// third-party
import { sub } from 'date-fns';
import { Chance } from 'chance';
import lodash from 'lodash';

const chance = new Chance();

const colleges = [
  'Adelphi University',
  'American University - International Accelerator',
  'Auburn University',
  'Felician University',
  'University of Dayton',
  'Florida State College at Jacksonville English Language Institute',
  'Heartland Community College',
  'McNeese State University',
  'Northwest Missouri State University',
  'Rockland Community College',
  'South Dakota School of Mines and Technology',
  'Maryville College',
  'American University of Antigua College of Medicine (AUA)',
  'Central Connecticut State University Intensive Language Program',
  'Florida International University Global First Year',
  'George Mason University',
  'Johns Hopkins Whiting School of Engineering',
  'Lingoda',
  'Madison College',
  'Santa Fe College',
  'Study Florida',
  'Study Illinois',
  'Study South Carolina',
  'Study Tennessee',
  'Study Wisconsin',
  'The University of North Florida Coggin College of Business',
  'University of Kansas',
  'University of Minnesota-Twin Cities',
  'Broward College',
  'California State University, Monterey Bay',
  'California State University-Dominguez Hills',
  'Cleveland State Global',
  'College of Central Florida',
  'Full Sail University',
  'Gonzaga University',
  'Louisiana State University - Global Pathway',
  'Middle Tennessee State University',
  'Nicholls State University',
  'Northeastern Junior College',
  'UMass Boston',
  'University of Arkansas',
  'University of Illinois at Chicago Global',
  'University of Illinois at Springfield',
  'University of Mount Union',
  'University of South Carolina',
  'University of Utah',
  'University of West Georgia',
  'UOP International',
  'Valencia College'
];

const screenSzie = ['720x1280', '1080x1920', '1440x2560', '2160x3840'];

const time = ['just now', '1 day ago', '2 min ago', '2 days ago', '1 week ago', '1 year ago', '5 months ago', '3 hours ago', '1 hour ago'];

export const range = (len) => {
  const arr = [];
  for (let i = 0; i < len; i += 1) {
    arr.push(i);
  }
  return arr;
};

// Generat 50 id for kiosk customer
const customerIds = range(20).map(() => chance.guid());
const kioskIds = range(200).map(() => chance.bb_pin());

export const mockKioskCustomerData = (index) => {
  return {
    id: `${kioskIds[index]}`,
    kioskName: chance.hash({ length: 8 }),
    email: chance.email({ domain: 'gmail.com' }),
    macId: chance.hash({ length: 15 }),
    communicationStatus: chance.bool(),
    errorStatus: chance.bool(),
    owner: chance.pickone(customerIds),
    deployedLocation: chance.pickone(colleges),
    onSiteContact: {
      firstName: chance.first(),
      lastName: chance.last(),
      phone: chance.phone(),
      email: chance.email({ domain: 'gmail.com' })
    },
    inventoryScented: chance.integer({ min: 0, max: 100 }),
    inventoryUnscented: chance.integer({ min: 0, max: 100 }),
    screenSize: chance.pickone(screenSzie),
    sbcHWVersion: chance.hash({ length: 5 }),
    sbcSWVersion: chance.hash({ length: 5 }),
    motorHWVersion: chance.hash({ length: 5 }),
    motorSWVersion: chance.hash({ length: 5 }),
    checkInTime: sub(new Date(), { days: chance.integer({ min: 0, max: 100 }) }),
    time: lodash.sampleSize(time)
  };
};

export const mockCustomerData = () => {
  return {
    id: chance.pickone(customerIds),
    schoolName: chance.pickone(colleges),
    customerFirstName: chance.first(),
    customerLastName: chance.last(),
    customerEmail: chance.email({ domain: 'gmail.com' }),
    customerPhone: chance.phone(),
    customerAddress: chance.address(),
    customerCity: chance.city(),
    customerState: chance.state(),
    customerCountry: chance.country(),
    customerZip: chance.zip(),
    kioskIds: lodash.sampleSize(kioskIds, chance.integer({ min: 1, max: 20 }))
  };
};

export const mockClientsData = () => {
  return {
    id: chance.pickone(customerIds),
    class_year: chance.pickone(['Freshman', 'Sophomore', 'Junior', 'Senior', 'Graduate']),
    email: chance.email({ domain: 'gmail.com' }),
    first_name: chance.first(),
    subscription: chance.pickone(['Paid', 'Subsidized']),
    gender: chance.pickone(['M', 'F']),
    last_name: chance.last(),
    order_date: sub(new Date(), { days: chance.integer({ min: 0, max: 100 }) }),
    frequency: chance.integer({ min: 0, max: 100 }),
    order_number: chance.integer({ min: 100000, max: 900000 }),
    product: chance.pickone(['Product 1', 'Product 2', 'Product 3', 'Product 4', 'Product 5']),
    quantity: chance.integer({ min: 0, max: 50 }) + '/' + chance.pickone(['50', '100', '150']),
    scenti: chance.pickone(['Scented', 'Unscented']),
    school: chance.pickone(colleges),
    tel: chance.phone()
  };
};
