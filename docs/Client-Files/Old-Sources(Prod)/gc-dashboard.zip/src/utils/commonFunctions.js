export function getErrors(values) {
  const errors = [];
  try {
    if (values?.inventoryScented < 15) {
      errors.push('Scented Inventory Low');
    }
    if (values?.inventoryUnscented < 15) {
      errors.push('Unscented Inventory Low');
    }

    if (values?.status) {
      values?.status?.motor1?.toLowerCase() !== 'clear' && errors.push('Motor 1 Stuck');
      values?.status?.motor2?.toLowerCase() !== 'clear' && errors.push('Motor 2 Stuck');
      values?.status?.temp > 50 && errors.push('Temp has exceeded the threshold');
      values?.status?.door?.toLowerCase() === 'open' && errors.push('Door Open');
      values?.status?.communication?.toLowerCase() === 'error' && errors.push('Kiosk internal communication error');
    }
  } catch {
    console.log('error in getErrors');
  }

  return errors;
}
