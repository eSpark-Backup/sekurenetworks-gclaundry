// TODO: Remove this file once the new account data is implemented.

const users = [
  {
    id: '5e86809283e28b96d2d38537',
    email: 'gc-dashboard@gmail.com',
    password: 'Password@123',
    name: 'GC Admin'
  }
];

export default users;
