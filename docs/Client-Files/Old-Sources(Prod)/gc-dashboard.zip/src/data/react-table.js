import {range} from 'utils/mock-data';
import {mockClientsData, mockCustomerData, mockKioskCustomerData} from 'utils/mock-kiosk-customer-data';

// Kiosk Data

const newKiosk = (index) => {
  return mockKioskCustomerData(index);
};

export const makeKioskData = (...lens) => {
  const makeDataLevel = (depth = 0) => {
    const len = lens[depth];
    return range(len).map((d, index) => ({
      ...newKiosk(index + 1),
      subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined
    }));
  };

  return makeDataLevel();
};

// Customer Data

const newCustomer = (index) => {
  return mockCustomerData(index);
};

export const makeCustomersData = (...lens) => {
  const makeDataLevel = (depth = 0) => {
    const len = lens[depth];
    return range(len).map((d, index) => ({
      ...newCustomer(index + 1),
      subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined
    }));
  };

  return makeDataLevel();
};

// Clients Data

const newClient = (index) => {
  return mockClientsData(index);
};

export const makeClientsData = (...lens) => {
  const makeDataLevel = (depth = 0) => {
    const len = lens[depth];
    return range(len).map((d, index) => ({
      ...newClient(index + 1),
      subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined
    }));
  };

  return makeDataLevel();
};
