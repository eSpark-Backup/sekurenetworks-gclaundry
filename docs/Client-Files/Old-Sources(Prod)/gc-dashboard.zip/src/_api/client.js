import axios from 'axios';

export const getClientData = () => {
  return axios
    .get('/clients')
    .then((response) =>
      response.data
    )
    .catch((error) => console.log('error', error));
};
