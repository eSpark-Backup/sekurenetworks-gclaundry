import axios from 'axios';

export const getKioskData = () =>
  axios
    .get('/kiosk')
    .then((response) => response.data)
    .catch((error) => console.log('error', error));

export const getKioskDataById = (id) =>
  axios
    .get(`/kiosk/${id}`)
    .then((response) => response.data)
    .catch((error) => console.log('error', error));

export const updateKioskData = (data, id) =>
  axios[id ? 'patch' : 'post']('/kiosk' + (id ? '/' + id : ''), data)
    .then((response) => response.data)
    .catch((error) => console.log('error', error));

export const updateKioskStatus = (data, id) =>
  axios['patch'](`/kiosk/${id}/activate`, data)
    .then((response) => response.data)
    .catch((error) => console.log('error', error));

export const deleteKioskData = (id) => axios.delete(`/kiosk/${id}`).catch((error) => console.log('error', error));
