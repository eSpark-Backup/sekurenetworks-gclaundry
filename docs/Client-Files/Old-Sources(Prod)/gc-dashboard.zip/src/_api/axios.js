import axios from 'axios';
import firebase from 'firebase/compat/app';

axios.interceptors.request.use(
  async function (config) {
    if (process.env.REACT_APP_ENV === 'production') {
      config.url = `https://kiosk-portal-363821.uc.r.appspot.com${config.url}`;
    }

    const token = await firebase.auth().currentUser.getIdToken();

    config.headers.Authorization = `Bearer ${token}`;

    return config;
  },
  function (error) {
    console.error('interceptor error', error);
  }
);
