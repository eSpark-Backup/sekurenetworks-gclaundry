import axios from 'axios';

export const getCustomersData = () => {
  return axios
    .get('/customers')
    .then((response) => response.data)
    .catch((error) => console.log('error', error));
};

export const getCustomersDataById = (id) =>
  axios
    .get(`/customers/${id}`)
    .then((response) => response.data)
    .catch((error) => console.log('error', error));

export const createUpdateCustomer = (data, _id) => {
  if (_id) {
    return axios
      .patch(`/customers/${_id}`, data)
      .then((response) => response.data)
      .catch((error) => console.log('error', error));
  } else {
    return axios
      .post(`/customers`, data)
      .then((response) => response.data)
      .catch((error) => console.log('error', error));
  }
};

export const deleteCustomerData = (id) => axios.delete(`/customers/${id}`).catch((error) => console.log('error', error));
