import axios from 'axios';

export const getDashboardData = () => axios.get('/dashboard').then((res) => res.data);
