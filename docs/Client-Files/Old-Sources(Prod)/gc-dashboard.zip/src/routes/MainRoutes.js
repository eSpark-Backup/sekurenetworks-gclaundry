import { lazy } from 'react';

// project import
import MainLayout from 'layout/MainLayout';
import Loadable from 'components/Loadable';
import AuthGuard from 'utils/route-guard/AuthGuard';
import AddEditKiosk from '../pages/kiosk/add-edit';
import AddEditCustomer from '../pages/customers/add-edit';
import AppLogout from '../sections/auth/AppLogout';

const KioskList = Loadable(lazy(() => import('pages/kiosk/list')));
const KioskDetail = Loadable(lazy(() => import('pages/kiosk/detail')));

const CustomerList = Loadable(lazy(() => import('pages/customers/list')));
const CustomerDetail = Loadable(lazy(() => import('pages/customers/details')));

const ClientsList = Loadable(lazy(() => import('pages/clients/list')));
// render - sample page
const DefaultDashboard = Loadable(lazy(() => import('pages/dashboard/default')));

// ==============================|| MAIN ROUTING ||============================== //

const MainRoutes = {
  path: '/',
  children: [
    {
      path: '/',
      element: (
        <AuthGuard>
          <AppLogout>
            <MainLayout />
          </AppLogout>
        </AuthGuard>
      ),
      children: [
        {
          path: 'dashboard',
          element: <DefaultDashboard />
        },
        {
          path: 'kiosk',
          element: <KioskList />
        },
        {
          path: 'kiosk/online',
          element: <KioskList filter="online" />
        },
        {
          path: 'kiosk/offline',
          element: <KioskList filter="offline" />
        },
        {
          path: 'kiosk/low-inventory',
          element: <KioskList filter="low-inventory" />
        },
        {
          path: 'kiosk/new',
          element: <AddEditKiosk />
        },
        {
          path: 'kiosk/edit/:id',
          element: <AddEditKiosk />
        },
        {
          path: 'kiosk/:id',
          element: <KioskDetail />
        },
        {
          path: 'customers',
          element: <CustomerList />
        },
        {
          path: 'customer/new',
          element: <AddEditCustomer />
        },
        {
          path: 'customer/edit/:id',
          element: <AddEditCustomer />
        },
        {
          path: 'customer/:id',
          element: <CustomerDetail />
        },
        {
          path: 'clients',
          element: <ClientsList />
        }
      ]
    }
  ]
};

export default MainRoutes;
