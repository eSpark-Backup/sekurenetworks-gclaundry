import { createContext, useContext, useEffect, useState } from 'react';
import { getKioskData } from '../_api/kiosk';

const KioskContext = createContext({
  kiosks: [],
  fetchKiosks: () => null,
  fetchingKiosksStatus: false
});
export const useKiosk = () => useContext(KioskContext);

// eslint-disable-next-line react/prop-types
export const KioskProvider = ({ children }) => {
  const [kiosks, setKiosks] = useState([]);
  const [fetchingKiosksStatus, setFetchingKiosksStatus] = useState(true);

  const fetchKiosks = () => {
    setFetchingKiosksStatus(true);
    getKioskData()
      .then(setKiosks)
      .catch((err) => {
        console.log(err);
      })
      .finally(() => setFetchingKiosksStatus(false));
  };

  useEffect(() => {
    fetchKiosks();
  }, []);

  // eslint-disable-next-line
  return <KioskContext.Provider value={{ kiosks, fetchKiosks, fetchingKiosksStatus }}>{children}</KioskContext.Provider>;
};
