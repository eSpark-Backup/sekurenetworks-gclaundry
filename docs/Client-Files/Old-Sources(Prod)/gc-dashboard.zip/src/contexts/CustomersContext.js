import { createContext, useContext, useEffect, useState } from 'react';
import { getCustomersData } from '../_api/customer';

const CustomersContext = createContext({
  clients: [],
  setClients: () => null
});
export const useCustomer = () => useContext(CustomersContext);

// eslint-disable-next-line react/prop-types
export const CustomerProvider = ({ children }) => {
  const [customers, setCustomers] = useState([]);
  const [loadingCustomers, setLoadingCustomers] = useState(true);

  useEffect(() => {
    setLoadingCustomers(true);
    getCustomersData()
      .then((data) => {
        setCustomers(data);
      })
      .catch((err) => {
        console.log(err);
        setCustomers([]);
      })
      .finally(() => setLoadingCustomers(false));
  }, [setCustomers]);

  // eslint-disable-next-line
  return <CustomersContext.Provider value={{ customers, setCustomers, loadingCustomers }}>{children}</CustomersContext.Provider>;
};
