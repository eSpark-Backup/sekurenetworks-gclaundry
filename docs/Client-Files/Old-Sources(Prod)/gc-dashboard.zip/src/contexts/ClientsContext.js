import { createContext, useContext, useEffect, useState } from 'react';
import { getClientData } from '../_api/client';

const ClientsContext = createContext({
  clients: [],
  setClients: () => null
});
export const useClient = () => useContext(ClientsContext);

// eslint-disable-next-line react/prop-types
export const ClientProvider = ({ children }) => {
  const [clients, setClients] = useState([]);
  const [loadingClients, setLoadingClients] = useState(true);

  useEffect(() => {
    setLoadingClients(true);
    getClientData()
      .then((data) => {
        setClients(data);
      })
      .catch((err) => {
        console.log(err);
        setClients([]);
      })
      .finally(() => setLoadingClients(false));
  }, [setClients]);

  // eslint-disable-next-line
  return <ClientsContext.Provider value={{ clients, setClients, loadingClients }}>{children}</ClientsContext.Provider>;
};
