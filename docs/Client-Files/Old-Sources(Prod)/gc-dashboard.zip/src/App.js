// project import
import Routes from 'routes';
import ThemeCustomization from 'themes';
import Locales from 'components/Locales';
import ScrollTop from 'components/ScrollTop';
import Snackbar from 'components/@extended/Snackbar';

// auth provider
import { FirebaseProvider as AuthProvider } from 'contexts/FirebaseContext';
import { KioskProvider } from 'contexts/KioskContext';
import { CustomerProvider } from './contexts/CustomersContext';
import { ClientProvider } from './contexts/ClientsContext';

// ==============================|| APP - THEME, ROUTER, LOCAL  ||============================== //
import './_api/axios';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const App = () => (
  <ThemeCustomization>
    <Locales>
      <ScrollTop>
        <AuthProvider>
          <CustomerProvider>
            <KioskProvider>
              <ClientProvider>
                <Routes />
                <Snackbar />
                <ToastContainer theme="colored" position={'top-center'} />
              </ClientProvider>
            </KioskProvider>
          </CustomerProvider>
        </AuthProvider>
      </ScrollTop>
    </Locales>
  </ThemeCustomization>
);

export default App;
