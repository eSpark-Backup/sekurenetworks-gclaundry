import React from 'react';
import { TextField } from '@mui/material';

const CustomTextField = ({ formik, name, label, accessorName, disabled = false, ...props }) => {
  if (accessorName) {
    return (
      <TextField
        id={name}
        name={name}
        label={label}
        value={formik.values[accessorName]}
        onChange={formik.handleChange}
        error={formik.touched[accessorName] && Boolean(formik.errors[accessorName])}
        helperText={formik.touched[accessorName] && props?.formik?.errors[accessorName]}
        fullWidth
        autoComplete="given-name"
        padding={2}
        disabled={disabled}
        {...props}
      />
    );
  }

  return null;
};

export default CustomTextField;
