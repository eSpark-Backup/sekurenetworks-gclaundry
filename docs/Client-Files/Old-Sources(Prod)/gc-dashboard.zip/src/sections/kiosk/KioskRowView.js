import PropTypes from 'prop-types';

// material-ui
import { useTheme } from '@mui/material/styles';
import { Divider, Grid, List, ListItem, Stack, TableCell, TableRow, Typography, useMediaQuery } from '@mui/material';

// third-party
import NumberFormat from 'react-number-format';

// project import
import MainCard from 'components/MainCard';
import Mailto from '../../components/Mailto';

// ==============================|| CUSTOMER - VIEW ||============================== //

const KioskRowView = ({ data }) => {
  const theme = useTheme();
  const matchDownMD = useMediaQuery(theme.breakpoints.down('md'));

  return (
    <TableRow sx={{ '&:hover': { bgcolor: `transparent !important` } }}>
      <TableCell colSpan={13} sx={{ p: 2.5 }}>
        <Grid container spacing={2.5} sx={{ px: { xs: 0, sm: 5, md: 6, lg: 10, xl: 12 } }}>
          <Grid item xs={4} sm={4} md={4} lg={4}>
            <MainCard>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Stack spacing={2.5} alignItems="center">
                    <Stack spacing={0.5} alignItems="center">
                      <Typography variant="h3">{data.kioskName}</Typography>
                      <Typography color="secondary">mac: {data.macId}</Typography>
                      <Typography variant="h5">{data.deployedLocation}</Typography>
                    </Stack>
                  </Stack>
                </Grid>
                <Grid item xs={12}>
                  <Divider />
                </Grid>
                <Grid item xs={12}>
                  <Stack direction="row" justifyContent="space-around" alignItems="center">
                    <Divider orientation="vertical" flexItem />
                    <Stack spacing={0.5} alignItems="center">
                      <Typography variant="h5">Scented</Typography>
                      <Typography color="secondary">{data.inventoryScented}</Typography>
                    </Stack>
                    <Divider orientation="vertical" flexItem />
                    <Stack spacing={0.5} alignItems="center">
                      <Typography variant="h5">Unscented</Typography>
                      <Typography color="secondary">{data.inventoryUnscented}</Typography>
                    </Stack>
                    <Divider orientation="vertical" flexItem />
                  </Stack>
                </Grid>

                <Grid item xs={12}>
                  <Divider />
                </Grid>
              </Grid>
            </MainCard>
          </Grid>

          <Grid item xs={8} sm={8} md={8} lg={8}>
            <Stack spacing={2.5}>
              <MainCard>
                <Typography variant="h3">On site Contact</Typography>
                <List sx={{ py: 0 }}>
                  <ListItem divider={!matchDownMD}>
                    <Grid container spacing={3}>
                      <Grid item xs={12} md={6}>
                        <Stack spacing={0.5}>
                          <Typography color="secondary">Name</Typography>
                          <Typography>{`${data.onSiteContact?.firstName} ${data.onSiteContact?.lastName}`}</Typography>
                        </Stack>
                      </Grid>
                      <Grid item xs={12} md={6}>
                        <Stack spacing={0.5}>
                          <Typography color="secondary">Phone</Typography>
                          <NumberFormat displayType="text" format="+1 (###) ###-####" mask="_" defaultValue={data.onSiteContact?.phone} />
                        </Stack>
                      </Grid>
                    </Grid>
                  </ListItem>
                  <ListItem divider={!matchDownMD}>
                    <Stack spacing={0.5}>
                      <Typography color="secondary">Email</Typography>
                      <Typography>
                        <Mailto email={data.onSiteContact?.email} />
                      </Typography>
                    </Stack>
                  </ListItem>
                </List>
              </MainCard>
            </Stack>
          </Grid>
        </Grid>
      </TableCell>
    </TableRow>
  );
};

KioskRowView.propTypes = {
  data: PropTypes.object
};

export default KioskRowView;
