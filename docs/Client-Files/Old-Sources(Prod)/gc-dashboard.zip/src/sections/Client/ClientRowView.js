import PropTypes from 'prop-types';

// material-ui
import { Grid, Stack, TableCell, TableRow, Typography } from '@mui/material';

// third-party
// project import
import MainCard from 'components/MainCard';
import { format } from 'date-fns';
import config from '../../config';

// ==============================|| CUSTOMER - VIEW ||============================== //

const ClientRowView = ({ data }) => {
  return (
    <TableRow sx={{ '&:hover': { bgcolor: `transparent !important` } }}>
      <TableCell colSpan={8} sx={{ p: 2.5 }}>
        <Grid item xs={12} sm={5} md={4} lg={3}>
          <MainCard>
            <Grid container spacing={3}>
              <Grid item sm={5} md={6} lg={6}>
                <Stack spacing={0.5} alignItems="start">
                  <Typography variant="h5">Class Year: {data.class_year}</Typography>
                  <Typography variant="h5">Subscription: {data.subscription}</Typography>
                  <Typography variant="h5">Product: {data.product}</Typography>
                </Stack>
              </Grid>
              <Grid item sm={5} md={6} lg={6}>
                <Stack spacing={0.5} alignItems="start">
                  <Typography variant="h5">Order Number: {data.order_number}</Typography>
                  <Typography variant="h5">
                    Order Date: {format(new Date(Date.parse(data.order_date)), config.dateFormat)?.toLocaleString()}
                  </Typography>
                  <Typography variant="h5">Frequency: {data.frequency || ''}</Typography>
                </Stack>
              </Grid>
            </Grid>
          </MainCard>
        </Grid>
      </TableCell>
    </TableRow>
  );
};

ClientRowView.propTypes = {
  data: PropTypes.object
};

export default ClientRowView;
