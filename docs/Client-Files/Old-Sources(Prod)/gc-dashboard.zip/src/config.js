export const drawerWidth = 260;

export const twitterColor = '#1DA1F2';
export const facebookColor = '#3b5998';
export const linkedInColor = '#0e76a8';

export const FIREBASE_API = {
  apiKey: 'AIzaSyCMIjry7TUSRIVMPdsNaCJCtlc_I6k-Pno',
  authDomain: 'laundry-web-control-app.firebaseapp.com',
  projectId: 'laundry-web-control-app',
  storageBucket: 'laundry-web-control-app.appspot.com',
  messagingSenderId: '1051759487989',
  appId: '1:1051759487989:web:0a14ecde752b9db920cebc',
  measurementId: 'G-DQPGCM98K2'
};

// ==============================|| THEME CONFIG  ||============================== //

const config = {
  defaultPath: '/dashboard',
  fontFamily: `'Public Sans', sans-serif`,
  i18n: 'en',
  miniDrawer: false,
  container: true,
  mode: 'light',
  presetColor: 'default',
  themeDirection: 'ltr',
  dateFormat: 'MMM dd, yyyy hh:mm a',
  actualPin: 3315
};

export default config;
