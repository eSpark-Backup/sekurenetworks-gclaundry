import { Button, Grid, OutlinedInput, Stack, Typography } from '@mui/material';
import MainCard from '../../components/MainCard';
import { useFormik } from 'formik';

import { useParams } from 'react-router';
import React, { useEffect, useState } from 'react';
import * as yup from 'yup';
import KioskList from '../kiosk/list';
import CustomTextField from '../../components/CustomTextField';
import AnimateButton from '../../components/@extended/AnimateButton';
import { createUpdateCustomer, getCustomersDataById } from '../../_api/customer';
import { PlusOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import AlertDialog from '../../components/@extended/AlertDialog';
import { TextMaskCustom } from '../../components/TextMaskInput';

const validationSchema = yup.object({
  schoolName: yup.string().required('School/Institution Name is required'),
  customerFirstName: yup.string().required('First Name is required'),
  customerLastName: yup.string().required('Last Name is required'),
  customerPhone: yup.string().required('Phone is required'),
  customerEmail: yup.string().required('Email is required'),
  customerAddress: yup.string().required('Address is required'),
  customerCity: yup.string().required('City is required'),
  customerState: yup.string().required('State is required'),
  customerCountry: yup.string().required('Country is required'),
  customerZip: yup.string().required('Zip is required')
});

const AddEditCustomer = () => {
  const params = useParams();
  const navigate = useNavigate();
  const [customer, setCustomer] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState(0);

  useEffect(() => {
    setIsEditMode(!!params.id);
    if (params.id) {
      getCustomersDataById(params.id)
        .then((data) => {
          setPhoneNumber(data.customerPhone);
          setCustomer(data);
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [params.id]);

  // useEffect(() => {
  //   const customerDummyData = makeCustomersData(1);
  //   delete customerDummyData[0]?.id;
  //   delete customerDummyData[0]?.kioskIds;
  //
  //   formik.setValues(customerDummyData[0]);
  // }, []);

  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      schoolName: customer ? customer.schoolName : '',
      customerFirstName: customer ? customer?.customerFirstName : '',
      customerLastName: customer ? customer?.customerLastName : '',
      customerPhone: customer ? customer?.customerPhone : '',
      customerEmail: customer ? customer?.customerEmail : '',
      customerAddress: customer ? customer?.customerAddress : '',
      customerCity: customer ? customer?.customerCity : '',
      customerState: customer ? customer?.customerState : '',
      customerCountry: customer ? customer?.customerCountry : '',
      customerZip: customer ? customer?.customerZip : ''
    },
    validationSchema,
    onSubmit: (values) => {
      createUpdateCustomer(values, customer?._id)
        .then((data) => {
          if (data) {
            toast(customer?._id ? 'Customer Updated Successfully' : 'Customer Added Successfully', { type: 'success' });
            navigate('/customers');
          }
        })
        .catch((err) => {
          toast(err?.message || 'Error', { type: 'error' });
        });
    }
  });

  const handleAdd = () => {
    // if (kiosk && !add) setKiosk(null);
    const props = { state: customer ? { customer } : undefined };
    navigate(`/kiosk/new`, props);
  };

  const handlePhoneChange = (event) => {
    const val = event.target.value;
    setPhoneNumber(val);
    formik.setFieldValue('customerPhone', val);
  };

  return (
    <>
      <AlertDialog
        open={openDialog}
        setOpen={setOpenDialog}
        title={'Confirm'}
        content={'Are you sure, you want to ' + `${isEditMode ? 'update customer info?' : 'add new customer?'}`}
        handleConfirm={() => {
          setOpenDialog(false);
          return formik.submitForm();
        }}
      />
      <MainCard>
        <form onSubmit={formik.handleSubmit} id="validation-forms">
          <Grid container spacing={2.5}>
            <Grid item xs={12}>
              <MainCard>
                <Grid container spacing={3}>
                  <Grid item sm={5} md={6} lg={6}>
                    <Stack spacing={2} paddingBottom={3} alignItems="start">
                      <CustomTextField formik={formik} name="schoolName" label="School/Institution Name *" accessorName="schoolName" />
                      <CustomTextField formik={formik} name="customerFirstName" label="First Name *" accessorName="customerFirstName" />
                      <CustomTextField formik={formik} name="customerLastName" label="Last Name *" accessorName="customerLastName" />
                      {/*<CustomTextField formik={formik} name="customerPhone" label="Phone *" accessorName="customerPhone" />*/}
                      <OutlinedInput
                        onChange={handlePhoneChange}
                        name="customerPhone"
                        id="customerPhone"
                        fullWidth
                        value={phoneNumber}
                        inputComponent={TextMaskCustom}
                      />
                      <CustomTextField
                        id="customerEmail"
                        name="customerEmail"
                        label="Email *"
                        formik={formik}
                        accessorName="customerEmail"
                      />
                    </Stack>
                  </Grid>
                  <Grid item sm={5} md={6} lg={6}>
                    <Stack spacing={2} alignItems="start">
                      <CustomTextField name="customerAddress" label="Address *" formik={formik} accessorName="customerAddress" />
                      <CustomTextField name="customerCity" label="City *" formik={formik} accessorName="customerCity" />
                      <CustomTextField name="customerState" label="State *" formik={formik} accessorName="customerState" />
                      <CustomTextField name="customerCountry" label="Country *" formik={formik} accessorName="customerCountry" />
                      <CustomTextField name="customerZip" label="ZIP *" formik={formik} accessorName="customerZip" />
                    </Stack>
                  </Grid>
                </Grid>
                <Grid item xs={12} paddingTop={0}>
                  <Stack direction="row" justifyContent="center">
                    <AnimateButton>
                      <Button variant="contained" sx={{ my: 3, ml: 1 }} type="button" onClick={() => setOpenDialog(true)}>
                        {isEditMode ? 'Update' : 'Create'}
                      </Button>
                    </AnimateButton>
                  </Stack>
                </Grid>
              </MainCard>
            </Grid>
            {customer?.kioskIds?.length ? (
              <Grid xs={12} item>
                <Stack spacing={2.5}>
                  <MainCard>
                    <Grid item xs={12}>
                      <Typography variant="h3" paddingTop={2} paddingBottom={2}>
                        Total Kiosks: {customer?.kioskIds?.length}
                      </Typography>
                      <Stack spacing={2.5}>
                        <KioskList />
                      </Stack>
                    </Grid>
                  </MainCard>
                </Stack>
              </Grid>
            ) : (
              <Grid xs={12} item>
                <Stack alignItems="center" spacing={1}>
                  {/*<SortingSelect sortBy={sortBy.id} setSortBy={setSortBy} allColumns={allColumns} />*/}
                  <Button variant="contained" startIcon={<PlusOutlined />} onClick={handleAdd}>
                    Add Kiosk
                  </Button>
                </Stack>
              </Grid>
            )}
          </Grid>
        </form>
      </MainCard>
    </>
  );
};

export default AddEditCustomer;
