import { Button, Divider, Grid, Stack, Typography } from '@mui/material';
import MainCard from '../../components/MainCard';
import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import { useParams } from 'react-router';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import KioskList from '../kiosk/list';
import AlertDialog from '../../components/@extended/AlertDialog';
import { toast } from 'react-toastify';
import { deleteCustomerData, getCustomersDataById } from '../../_api/customer';

const CustomerDetail = () => {
  const params = useParams();
  const navigate = useNavigate();
  const [customer, setCustomer] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    // lookup id
    getCustomersDataById(params.id)
      .then((res) => {
        if (res) setCustomer(res);
      })
      .catch(() => {
        navigate('/customers');
      });
  }, [params.id]);

  if (!customer) return null;

  const handleAdd = () => {
    const props = { state: customer ? { customer } : undefined };
    navigate(`/kiosk/new`, props);
  };

  function handleDelete() {
    setOpenDialog(true);
  }

  return (
    <>
      <AlertDialog
        open={openDialog}
        setOpen={setOpenDialog}
        title={'Confirm'}
        content={'Are you sure, you want to delete Customer?'}
        handleConfirm={() => {
          deleteCustomerData(customer?._id)
            .then(() => {
              toast('Customer deleted successfully', { type: 'success' });
              navigate('/customers');
            })
            .catch((err) => {
              toast.error(err.message);
            });
        }}
      />
      <MainCard>
        <Stack alignItems="end" spacing={1} paddingBottom={1}>
          {/*<SortingSelect sortBy={sortBy.id} setSortBy={setSortBy} allColumns={allColumns} />*/}
          <Button variant="contained" startIcon={<EditOutlined />} onClick={() => navigate(`/customer/edit/${params?.id}`)}>
            Edit
          </Button>
        </Stack>
        <Grid container spacing={2.5}>
          <Grid item xs={12}>
            <MainCard>
              <Grid container spacing={3}>
                <Grid item sm={5} md={6} lg={6}>
                  <Stack spacing={0.5} paddingBottom={3} alignItems="start">
                    <Typography variant="h2">{customer.schoolName}</Typography>
                    <Typography variant="h5">{`${customer.customerFirstName} ${customer.customerLastName}`}</Typography>
                    <Typography variant="h5">{customer.customerPhone}</Typography>
                    <Typography variant="h5">{customer.customerEmail}</Typography>
                  </Stack>
                </Grid>
                <Grid item sm={5} md={6} lg={6}>
                  <Typography variant="h4">Address</Typography>

                  <Divider />
                  <Stack spacing={0.5} paddingTop={2} alignItems="start">
                    <Typography variant="h5">{customer.customerAddress}</Typography>
                    <Typography variant="h5">{`${customer.customerCity}, ${customer.customerState}`}</Typography>
                    <Typography variant="h5">{`${customer.customerCountry}, ${customer.customerZip}`}</Typography>
                  </Stack>
                </Grid>
              </Grid>
            </MainCard>
          </Grid>

          <Grid item xs={12}>
            {customer?.kioskIds?.length ? (
              <Grid xs={12} item>
                <Stack spacing={2.5}>
                  <MainCard>
                    <Grid item xs={12}>
                      <Typography variant="h3" paddingTop={2} paddingBottom={2}>
                        Total Kiosks: {customer?.kioskIds?.length}
                      </Typography>
                      <Stack spacing={2.5}>
                        <KioskList />
                      </Stack>
                    </Grid>
                  </MainCard>
                </Stack>
              </Grid>
            ) : (
              <Grid xs={12} item>
                <Stack alignItems="center" spacing={1}>
                  {/*<SortingSelect sortBy={sortBy.id} setSortBy={setSortBy} allColumns={allColumns} />*/}
                  <Button variant="contained" startIcon={<PlusOutlined />} onClick={handleAdd}>
                    Add Kiosk
                  </Button>
                </Stack>
              </Grid>
            )}
          </Grid>
        </Grid>
      </MainCard>

      <Stack alignItems="center" spacing={1} paddingTop={1}>
        {/*<SortingSelect sortBy={sortBy.id} setSortBy={setSortBy} allColumns={allColumns} />*/}
        <Button variant="contained" color="error" startIcon={<DeleteOutlined />} onClick={handleDelete}>
          Delete
        </Button>
      </Stack>
    </>
  );
};

export default CustomerDetail;
