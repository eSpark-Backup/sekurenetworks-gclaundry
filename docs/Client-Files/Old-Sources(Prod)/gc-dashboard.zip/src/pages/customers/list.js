import PropTypes from 'prop-types';
import { Fragment, useEffect, useMemo, useState } from 'react';

// material-ui
import { alpha, useTheme } from '@mui/material/styles';
import {
  Alert,
  Button,
  LinearProgress,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
  useMediaQuery
} from '@mui/material';

// third-party
import { useExpanded, useFilters, useGlobalFilter, usePagination, useSortBy, useTable } from 'react-table';

// project import
import IconButton from 'components/@extended/IconButton';
import MainCard from 'components/MainCard';
import ScrollX from 'components/ScrollX';
import { GlobalFilter, renderFilterTypes } from 'utils/react-table';
import { HeaderSort, TablePagination } from 'components/third-party/ReactTable';

// assets
import { EditTwoTone, FileTextOutlined, PlusOutlined } from '@ant-design/icons';
import Mailto from '../../components/Mailto';
import { useNavigate } from 'react-router-dom';
import { useCustomer } from '../../contexts/CustomersContext';
import { getCustomersData } from '../../_api/customer';

// ==============================|| REACT TABLE ||============================== //

const NUMBER_OF_ROWS = 25;

function ReactTable({ columns, data, getHeaderProps, renderRowSubComponent, handleAdd }) {
  const theme = useTheme();
  const matchDownSM = useMediaQuery(theme.breakpoints.down('sm'));

  const filterTypes = useMemo(() => renderFilterTypes, []);
  const sortBy = { id: 'customerFirstName', desc: false };

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    visibleColumns,
    rows,
    // @ts-ignore
    page,
    // @ts-ignore
    gotoPage,
    // @ts-ignore
    setPageSize,
    // @ts-ignore
    state: { globalFilter, pageIndex, pageSize },
    // @ts-ignore
    preGlobalFilteredRows,
    // @ts-ignore
    setGlobalFilter
    // @ts-ignore
  } = useTable(
    {
      columns,
      data,
      // @ts-ignore
      filterTypes,
      // @ts-ignore
      initialState: {
        pageIndex: 0,
        pageSize: NUMBER_OF_ROWS,
        sortBy: [sortBy],
        hiddenColumns: ['customerPhone', 'customerLastName', 'customerState']
      }
    },
    useGlobalFilter,
    useFilters,
    useSortBy,
    useExpanded,
    usePagination
  );

  return (
    <>
      <Stack spacing={3}>
        <Stack
          direction={matchDownSM ? 'column' : 'row'}
          justifyContent="space-between"
          alignItems="center"
          spacing={1}
          sx={{ p: 3, pb: 0 }}
        >
          <GlobalFilter
            preGlobalFilteredRows={preGlobalFilteredRows}
            globalFilter={globalFilter}
            setGlobalFilter={setGlobalFilter}
            size="small"
          />
          <Stack direction={matchDownSM ? 'column' : 'row'} alignItems="center" spacing={1}>
            {/*<SortingSelect sortBy={sortBy.id} setSortBy={setSortBy} allColumns={allColumns} />*/}
            <Button variant="contained" startIcon={<PlusOutlined />} onClick={handleAdd}>
              Add New Customer
            </Button>
          </Stack>
        </Stack>

        <Table {...getTableProps()}>
          <TableHead>
            {headerGroups.map((headerGroup, i) => (
              <TableRow key={i} {...headerGroup.getHeaderGroupProps()} sx={{ '& > th:first-of-type': { width: '58px' } }}>
                {headerGroup.headers.map((column, index) => (
                  <TableCell key={index} {...column.getHeaderProps([{ className: column.className }, getHeaderProps(column)])}>
                    <HeaderSort column={column} />
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableHead>
          <TableBody {...getTableBodyProps()}>
            {page.map((row, i) => {
              prepareRow(row);
              const rowProps = row.getRowProps();

              return (
                <Fragment key={i}>
                  <TableRow
                    {...row.getRowProps()}
                    sx={{
                      cursor: 'pointer',
                      bgcolor:
                        row.values?.inventoryScented < 10 || row.values?.inventoryUnscented < 10
                          ? alpha(theme.palette.warning.light, 0.35)
                          : 'inherit'
                    }}
                  >
                    {row.cells.map((cell, index) => (
                      <TableCell key={index} {...cell.getCellProps([{ className: cell.column.className }])}>
                        {cell.render('Cell')}
                      </TableCell>
                    ))}
                  </TableRow>
                  {row.isExpanded && renderRowSubComponent({ row, rowProps, visibleColumns })}
                </Fragment>
              );
            })}
            <TableRow sx={{ '&:hover': { bgcolor: 'transparent !important' } }}>
              <TableCell sx={{ p: 2, py: 3 }} colSpan={9}>
                <TablePagination gotoPage={gotoPage} rows={rows} setPageSize={setPageSize} pageSize={pageSize} pageIndex={pageIndex} />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Stack>
    </>
  );
}

ReactTable.propTypes = {
  columns: PropTypes.array,
  data: PropTypes.array,
  getHeaderProps: PropTypes.func,
  handleAdd: PropTypes.func,
  renderRowSubComponent: PropTypes.any
};

// ==============================|| CUSTOMERS - LIST VIEW ||============================== //

const CellContactDetails = ({ row }) => {
  const { original: values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Stack spacing={0}>
        <Typography variant="subtitle1">{`${values?.customerPhone}`}</Typography>
        <Typography variant="subtitle1" color="textSecondary">
          <Mailto email={values?.customerEmail} />
        </Typography>
      </Stack>
    </Stack>
  );
};

const CellCustomerName = ({ row }) => {
  const { original: values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Typography variant="subtitle1">{`${values?.customerFirstName} ${values?.customerLastName}`}</Typography>
    </Stack>
  );
};

const CellSchoolName = ({ row }) => {
  const { original: values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Typography variant="subtitle1">{values?.schoolName}</Typography>
    </Stack>
  );
};

const CellLocation = ({ row }) => {
  const { original: values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Stack spacing={0}>
        <Typography variant="subtitle1">{`${values?.customerCity}`}</Typography>
        <Typography variant="subtitle2" color="textSecondary">
          {values?.customerState}
        </Typography>
      </Stack>
    </Stack>
  );
};

const CellTotalKiosk = ({ row }) => {
  const { original: values } = row;

  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Stack spacing={0}>
        <Typography variant="subtitle1">{`${values?.kioskIds?.length || '0'}`}</Typography>
      </Stack>
    </Stack>
  );
};

const Actions = ({ theme, values, setCustomer }) => {
  const navigate = useNavigate();
  return (
    <>
      <Tooltip title="Detail">
        <IconButton
          color="primary"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/customer/${values?._id}`);
          }}
        >
          <FileTextOutlined twoToneColor={theme.palette.primary.main} />
        </IconButton>
      </Tooltip>
      <Tooltip title="Edit">
        <IconButton
          color="primary"
          onClick={(e) => {
            e.stopPropagation();
            setCustomer(values);
            navigate(`/customer/edit/${values?._id}`);
          }}
        >
          <EditTwoTone twoToneColor={theme.palette.primary.main} />
        </IconButton>
      </Tooltip>
    </>
  );
};

CellContactDetails.propTypes = {
  row: PropTypes.object
};

const CellActions = ({ row }) => {
  const theme = useTheme();
  const { original: values } = row;
  return (
    <Stack direction="row" alignItems="center" justifyContent="center" spacing={0}>
      <Actions theme={theme} values={values} setCustomer={setCustomer} />
    </Stack>
  );
};

CellActions.propTypes = {
  row: PropTypes.object
};

const CustomersList = () => {
  const navigate = useNavigate();
  const theme = useTheme();
  const { customers, setCustomers, loadingCustomers } = useCustomer();

  const [, setCustomer] = useState(null);

  // useEffect(() => {
  //   // fake async call
  //   if (!data.length) setCustomers(makeCustomersData(20));
  // }, []);

  useEffect(() => {
    getCustomersData().then((data) => {
      data && setCustomers(data);
    });
  }, []);

  const handleAdd = () => {
    navigate(`/customer/new`);
  };

  const columns = useMemo(
    () => [
      {
        Header: 'No',
        id: '_id',
        Cell: ({ row, flatRows }) => {
          return <Typography variant="subtitle1">{flatRows.indexOf(row) + 1}</Typography>;
        },
        disableSortBy: true
      },
      {
        Header: 'School/Institution',
        accessor: 'schoolName',
        Cell: CellSchoolName
      },

      {
        accessor: 'customerLastName'
      },

      {
        Header: 'Location',
        accessor: 'customerCity',
        Cell: CellLocation
      },
      {
        accessor: 'customerState'
      },
      {
        Header: 'Name',
        accessor: 'customerFirstName',
        Cell: CellCustomerName
      },
      {
        Header: 'Contact',
        accessor: 'customerEmail',
        Cell: CellContactDetails
      },
      {
        accessor: 'customerPhone'
      },
      {
        Header: 'Total Kiosk',
        // eslint-disable-next-line
        Cell: CellTotalKiosk
      },
      {
        Header: 'Actions',
        className: 'cell-center',
        disableSortBy: true,
        // eslint-disable-next-line
        Cell: ({ row }) => {
          const theme = useTheme();
          // eslint-disable-next-line
          const { original } = row;

          return (
            <Stack direction="row" alignItems="center" justifyContent="center" spacing={0}>
              <Actions theme={theme} values={original} setCustomer={setCustomer} />
            </Stack>
          );
        }
      }
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [theme]
  );

  if (loadingCustomers) return <LinearProgress />;

  return (
    <MainCard content={false}>
      <ScrollX>
        {customers?.length > 0 ? (
          <ReactTable columns={columns} data={customers} handleAdd={handleAdd} getHeaderProps={(column) => column.getSortByToggleProps()} />
        ) : (
          <Alert color="warning">No customers. Please try refreshing the page.</Alert>
        )}
      </ScrollX>
    </MainCard>
  );
};
export default CustomersList;
