import { useEffect, useState } from 'react';
// material-ui
import { Grid, LinearProgress } from '@mui/material';

// project import
import AnalyticEcommerce from 'components/cards/statistics/AnalyticEcommerce';
import { getDashboardData } from '../../_api/dashboard';
// import IncomeAreaChart from 'sections/dashboard/default/IncomeAreaChart';
// import MonthlyBarChart from 'sections/dashboard/default/MonthlyBarChart';
// import ReportAreaChart from 'sections/dashboard/default/ReportAreaChart';
// import SalesChart from 'sections/dashboard/SalesChart';
// import OrdersTable from 'sections/dashboard/default/OrdersTable';

// ==============================|| DASHBOARD - DEFAULT ||============================== //

/*
  "kiosk": {
    "total": 4,
    "online": 2,
    "offline": 2
  },
  "totalClients": 1,
  "totalCustomers": 11
 */

const DashboardDefault = () => {
  const [data, setData] = useState(null);

  useEffect(() => {
    getDashboardData().then(setData);
  }, [setData]);

  if (!data) return <LinearProgress />;

  return (
    <Grid container rowSpacing={4.5} columnSpacing={2.75}>
      {/* row 1 */}
      <Grid item xs={12} sm={6} md={4} lg={4}>
        <AnalyticEcommerce title="Online Kiosks" to="/kiosk/online" count={`${data.kiosk.online}`} />
      </Grid>
      <Grid item xs={12} sm={6} md={4} lg={4}>
        <AnalyticEcommerce title="Offline Kiosks" to="/kiosk/offline" count={`${data.kiosk.offline}`} />
      </Grid>
      <Grid item xs={12} sm={6} md={4} lg={4}>
        <AnalyticEcommerce title="Low Inventory Kiosks" to="/kiosk/low-inventory" count={`${data.totalLowInventoryKiosk}`} />
      </Grid>

      <Grid item md={8} sx={{ display: { sm: 'none', md: 'block', lg: 'none' } }} />
    </Grid>
  );
};

export default DashboardDefault;
