import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router';
import { Button, Divider, Grid, MenuItem, OutlinedInput, Select, Stack, TextField, Typography } from '@mui/material';
import * as yup from 'yup';
import { useFormik } from 'formik';
import MainCard from '../../components/MainCard';
import AnimateButton from '../../components/@extended/AnimateButton';
import CustomTextField from '../../components/CustomTextField';
import { useCustomer } from '../../contexts/CustomersContext';
import { Autocomplete } from '@mui/lab';
import { useLocation, useNavigate } from 'react-router-dom';
import { getKioskDataById, updateKioskData } from '../../_api/kiosk';
import { useKiosk } from '../../contexts/KioskContext';
import { LoadingOutlined } from '@ant-design/icons';
import { toast } from 'react-toastify';
import AlertDialog from '../../components/@extended/AlertDialog';
import 'yup-phone';
import { TextMaskCustom } from '../../components/TextMaskInput';

// const phoneNumberMask = ['(', /[1-9]/, /\d/, /\d/, ')', ' ', /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/];

const validationSchema = yup.object({
  kioskName: yup.string().required('Kiosk Name is required'),
  kioskId: yup.string().required('Kiosk Name is required'),
  deployedLocation: yup.string().required('Kiosk Location is required'),
  owner: yup.string().required('Customer is required'),
  onSiteContact: yup.object({
    firstName: yup.string().required('First name is required'),
    lastName: yup.string().required('Last name is required'),
    phone: yup.string().phone().required('Phone is required'),
    email: yup.string().email().required('Email is required')
  })
});

const AddEditKiosk = () => {
  const params = useParams();
  const navigate = useNavigate();
  const { fetchingKiosksStatus } = useKiosk();
  const { customers } = useCustomer();
  const [kiosk, setKiosk] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const location = useLocation();
  const [openDialog, setOpenDialog] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState(0);
  const [secondaryPhoneNumber, setSecondaryPhoneNumber] = useState(0);
  const newKioskId = useMemo(() => (Math.random() + 1).toString(36).substring(7), []);
  const formik = useFormik({
    enableReinitialize: true,
    initialValues: {
      _id: kiosk?._id || '',
      kioskName: kiosk ? kiosk.kioskName : '',
      kioskId: kiosk ? kiosk.kioskId : '',
      customerId: kiosk ? kiosk.customerId : location.state?.customer?._id || '',
      communicationStatus: kiosk ? kiosk.communicationStatus : false,
      deployedLocation: kiosk ? kiosk.deployedLocation : '',
      locationTag: kiosk ? kiosk.locationTag : '',
      address: {
        address: kiosk?.address?.address ?? '',
        city: kiosk?.address?.city ?? '',
        state: kiosk?.address?.state ?? '',
        country: kiosk?.address?.country ?? '',
        zip: kiosk?.address?.zip ?? ''
      },
      inventoryScented: kiosk ? kiosk.inventoryScented : '0%',
      inventoryUnscented: kiosk ? kiosk.inventoryUnscented : '0%',
      owner: location.state?.customer?.customerFirstName + ' ' + location.state?.customer?.customerLastName ?? '',
      email: location.state?.customer?.customerEmail ?? '',
      macId: kiosk ? kiosk.macId : '',
      resolution: kiosk ? kiosk.resolution : '',
      screen: kiosk ? kiosk.screen : '',
      sbcHWVersion: kiosk ? kiosk.sbcHWVersion : '',
      sbcSWVersion: kiosk ? kiosk.sbcSWVersion : '',
      mcbHWVersion: kiosk ? kiosk.mcbHWVersion : '',
      mcbSWVersion: kiosk ? kiosk.mcbSWVersion : '',
      motorHWVersion: kiosk ? kiosk.motorHWVersion : '',
      motorSWVersion: kiosk ? kiosk.motorSWVersion : '',
      onSiteContact: {
        firstName: kiosk?.onSiteContact?.firstName ?? '',
        lastName: kiosk?.onSiteContact?.lastName ?? '',
        phone: kiosk?.onSiteContact?.phone ?? '',
        email: kiosk?.onSiteContact?.email ?? ''
      },
      onSiteContactSecondary: {
        firstName: kiosk?.onSiteContactSecondary?.firstName ?? '',
        lastName: kiosk?.onSiteContactSecondary?.lastName ?? '',
        phone: kiosk?.onSiteContactSecondary?.phone ?? '',
        email: kiosk?.onSiteContactSecondary?.email ?? ''
      },
      isActive: kiosk?.isActive
    },
    validationSchema,
    onSubmit: (values) => {
      values.customerId = selectedCustomer?._id;
      values.owner = selectedCustomer?.customerFirstName + ' ' + selectedCustomer?.customerLastName;
      values.email = selectedCustomer?.customerEmail;

      delete values._id;
      updateKioskData(
        {
          ...values,
          inventoryUnscented: values?.inventoryUnscented,
          inventoryScented: values.inventoryScented
        },
        params.id
      )
        .then((data) => {
          if (data) {
            toast(params.id ? "'Kiosk Updated Successfully" : 'Kiosk Added Successfully', { type: 'success' });
            navigate('/kiosk');
          }
        })
        .catch((err) => {
          toast(err?.message || 'Error', { type: 'error' });
        });
    }
  });

  const selectedOwner = useMemo(
    () =>
      location.state?.customer?._id
        ? customers.find(({ _id }) => _id === location.state?.customer?._id)
        : customers?.find(({ _id }) => _id === kiosk?.customerId),
    [customers, kiosk?.customerId, location.state?.customer?._id]
  );

  useEffect(() => {
    setSelectedCustomer(selectedOwner);
  }, [selectedOwner]);

  useEffect(() => {
    formik.setFieldValue('email', selectedCustomer?.customerEmail);
  }, [selectedCustomer]);

  useEffect(() => {
    if (fetchingKiosksStatus) return;

    setIsEditMode(!!params.id);

    // const kiosk = kiosks.find((k) => k._id === params.id);
    if (params.id) {
      getKioskDataById(params.id)
        .then((data) => {
          if (!data.isActive) {
            toast('Can not modify the data of de-activated kiosk', { type: 'error' });
            navigate(`/kiosk/${params.id}`);
          }
          setKiosk(data);
          setPhoneNumber(data.phone);
          setSecondaryPhoneNumber(data.phone);
        })
        .catch((err) => {
          toast(err?.message || 'Error', { type: 'error' });
        });
    }
  }, [params.id, fetchingKiosksStatus]);

  const handlePhoneChange = (event) => {
    const val = event.target.value;
    setPhoneNumber(val);
    formik.setFieldValue('onSiteContact.phone', val);
  };

  const handleSecondaryPhoneChange = (event) => {
    const val = event.target.value;
    setSecondaryPhoneNumber(val);
    formik.setFieldValue('onSiteContactSecondary.phone', val);
  };

  const handleStateChange = (event) => {
    if (!kiosk?.kioskId) {
      const kioskId = event.target.value ? `${event.target.value.substring(0, 2).toLowerCase()}-` + newKioskId : newKioskId;
      formik.setFieldValue('kioskId', kioskId);
    }
    // console.log('+++++ kiosk +++', newKioskId);
    formik.setFieldValue('address.state', event.target.value);
  };

  // dont allow view to flicker while loading selected kiosk details
  if (params.id && fetchingKiosksStatus) return <LoadingOutlined />;

  return (
    <>
      <AlertDialog
        open={openDialog}
        setOpen={setOpenDialog}
        title={'Confirm'}
        content={'Are you sure, you want to ' + `${isEditMode ? 'update kiosk info?' : 'add new kiosk?'}`}
        handleConfirm={() => {
          setOpenDialog(false);
          return formik.submitForm();
        }}
      />
      <MainCard>
        <form onSubmit={formik.handleSubmit} id="validation-forms">
          <Grid container spacing={2.5}>
            <Grid item xs={12} sm={5} md={4} lg={3}>
              <MainCard>
                <Grid item xs={12} sm={12}>
                  <Typography variant="h3">Kiosk Info</Typography>
                  <Divider />
                  <Stack spacing={2} paddingY={2}>
                    <CustomTextField name="kioskName" label="Kiosk Name *" formik={formik} accessorName="kioskName" />
                    <CustomTextField
                      name="kioskId"
                      InputProps={{ readOnly: true }}
                      label="Kiosk Id *"
                      formik={formik}
                      accessorName="kioskId"
                      value={formik?.values?.kioskId ? formik.values.kioskId : newKioskId}
                    />
                    <CustomTextField name="deployedLocation" label="Kiosk Location *" formik={formik} accessorName={'deployedLocation'} />
                    <CustomTextField name="locationTag" label="Kiosk Location Tag *" formik={formik} accessorName={'locationTag'} />
                    <TextField
                      id="address.address"
                      name="address.address"
                      label="Address"
                      value={formik.values.address?.address}
                      onChange={formik.handleChange}
                      error={formik.touched?.address?.address && Boolean(formik.errors?.address?.address)}
                      helperText={formik.touched?.address?.address && formik?.errors?.address?.address}
                      fullWidth
                      autoComplete="given-name"
                      padding={2}
                    />
                    <TextField
                      id="address.city"
                      name="address.city"
                      label="City"
                      value={formik.values.address?.city}
                      onChange={formik.handleChange}
                      error={formik.touched?.address?.city && Boolean(formik.errors?.address?.city)}
                      helperText={formik.touched?.address?.city && formik?.errors?.address?.city}
                      fullWidth
                      autoComplete="given-name"
                      padding={2}
                    />
                    <TextField
                      id="address.state"
                      name="address.state"
                      label="State"
                      value={formik.values.address?.state}
                      onChange={handleStateChange}
                      error={formik.touched?.address?.state && Boolean(formik.errors?.address?.state)}
                      helperText={formik.touched?.address?.state && formik?.errors?.address?.state}
                      fullWidth
                      autoComplete="given-name"
                      padding={2}
                    />
                    <TextField
                      id="address.country"
                      name="address.country"
                      label="Country"
                      value={formik.values.address?.country}
                      onChange={formik.handleChange}
                      error={formik.touched?.address?.country && Boolean(formik.errors?.address?.country)}
                      helperText={formik.touched?.address?.country && formik?.errors?.address?.country}
                      fullWidth
                      autoComplete="given-name"
                      padding={2}
                    />
                    <TextField
                      id="address.zip"
                      name="address.zip"
                      label="Zip"
                      value={formik.values.address?.zip}
                      onChange={formik.handleChange}
                      error={formik.touched?.address?.zip && Boolean(formik.errors?.address?.zip)}
                      helperText={formik.touched?.address?.zip && formik?.errors?.address?.zip}
                      fullWidth
                      autoComplete="given-name"
                      padding={2}
                    />
                    <Select
                      labelId="demo-simple-select-label"
                      id="demo-simple-select"
                      value={formik.values.communicationStatus}
                      label="Communication Status"
                      onChange={(e) => formik.setFieldValue('communicationStatus', e.target.value)}
                    >
                      <MenuItem value={true}>Online</MenuItem>
                      <MenuItem value={false}>Offline</MenuItem>
                    </Select>
                    <CustomTextField
                      name="inventoryScented"
                      label="Inventory Scented *"
                      formik={formik}
                      accessorName={'inventoryScented'}
                      disabled={true}
                    />
                    <CustomTextField
                      name="inventoryUnscented"
                      label="Inventory Unscented *"
                      formik={formik}
                      accessorName={'inventoryUnscented'}
                      disabled={true}
                    />
                  </Stack>
                </Grid>
              </MainCard>
            </Grid>
            <Grid item xs={12} sm={7} md={8} lg={9}>
              <Stack spacing={2.5}>
                <MainCard>
                  <Grid item xs={12} sm={12}>
                    <Typography variant="h3">Customer Info</Typography>
                    <Divider />
                    <Stack spacing={2} paddingY={2}>
                      <>
                        <Autocomplete
                          fullWidth
                          id="basic-autocomplete"
                          // disabled={!!location.state?.customer?._id || !!kiosk?.customerId}
                          options={customers}
                          getOptionLabel={(option) => option?.schoolName}
                          onChange={(event, newValue) => {
                            setSelectedCustomer(newValue);
                          }}
                          autoSelect={true}
                          value={selectedCustomer ? selectedCustomer : null}
                          renderInput={(params) => <TextField {...params} placeholder="Select Customer" />}
                        />
                        <CustomTextField
                          name="email"
                          label={isEditMode ? '' : 'Customer Email *'}
                          formik={formik}
                          accessorName={'email'}
                          disabled={true}
                        />
                      </>
                      {/*)}*/}
                    </Stack>
                    <Grid item xs={12} padding={2} />
                    <Typography variant="h3">Site Contact - Primary</Typography>
                    <Grid item xs={12} paddingBottom={2}>
                      <Divider />
                    </Grid>
                    <Stack spacing={2} alignItems="start">
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <TextField
                            id="onSiteContact.firstName"
                            name="onSiteContact.firstName"
                            label="First Name"
                            value={formik.values.onSiteContact?.firstName}
                            onChange={formik.handleChange}
                            error={formik.touched?.onSiteContact?.firstName && Boolean(formik.errors?.onSiteContact?.firstName)}
                            helperText={formik.touched?.onSiteContact?.firstName && formik?.errors?.onSiteContact?.firstName}
                            fullWidth
                            autoComplete="given-name"
                            padding={2}
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            id="onSiteContact.lastName"
                            name="onSiteContact.lastName"
                            label="Last Name"
                            value={formik.values.onSiteContact?.lastName}
                            onChange={formik.handleChange}
                            error={formik.touched?.onSiteContact?.lastName && Boolean(formik.errors?.onSiteContact?.lastName)}
                            helperText={formik.touched?.onSiteContact?.lastName && formik?.errors?.onSiteContact?.lastName}
                            fullWidth
                            autoComplete="given-name"
                            padding={2}
                          />
                        </Grid>
                      </Grid>
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <OutlinedInput
                            onChange={handlePhoneChange}
                            name="onSiteContact.phone"
                            id="onSiteContact.phone"
                            fullWidth
                            value={phoneNumber ?? formik.values.onSiteContact?.phone}
                            inputComponent={TextMaskCustom}
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            id="onSiteContact.email"
                            name="onSiteContact.email"
                            label="Email"
                            value={formik.values.onSiteContact?.email}
                            onChange={formik.handleChange}
                            error={formik.touched?.onSiteContact?.email && Boolean(formik.errors?.onSiteContact?.email)}
                            helperText={formik.touched?.onSiteContact?.email && 'Please enter a valid email address'}
                            fullWidth
                            autoComplete="given-name"
                            padding={2}
                          />
                        </Grid>
                      </Grid>
                    </Stack>
                    <Grid item xs={12} padding={2} />
                    <Typography variant="h3">Site Contact - Secondary</Typography>
                    <Grid item xs={12} paddingBottom={2}>
                      <Divider />
                    </Grid>
                    <Stack spacing={2} alignItems="start">
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <TextField
                            id="onSiteContactSecondary.firstName"
                            name="onSiteContactSecondary.firstName"
                            label="First Name"
                            value={formik.values.onSiteContactSecondary?.firstName}
                            onChange={formik.handleChange}
                            error={
                              formik.touched?.onSiteContactSecondary?.firstName && Boolean(formik.errors?.onSiteContactSecondary?.firstName)
                            }
                            helperText={
                              formik.touched?.onSiteContactSecondary?.firstName && formik?.errors?.onSiteContactSecondary?.firstName
                            }
                            fullWidth
                            autoComplete="given-name"
                            padding={2}
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            id="onSiteContactSecondary.lastName"
                            name="onSiteContactSecondary.lastName"
                            label="Last Name"
                            value={formik.values.onSiteContactSecondary?.lastName}
                            onChange={formik.handleChange}
                            error={
                              formik.touched?.onSiteContactSecondary?.lastName && Boolean(formik.errors?.onSiteContactSecondary?.lastName)
                            }
                            helperText={
                              formik.touched?.onSiteContactSecondary?.lastName && formik?.errors?.onSiteContactSecondary?.lastName
                            }
                            fullWidth
                            autoComplete="given-name"
                            padding={2}
                          />
                        </Grid>
                      </Grid>
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <OutlinedInput
                            onChange={handleSecondaryPhoneChange}
                            name="onSiteContactSecondary.phone"
                            id="onSiteContactSecondary.phone"
                            fullWidth
                            value={secondaryPhoneNumber ?? formik.values.onSiteContactSecondary?.phone}
                            inputComponent={TextMaskCustom}
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <TextField
                            id="onSiteContactSecondary.email"
                            name="onSiteContactSecondary.email"
                            label="Email"
                            value={formik.values.onSiteContactSecondary?.email}
                            onChange={formik.handleChange}
                            error={formik.touched?.onSiteContactSecondary?.email && Boolean(formik.errors?.onSiteContactSecondary?.email)}
                            helperText={formik.touched?.onSiteContactSecondary?.email && 'Please enter a valid email address'}
                            fullWidth
                            autoComplete="given-name"
                            padding={2}
                          />
                        </Grid>
                      </Grid>
                    </Stack>

                    <Grid item xs={12} padding={3} />
                    <Typography variant="h3">Machine Info</Typography>
                    <Grid item xs={12} paddingBottom={2}>
                      <Divider />
                    </Grid>
                    <Stack spacing={2} alignItems="start">
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <CustomTextField name="macId" label="MAC ID" formik={formik} accessorName={'macId'} />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <CustomTextField name="resolution" label="Resolution" formik={formik} accessorName={'resolution'} />
                        </Grid>
                      </Grid>
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <CustomTextField name="sbcHWVersion" label="SBC Hardware Version" formik={formik} accessorName={'sbcHWVersion'} />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <CustomTextField name="sbcSWVersion" label="SBC Software Version" formik={formik} accessorName={'sbcSWVersion'} />
                        </Grid>
                      </Grid>
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <CustomTextField name="mcbHWVersion" label="MCB Hardware Version" formik={formik} accessorName={'mcbHWVersion'} />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <CustomTextField name="mcbSWVersion" label="MCB Software Version" formik={formik} accessorName={'mcbSWVersion'} />
                        </Grid>
                      </Grid>
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <CustomTextField
                            name="motorHWVersion"
                            label="Motor Hardware Version"
                            formik={formik}
                            accessorName={'motorHWVersion'}
                          />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                          <CustomTextField
                            name="motorSWVersion"
                            label="Motor Software Version"
                            formik={formik}
                            accessorName={'motorSWVersion'}
                          />
                        </Grid>
                      </Grid>
                      <Grid container>
                        <Grid item xs={12} sm={6} paddingRight={1}>
                          <CustomTextField name="screen" label="Screen" formik={formik} accessorName={'screen'} />
                        </Grid>
                      </Grid>
                    </Stack>
                  </Grid>
                </MainCard>
              </Stack>
            </Grid>
            <Grid item xs={12}>
              <Stack direction="row" justifyContent="center">
                <AnimateButton>
                  <Button variant="contained" sx={{ my: 3, ml: 1 }} type="button" onClick={() => setOpenDialog(true)}>
                    {isEditMode ? 'Update' : 'Create'}
                  </Button>
                </AnimateButton>
              </Stack>
            </Grid>
          </Grid>
        </form>
      </MainCard>
    </>
  );
};

export default AddEditKiosk;
