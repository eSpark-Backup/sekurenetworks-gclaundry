import PropTypes from 'prop-types';
import { Fragment, useCallback, useEffect, useMemo, useState } from 'react';

// material-ui
import { alpha, useTheme } from '@mui/material/styles';
import {
  Alert,
  Badge,
  Button,
  LinearProgress,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
  useMediaQuery
} from '@mui/material';

// third-party
import { useExpanded, useFilters, useGlobalFilter, usePagination, useSortBy, useTable } from 'react-table';

// project import
import KioskRowView from 'sections/kiosk/KioskRowView';
import IconButton from 'components/@extended/IconButton';
import MainCard from 'components/MainCard';
import ScrollX from 'components/ScrollX';
import { GlobalFilter, renderFilterTypes } from 'utils/react-table';
import { HeaderSort, TablePagination } from 'components/third-party/ReactTable';

// assets
import { CloseOutlined, EditTwoTone, EyeTwoTone, FileTextOutlined, PlusOutlined } from '@ant-design/icons';
import Mailto from '../../components/Mailto';
import { useKiosk } from '../../contexts/KioskContext';
import { useNavigate } from 'react-router-dom';
import { useParams } from 'react-router';
import { useCustomer } from '../../contexts/CustomersContext';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import { getErrors } from '../../utils/commonFunctions';

// ==============================|| REACT TABLE ||============================== //

const NUMBER_OF_ROWS = 25;

function ReactTable({ columns, data, getHeaderProps, renderRowSubComponent, handleAdd }) {
  const theme = useTheme();
  const matchDownSM = useMediaQuery(theme.breakpoints.down('sm'));

  const filterTypes = useMemo(() => renderFilterTypes, []);
  const sortBy = { id: 'kioskName', desc: false };

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    setHiddenColumns,
    visibleColumns,
    rows,
    // @ts-ignore
    page,
    // @ts-ignore
    gotoPage,
    // @ts-ignore
    setPageSize,
    // @ts-ignore
    state: { globalFilter, pageIndex, pageSize },
    // @ts-ignore
    preGlobalFilteredRows,
    // @ts-ignore
    setGlobalFilter
    // @ts-ignore
  } = useTable(
    {
      columns,
      data,
      // @ts-ignore
      filterTypes,
      // @ts-ignore
      initialState: {
        pageIndex: 0,
        pageSize: NUMBER_OF_ROWS,
        sortBy: [sortBy],
        hiddenColumns: ['onSiteContact.email', 'onSiteContact.firstName', 'onSiteContact.lastName']
      }
    },
    useGlobalFilter,
    useFilters,
    useSortBy,
    useExpanded,
    usePagination
  );

  useEffect(() => {
    if (matchDownSM) {
      setHiddenColumns(['age', 'contact', 'visits', 'email', 'status']);
    } else {
      setHiddenColumns(['avatar', 'email']);
    }
    // eslint-disable-next-line
  }, [matchDownSM]);

  return (
    <>
      <Stack spacing={3}>
        <Stack
          direction={matchDownSM ? 'column' : 'row'}
          justifyContent="space-between"
          alignItems="center"
          spacing={1}
          sx={{ p: 3, pb: 0 }}
        >
          <GlobalFilter
            preGlobalFilteredRows={preGlobalFilteredRows}
            globalFilter={globalFilter}
            setGlobalFilter={setGlobalFilter}
            size="small"
          />
          <Stack direction={matchDownSM ? 'column' : 'row'} alignItems="center" spacing={1}>
            {/*<SortingSelect sortBy={sortBy.id} setSortBy={setSortBy} allColumns={allColumns} />*/}
            <Button variant="contained" startIcon={<PlusOutlined />} onClick={handleAdd}>
              Add Kiosk
            </Button>
          </Stack>
        </Stack>

        <Table {...getTableProps()}>
          <TableHead>
            {headerGroups.map((headerGroup, i) => (
              <TableRow key={i} {...headerGroup.getHeaderGroupProps()} sx={{ '& > th:first-of-type': { width: '58px' } }}>
                {headerGroup.headers.map((column, index) => (
                  <TableCell key={index} {...column.getHeaderProps([{ className: column.className }, getHeaderProps(column)])}>
                    <HeaderSort column={column} />
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableHead>
          <TableBody {...getTableBodyProps()}>
            {page.map((row, i) => {
              prepareRow(row);
              const rowProps = row.getRowProps();

              return (
                <Fragment key={i}>
                  <TableRow
                    {...row.getRowProps()}
                    sx={{
                      cursor: 'pointer',
                      bgcolor: !row.original?.isActive
                        ? alpha(theme.palette.secondary.light, 0.5)
                        : parseFloat(row.values?.inventoryScented?.replace('%', '')) < 15 ||
                          parseFloat(row.values?.inventoryUnscented?.replace('%', '')) < 15
                        ? alpha(theme.palette.warning.light, 0.35)
                        : 'inherit'
                    }}
                  >
                    {row.cells.map((cell, index) => (
                      <TableCell key={index} {...cell.getCellProps([{ className: cell.column.className }])}>
                        {cell.render('Cell')}
                      </TableCell>
                    ))}
                  </TableRow>
                  {row.isExpanded && renderRowSubComponent({ row, rowProps, visibleColumns })}
                </Fragment>
              );
            })}
            <TableRow sx={{ '&:hover': { bgcolor: 'transparent !important' } }}>
              <TableCell sx={{ p: 2, py: 3 }} colSpan={9}>
                <TablePagination gotoPage={gotoPage} rows={rows} setPageSize={setPageSize} pageSize={pageSize} pageIndex={pageIndex} />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Stack>
    </>
  );
}

ReactTable.propTypes = {
  columns: PropTypes.array,
  data: PropTypes.array,
  getHeaderProps: PropTypes.func,
  handleAdd: PropTypes.func,
  renderRowSubComponent: PropTypes.any
};

// ==============================|| KIOSK - LIST VIEW ||============================== //

const CellKioskDetails = ({ row }) => {
  const { values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Stack spacing={0}>
        <Typography variant="subtitle1">{`${values?.onSiteContact?.firstName || '-'} ${values?.onSiteContact?.lastName || ''}`}</Typography>
        <Typography variant="subtitle2" color="textSecondary">
          <Mailto email={values?.onSiteContact?.email} />
        </Typography>
      </Stack>
    </Stack>
  );
};

const CellKioskErrors = ({ row }) => {
  const { values } = row;
  const errors = getErrors(values);
  return (
    <Tooltip title={errors.length ? <div style={{ whiteSpace: 'pre-line' }}>{errors.join('\n')}</div> : 'No Error'} arrow>
      <div style={{ display: 'flex', justifyContent: 'center' }}>{errors.length ? <WarningAmberIcon color={'error'} /> : '-'}</div>
    </Tooltip>
  );
};

const Actions = ({ theme, toggleRowExpanded, collapseIcon, values, setKiosk }) => {
  const navigate = useNavigate();
  return (
    <>
      <Tooltip title="Detail">
        <IconButton
          color="primary"
          onClick={(e) => {
            e.stopPropagation();
            navigate(`/kiosk/${values?._id}`);
          }}
        >
          <FileTextOutlined twoToneColor={theme.palette.primary.main} />
        </IconButton>
      </Tooltip>
      <Tooltip title="Quick View">
        <IconButton
          color="secondary"
          onClick={(e) => {
            e.stopPropagation();
            toggleRowExpanded();
          }}
        >
          {collapseIcon}
        </IconButton>
      </Tooltip>
      <Tooltip title="Edit">
        <IconButton
          color="primary"
          onClick={(e) => {
            e.stopPropagation();
            setKiosk(values);

            navigate(`/kiosk/edit/${values?._id}`);
          }}
        >
          <EditTwoTone twoToneColor={theme.palette.primary.main} />
        </IconButton>
      </Tooltip>
    </>
  );
};

CellKioskDetails.propTypes = {
  row: PropTypes.object
};

const CellActions = ({ row }) => {
  const theme = useTheme();
  const collapseIcon = row.isExpanded ? (
    <CloseOutlined style={{ color: theme.palette.error.main }} />
  ) : (
    <EyeTwoTone twoToneColor={theme.palette.secondary.main} />
  );
  return (
    <Stack direction="row" alignItems="center" justifyContent="center" spacing={0}>
      <Actions theme={theme} toggleRowExpanded={toggleRowExpanded} collapseIcon={collapseIcon} values={values} />
    </Stack>
  );
};

CellActions.propTypes = {
  row: PropTypes.object
};

const KioskList = ({ filter = '' }) => {
  const navigate = useNavigate();
  const theme = useTheme();
  const { kiosks: kioskList, fetchKiosks, fetchingKiosksStatus } = useKiosk();

  const kiosks = useMemo(
    () =>
      filter === ''
        ? kioskList
        : kioskList?.filter((kiosk) =>
            filter === 'low-inventory'
              ? parseFloat(kiosk.inventoryScented?.replace('%', '')) < 15 || parseFloat(kiosk.inventoryUnscented?.replace('%', '')) < 15
              : kiosk.communicationStatus === (filter === 'online')
          ),
    [kioskList, filter]
  );

  const [, setKiosk] = useState(null);

  const { customers } = useCustomer();
  const params = useParams();

  // only used to refresh kiosks list
  useEffect(() => {
    fetchKiosks();
  }, [filter]);

  // const data = useMemo(() => makeKioskData(200), []);
  const { customerKiosks, customer } = useMemo(() => {
    if (!params.id) return { customerKiosks: null, customer: null };

    const customer = customers?.find((k) => k?._id === params.id);

    if (!customer) return { customerKiosks: null, customer: null };

    return {
      customer,
      customerKiosks: kiosks?.filter((k) => customer?.kioskIds?.includes(k?._id)) ?? []
    };
  }, [kiosks, params.id, customers]);

  const handleAdd = () => {
    // if (kiosk && !add) setKiosk(null);
    const props = { state: customer ? { customer } : undefined };
    navigate(`/kiosk/new`, props);
  };

  const columns = useMemo(
    () => [
      {
        Header: 'Name',
        accessor: 'kioskName',
        disableSortBy: true,
        Cell: ({ value }) => <Typography variant="subtitle2">{value}</Typography>
      },
      {
        accessor: '_id',
        disableSortBy: true,
        Cell: () => null
      },
      {
        Header: 'Location',
        accessor: 'deployedLocation'
      },
      {
        Header: 'School-Customer',
        accessor: 'customerId',
        Cell: ({ value }) => (
          <div>
            <span>{value.schoolName}</span>
          </div>
        )
      },
      {
        Header: 'Email',
        accessor: 'email'
      },
      {
        accessor: 'onSiteContact.email',
        disableSortBy: true,
        Cell: () => null
      },
      {
        accessor: 'onSiteContact.firstName',
        disableSortBy: true,
        Cell: () => null
      },
      {
        accessor: 'onSiteContact.lastName',
        disableSortBy: true,
        Cell: () => null
      },
      {
        Header: 'Contact',
        accessor: 'onSiteContact',
        // eslint-disable-next-line
        Cell: CellKioskDetails,
        disableSortBy: true
      },
      {
        Header: 'Scented',
        accessor: 'inventoryScented',
        disableSortBy: true,
        Cell: ({ value }) => <Typography>{value}</Typography>
      },
      {
        Header: 'Unscented',
        accessor: 'inventoryUnscented',
        disableSortBy: true,
        Cell: ({ value }) => <Typography>{value}</Typography>
      },
      {
        Header: 'Error',
        accessor: 'error',
        disableSortBy: true,
        // eslint-disable-next-line
        Cell: CellKioskErrors
      },
      {
        Header: 'Status',
        accessor: 'communicationStatus',
        disableSortBy: true,
        align: 'center',
        // eslint-disable-next-line
        Cell: ({ value }) => {
          return (
            <Tooltip title={value ? 'Online' : 'Offline'} arrow>
              <div style={{ display: 'flex', justifyContent: 'center' }}>
                <Badge color={value ? 'success' : 'error'} badgeContent={''} />
              </div>
            </Tooltip>
          );
        }
      },
      {
        Header: 'Actions',
        className: 'cell-center',
        disableSortBy: true,
        // eslint-disable-next-line
        Cell: ({ row }) => {
          const theme = useTheme();
          // eslint-disable-next-line
          const { values, isExpanded, toggleRowExpanded } = row;
          const collapseIcon = isExpanded ? (
            <CloseOutlined style={{ color: theme.palette.error.main }} />
          ) : (
            <EyeTwoTone twoToneColor={theme.palette.secondary.main} />
          );
          return (
            <Stack direction="row" alignItems="center" justifyContent="center" spacing={0}>
              <Actions
                theme={theme}
                toggleRowExpanded={toggleRowExpanded}
                collapseIcon={collapseIcon}
                values={values}
                setKiosk={setKiosk}
              />
            </Stack>
          );
        }
      }
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [theme]
  );

  const renderRowSubComponent = useCallback(({ row }) => <KioskRowView data={kiosks[row.id]} />, [kiosks]);

  return (
    <MainCard content={false}>
      {fetchingKiosksStatus ? (
        <LinearProgress />
      ) : (
        <ScrollX>
          {kiosks?.length > 0 ? (
            <ReactTable
              columns={columns}
              data={customerKiosks ?? kiosks ?? []}
              handleAdd={handleAdd}
              getHeaderProps={(column) => column.getSortByToggleProps()}
              renderRowSubComponent={renderRowSubComponent}
            />
          ) : (
            <Alert color="warning">No Kiosk. Please try refreshing the page.</Alert>
          )}
        </ScrollX>
      )}
    </MainCard>
  );
};

KioskList.propTypes = {
  filter: PropTypes.string
};
export default KioskList;
