import { useParams } from 'react-router';
import { useEffect, useMemo, useState } from 'react';
import { useKiosk } from '../../contexts/KioskContext';
import { useNavigate } from 'react-router-dom';
import MainCard from '../../components/MainCard';
import { Alert, Button, Chip, Divider, Grid, Stack, Switch, Typography } from '@mui/material';
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import AlertDialog from '../../components/@extended/AlertDialog';
import { deleteKioskData, getKioskDataById, updateKioskStatus } from '../../_api/kiosk';
import { toast } from 'react-toastify';
import { styled } from '@mui/material/styles';
import { format } from 'date-fns';
import config from '../../config';
import { getErrors } from '../../utils/commonFunctions';
import { getCustomersDataById } from '../../_api/customer';

const Detail = () => {
  const params = useParams();
  const navigate = useNavigate();
  const { fetchingKiosksStatus } = useKiosk();

  const [kiosk, setKiosk] = useState(null);
  const [isActive, setIsActive] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [openActivateDialog, setOpenActivateDialog] = useState(false);
  const [selectedOwner, setSelectedOwner] = useState();
  const selectedOwnerName = useMemo(
    () => (selectedOwner?.customerFirstName ?? '') + ' ' + (selectedOwner?.customerLastName ?? ''),
    [selectedOwner]
  );
  const selectedOwnerEmail = useMemo(() => selectedOwner?.customerEmail, [selectedOwner]);
  useEffect(() => {
    if (fetchingKiosksStatus) return;

    // lookup id
    getKioskDataById(params.id)
      .then((res) => {
        setKiosk(res);
        setIsActive(res?.isActive);
        getCustomersDataById(res?.customerId).then((res) => {
          if (res) setSelectedOwner(res);
        });
      })
      .catch(() => {
        navigate('/kiosk');
      });
  }, [params.id, fetchingKiosksStatus]);

  if (!kiosk) return null;

  const onSiteContactName = (kiosk?.onSiteContact?.firstName || '') + ' ' + (kiosk?.onSiteContact?.lastName || '');
  const onSiteSecondaryContactName =
    (kiosk?.onSiteContactSecondary?.firstName || '') + ' ' + (kiosk?.onSiteContactSecondary?.lastName || '');

  function handleDelete() {
    setOpenDialog(true);
  }

  const IOSSwitch = styled((props) => <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} />)(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
      padding: 0,
      margin: 2,
      transitionDuration: '300ms',
      '&.Mui-checked': {
        transform: 'translateX(16px)',
        color: '#fff',
        '& + .MuiSwitch-track': {
          backgroundColor: theme.palette.mode === 'dark' ? '#2ECA45' : '#65C466',
          opacity: 1,
          border: 0
        },
        '&.Mui-disabled + .MuiSwitch-track': {
          opacity: 0.5
        }
      },
      '&.Mui-focusVisible .MuiSwitch-thumb': {
        color: '#33cf4d',
        border: '6px solid #fff'
      },
      '&.Mui-disabled .MuiSwitch-thumb': {
        color: theme.palette.mode === 'light' ? theme.palette.grey[100] : theme.palette.grey[600]
      },
      '&.Mui-disabled + .MuiSwitch-track': {
        opacity: theme.palette.mode === 'light' ? 0.7 : 0.3
      }
    },
    '& .MuiSwitch-thumb': {
      boxSizing: 'border-box',
      width: 22,
      height: 22
    },
    '& .MuiSwitch-track': {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === 'light' ? '#E9E9EA' : '#39393D',
      opacity: 1,
      transition: theme.transitions.create(['background-color'], {
        duration: 500
      })
    }
  }));

  const handleSwitch = (event) => {
    setIsActive(event.target.checked);
    setOpenActivateDialog(true);
  };

  const errors = getErrors(kiosk);

  return (
    <>
      <AlertDialog
        open={openDialog}
        setOpen={setOpenDialog}
        title={'Confirm'}
        content={'Are you sure, you want to delete kiosk?'}
        handleConfirm={() => {
          deleteKioskData(kiosk._id)
            .then(() => {
              toast('Kiosk deleted successfully', { type: 'success' });
              navigate('/kiosk');
            })
            .catch((err) => {
              toast.error(err.message);
            });
        }}
      />
      <AlertDialog
        open={openActivateDialog}
        setOpen={setOpenActivateDialog}
        title={'Confirm'}
        content={'Are you sure, you want to proceed?'}
        handleConfirm={() => {
          updateKioskStatus(
            {
              isActive: isActive
            },
            params.id
          )
            .then((data) => {
              if (data) {
                toast(!isActive ? 'Kiosk is de-activated successfully' : 'Kiosk is activated successfully', { type: 'success' });
                setOpenActivateDialog(false);
              }
            })
            .catch((err) => {
              setIsActive(isActive);
              setOpenActivateDialog(false);
              toast(err?.message || 'Error', { type: 'error' });
            });
        }}
        handleClose={() => {
          setIsActive(!isActive);
          setOpenActivateDialog(false);
        }}
      />
      <MainCard>
        <Stack direction="row-reverse" spacing={3} alignItems="center" justifyContent="end" marginBottom={1}>
          <Stack spacing={3} alignItems="end">
            <Button
              disabled={!isActive}
              variant="contained"
              startIcon={<EditOutlined />}
              onClick={() => navigate(`/kiosk/edit/${params?.id}`)}
            >
              Edit
            </Button>
          </Stack>
          <Stack direction="row" spacing={2} alignItems="end">
            <Typography>Deactivate</Typography>
            <IOSSwitch inputProps={{ 'aria-label': 'ant design' }} checked={isActive} onChange={handleSwitch} />
            <Typography>Activate</Typography>
          </Stack>
        </Stack>

        <Grid container spacing={2.5}>
          <Grid item xs={12} sm={5} md={4} lg={3}>
            <MainCard>
              <Grid container spacing={3}>
                <Grid item xs={12}>
                  <Stack spacing={2.5} alignItems="center">
                    <Stack spacing={0.5} alignItems="center">
                      <Typography variant="h2">{kiosk?.kioskName || ''}</Typography>
                      <Typography variant="h5">{kiosk?.kioskId || ''}</Typography>
                      <Typography variant="h5">{kiosk?.deployedLocation || ''}</Typography>
                      <Typography variant="h5">{kiosk?.locationTag || ''}</Typography>
                      <Typography variant="h5" align={'center'}>
                        {kiosk?.address.address +
                          ', ' +
                          kiosk?.address.city +
                          ', ' +
                          kiosk?.address.state +
                          ', ' +
                          kiosk?.address.country +
                          ', ' +
                          kiosk?.address.zip || ''}
                      </Typography>
                    </Stack>
                    <Chip
                      label={kiosk?.communicationStatus ? 'Online' : 'Offline'}
                      color={kiosk?.communicationStatus ? 'success' : 'error'}
                    />
                  </Stack>
                  <Stack spacing={0.5} paddingTop={2} alignItems="center">
                    <Typography variant={'caption'} align={'center'}>
                      {kiosk?.checkInTime
                        ? `Last check-in: ${format(new Date(Date.parse(kiosk?.checkInTime)), config.dateFormat)?.toLocaleString()}`
                        : 'No check-in yet'}
                    </Typography>
                  </Stack>
                </Grid>
                <Grid item xs={12}>
                  <Divider />
                </Grid>
                <Grid item xs={12}>
                  <Stack direction="row" justifyContent="space-around" alignItems="center">
                    <Divider orientation="vertical" flexItem />
                    <Stack spacing={0.5} alignItems="center">
                      <Typography variant="h5">Scented</Typography>
                      <Typography color="secondary" variant="h2">
                        {kiosk?.inventoryScented || '0%'}
                      </Typography>
                    </Stack>
                    <Divider orientation="vertical" flexItem />
                    <Stack spacing={0.5} alignItems="center">
                      <Typography variant="h5">Unscented</Typography>
                      <Typography color="secondary" variant="h2">
                        {kiosk?.inventoryUnscented || '0%'}
                      </Typography>
                    </Stack>
                    <Divider orientation="vertical" flexItem />
                  </Stack>
                </Grid>
                <Grid item xs={12}>
                  <Divider />
                </Grid>
              </Grid>
            </MainCard>
          </Grid>
          <Grid item xs={12} sm={7} md={8} lg={9}>
            <Stack spacing={2.5}>
              <MainCard>
                <Grid container>
                  {onSiteContactName && (
                    <Grid item xs={12} md={6}>
                      <Stack spacing={0.5} alignItems="start" direction="column">
                        <Typography variant="h3">Customer Info</Typography>
                        <Divider />
                        <Typography variant="h5">{selectedOwnerName.trim() || '-'}</Typography>
                        <Typography variant="h5">{selectedOwnerEmail || '-'}</Typography>
                      </Stack>
                    </Grid>
                  )}
                  {onSiteSecondaryContactName && (
                    <Grid item xs={12} md={6}>
                      <Stack spacing={0.5} alignItems="end" direction="column">
                        {errors.map((error) => (
                          <Alert key={error} severity="warning" color={'error'}>
                            {error}
                          </Alert>
                        ))}
                      </Stack>
                    </Grid>
                  )}
                </Grid>
                <Grid item xs={12} padding={3}>
                  <Divider />
                </Grid>
                <Grid container>
                  {onSiteContactName && (
                    <Grid item xs={12} md={6}>
                      <Stack spacing={0.5} alignItems="start" direction="column">
                        <Typography variant="h3">Site Contact - Primary</Typography>
                        <Divider />
                        <Typography variant="h5">{onSiteContactName}</Typography>
                        <Typography variant="h5">{kiosk?.onSiteContact?.phone || ''}</Typography>
                        <Typography variant="h5">{kiosk?.onSiteContact?.email || ''}</Typography>
                      </Stack>
                    </Grid>
                  )}
                  {onSiteSecondaryContactName && (
                    <Grid item xs={12} md={6}>
                      <Stack spacing={0.5} alignItems="start" direction="column">
                        <Typography variant="h3">Site Contact - Secondary</Typography>
                        <Divider />
                        <Typography variant="h5">{onSiteSecondaryContactName}</Typography>
                        <Typography variant="h5">{kiosk?.onSiteContactSecondary?.phone || ''}</Typography>
                        <Typography variant="h5">{kiosk?.onSiteContactSecondary?.email || ''}</Typography>
                      </Stack>
                    </Grid>
                  )}
                </Grid>
              </MainCard>
            </Stack>
            <Stack spacing={2.5}>
              <MainCard>
                <Stack spacing={0.5} alignItems="start">
                  <Typography variant="h3">Machine Info</Typography>
                  <Divider />
                  <Grid container>
                    <Grid item xs={12} md={6}>
                      <Stack spacing={0.5}>
                        <Typography variant="h5">{'MAC ID: ' + kiosk?.macId || ''}</Typography>
                        <Typography variant="h5">{'SBC Hardware Version: ' + kiosk?.sbcHWVersion || ''}</Typography>
                        <Typography variant="h5">{'Motor Hardware Version: ' + kiosk?.motorHWVersion || ''}</Typography>
                        <Typography variant="h5">{'MCB Hardware Version: ' + kiosk?.mcbHWVersion || ''}</Typography>
                        <Typography variant="h5">{'Screen: ' + kiosk?.screen || ''}</Typography>
                      </Stack>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Stack spacing={0.5}>
                        <Typography variant="h5">{'Resolution: ' + kiosk?.resolution || ''}</Typography>
                        <Typography variant="h5">{'SBC Software Version: ' + kiosk?.sbcSWVersion || ''}</Typography>
                        <Typography variant="h5">{'Motor Software Version: ' + kiosk?.motorSWVersion || ''}</Typography>
                        <Typography variant="h5">{'MCB Software Version: ' + kiosk?.mcbSWVersion || ''}</Typography>
                      </Stack>
                    </Grid>
                  </Grid>
                </Stack>
              </MainCard>
            </Stack>
          </Grid>
        </Grid>
      </MainCard>

      <Stack alignItems="center" spacing={1} paddingTop={1}>
        {/*<SortingSelect sortBy={sortBy.id} setSortBy={setSortBy} allColumns={allColumns} />*/}
        <Button variant="contained" startIcon={<DeleteOutlined />} onClick={handleDelete}>
          Delete
        </Button>
      </Stack>
    </>
  );
};

export default Detail;
