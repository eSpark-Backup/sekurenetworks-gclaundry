import PropTypes from 'prop-types';
import { Fragment, useCallback, useEffect, useMemo, useState } from 'react';

// material-ui
import { alpha, useTheme } from '@mui/material/styles';
import {
  Alert,
  LinearProgress,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Tooltip,
  Typography,
  useMediaQuery
} from '@mui/material';

// third-party
import { useExpanded, useFilters, useGlobalFilter, usePagination, useSortBy, useTable } from 'react-table';

// project import
import IconButton from 'components/@extended/IconButton';
import MainCard from 'components/MainCard';
import ScrollX from 'components/ScrollX';
import { GlobalFilter, renderFilterTypes } from 'utils/react-table';
import { HeaderSort, TablePagination } from 'components/third-party/ReactTable';

// assets
import Mailto from '../../components/Mailto';
import { useClient } from '../../contexts/ClientsContext';
import { CloseOutlined, EyeTwoTone } from '@ant-design/icons';
import ClientRowView from '../../sections/Client/ClientRowView';
import { getClientData } from '../../_api/client';

// ==============================|| REACT TABLE ||============================== //

const NUMBER_OF_ROWS = 25;

function ReactTable({ columns, data, getHeaderProps, renderRowSubComponent }) {
  const theme = useTheme();
  const matchDownSM = useMediaQuery(theme.breakpoints.down('sm'));

  const filterTypes = useMemo(() => renderFilterTypes, []);
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    prepareRow,
    visibleColumns,
    rows,
    // @ts-ignore
    page,
    // @ts-ignore
    gotoPage,
    // @ts-ignore
    setPageSize,
    // @ts-ignore
    state: { globalFilter, pageIndex, pageSize },
    // @ts-ignore
    preGlobalFilteredRows,
    // @ts-ignore
    setGlobalFilter
    // @ts-ignore
  } = useTable(
    {
      columns,
      data,
      // @ts-ignore
      filterTypes,
      // @ts-ignore
      initialState: {
        pageIndex: 0,
        pageSize: NUMBER_OF_ROWS,
        hiddenColumns: ['last_name', 'email']
      }
    },
    useGlobalFilter,
    useFilters,
    useSortBy,
    useExpanded,
    usePagination
  );

  return (
    <>
      <Stack spacing={3}>
        <Stack
          direction={matchDownSM ? 'column' : 'row'}
          justifyContent="space-between"
          alignItems="center"
          spacing={1}
          sx={{ p: 3, pb: 0 }}
        >
          <GlobalFilter
            preGlobalFilteredRows={preGlobalFilteredRows}
            globalFilter={globalFilter}
            setGlobalFilter={setGlobalFilter}
            size="small"
          />
        </Stack>

        <Table {...getTableProps()}>
          <TableHead>
            {headerGroups.map((headerGroup, i) => (
              <TableRow key={i} {...headerGroup.getHeaderGroupProps()} sx={{ '& > th:first-of-type': { width: '58px' } }}>
                {headerGroup.headers.map((column, index) => (
                  <TableCell key={index} {...column.getHeaderProps([{ className: column.className }, getHeaderProps(column)])}>
                    <HeaderSort column={column} />
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableHead>
          <TableBody {...getTableBodyProps()}>
            {page.map((row, i) => {
              prepareRow(row);
              const rowProps = row.getRowProps();

              return (
                <Fragment key={i}>
                  <TableRow
                    {...row.getRowProps()}
                    sx={{
                      cursor: 'pointer',
                      bgcolor:
                        row.values?.inventoryScented < 15 || row.values?.inventoryUnscented < 15
                          ? alpha(theme.palette.warning.light, 0.35)
                          : 'inherit'
                    }}
                  >
                    {row.cells.map((cell, index) => (
                      <TableCell key={index} {...cell.getCellProps([{ className: cell.column.className }])}>
                        {cell.render('Cell')}
                      </TableCell>
                    ))}
                  </TableRow>
                  {row.isExpanded && renderRowSubComponent({ row, rowProps, visibleColumns })}
                </Fragment>
              );
            })}
            <TableRow sx={{ '&:hover': { bgcolor: 'transparent !important' } }}>
              <TableCell sx={{ p: 2, py: 3 }} colSpan={9}>
                <TablePagination gotoPage={gotoPage} rows={rows} setPageSize={setPageSize} pageSize={pageSize} pageIndex={pageIndex} />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Stack>
    </>
  );
}

ReactTable.propTypes = {
  columns: PropTypes.array,
  data: PropTypes.array,
  getHeaderProps: PropTypes.func,
  renderRowSubComponent: PropTypes.any
};

// ==============================|| CLIENTS - LIST VIEW ||============================== //

const CellContactDetails = ({ row }) => {
  const { original: values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Stack spacing={0}>
        <Typography variant="subtitle1">{`${values?.tel}`}</Typography>
        <Typography variant="subtitle1" color="textSecondary">
          <Mailto email={values?.email} />
        </Typography>
      </Stack>
    </Stack>
  );
};

const CellClientName = ({ row }) => {
  const { original: values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Typography variant="subtitle1">{`${values?.first_name} ${values?.last_name}`}</Typography>
    </Stack>
  );
};

const CellInstitution = ({ row }) => {
  const { original: values } = row;
  return (
    <Stack direction="row" spacing={1.5} alignItems="center">
      <Stack spacing={0}>
        <Typography variant="subtitle1">{`${values?.school}`}</Typography>
      </Stack>
    </Stack>
  );
};

const Actions = ({ toggleRowExpanded, collapseIcon }) => {
  return (
    <>
      <Tooltip title="Quick View">
        <IconButton
          color="secondary"
          onClick={(e) => {
            e.stopPropagation();
            toggleRowExpanded();
          }}
        >
          {collapseIcon}
        </IconButton>
      </Tooltip>
    </>
  );
};

CellContactDetails.propTypes = {
  row: PropTypes.object
};

const CellActions = ({ row }) => {
  const theme = useTheme();
  const collapseIcon = row.isExpanded ? (
    <CloseOutlined style={{ color: theme.palette.error.main }} />
  ) : (
    <EyeTwoTone twoToneColor={theme.palette.secondary.main} />
  );
  return (
    <Stack direction="row" alignItems="center" justifyContent="center" spacing={0}>
      <Actions theme={theme} toggleRowExpanded={toggleRowExpanded} collapseIcon={collapseIcon} values={values} />
    </Stack>
  );
};

CellActions.propTypes = {
  row: PropTypes.object
};

const ClientsList = () => {
  const theme = useTheme();
  const { clients, setClients, loadingClients } = useClient();

  const [, setClient] = useState(null);

  // useEffect(() => {
  //     // fake async call
  //     if (!data.length) setClients(makeClientsData(20));
  // }, []);

  useEffect(() => {
    getClientData().then((data) => {
      data && setClients(data);
    });
  }, []);

  const columns = useMemo(
    () => [
      {
        Header: 'No',
        id: 'id',
        Cell: ({ row, flatRows }) => {
          return <Typography variant="subtitle1">{flatRows.indexOf(row) + 1}</Typography>;
        },
        disableSortBy: true
      },
      {
        Header: 'Name',
        accessor: 'first_name',
        Cell: CellClientName
      },
      {
        accessor: 'last_name'
      },
      {
        Header: 'Institution',
        accessor: 'school',
        Cell: CellInstitution
      },
      {
        Header: 'Contact',
        accessor: 'tel',
        Cell: CellContactDetails
      },
      {
        accessor: 'email'
      },
      {
        Header: 'Gender',
        accessor: 'gender'
      },
      {
        Header: 'Quantity',
        accessor: 'quantity'
      },
      {
        Header: 'Scents',
        accessor: 'scenti'
      },
      {
        Header: 'Subscription',
        accessor: 'subscription'
      },
      {
        Header: 'Actions',
        className: 'cell-center',
        disableSortBy: true,
        // eslint-disable-next-line
        Cell: ({ row }) => {
          const theme = useTheme();
          // eslint-disable-next-line
          const { values, isExpanded, toggleRowExpanded } = row;
          const collapseIcon = isExpanded ? (
            <CloseOutlined style={{ color: theme.palette.error.main }} />
          ) : (
            <EyeTwoTone twoToneColor={theme.palette.secondary.main} />
          );
          return (
            <Stack direction="row" alignItems="center" justifyContent="center" spacing={0}>
              <Actions
                theme={theme}
                toggleRowExpanded={toggleRowExpanded}
                collapseIcon={collapseIcon}
                values={values}
                setClient={setClient}
              />
            </Stack>
          );
        }
      }
    ],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [theme]
  );

  const renderRowSubComponent = useCallback(({ row }) => <ClientRowView data={clients[row.id]} />, [clients]);

  if (loadingClients) return <LinearProgress />;

  return (
    <MainCard content={false}>
      <ScrollX>
        {clients?.length > 0 ? (
          <ReactTable
            columns={columns}
            data={clients}
            getHeaderProps={(column) => column.getSortByToggleProps()}
            renderRowSubComponent={renderRowSubComponent}
          />
        ) : (
          <Alert color="warning">No Clients. Please try refreshing the page.</Alert>
        )}
      </ScrollX>
    </MainCard>
  );
};
export default ClientsList;
