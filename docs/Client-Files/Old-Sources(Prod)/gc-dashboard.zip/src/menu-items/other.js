// third-party
import { FormattedMessage } from 'react-intl';

// assets
import { UserOutlined } from '@ant-design/icons';
import DashboardIcon from '@mui/icons-material/Dashboard';
import AdUnitsIcon from '@mui/icons-material/AdUnits';
import SchoolIcon from '@mui/icons-material/School';

// icons
const icons = {
  DashboardIcon,
  AdUnitsIcon,
  UserOutlined,
  SchoolIcon
};

// ==============================|| MENU ITEMS - SUPPORT ||============================== //

const other = {
  id: 'other',
  title: <FormattedMessage id="Admin" />,
  type: 'group',
  children: [
    {
      id: 'dashboard',
      title: <FormattedMessage id="Dashboard" />,
      type: 'item',
      url: '/dashboard',
      icon: icons.DashboardIcon
    },
    {
      id: 'kiosk',
      title: <FormattedMessage id="Kiosk" />,
      type: 'item',
      url: '/kiosk',
      icon: icons.AdUnitsIcon,
      rotate: 180
    },
    {
      id: 'customers',
      title: <FormattedMessage id="Customers" />,
      type: 'item',
      url: '/customers',
      icon: icons.UserOutlined
    },
    {
      id: 'clients',
      title: <FormattedMessage id="Clients" />,
      type: 'item',
      url: '/clients',
      icon: icons.SchoolIcon
    }
  ]
};

export default other;
