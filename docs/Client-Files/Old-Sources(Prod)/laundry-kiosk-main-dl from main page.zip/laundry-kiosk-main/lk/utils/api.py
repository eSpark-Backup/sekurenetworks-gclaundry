import time

import requests

from settings import BASE_URL
from utils.common import get_screen_resolution, update_config_file, get_config
from utils.logger import logger


def register_kiosk():
    resolution = get_screen_resolution()
    payload = {
        "ctrlBoardFw": "V1.7",
        "ctrlBoardHw": "V2.10",
        "sbcBoardFw": "V3.11",
        "sbcBoardHw": "V2.01",
        "motor1": "V1.0",
        "motor2": "V1.0",
        "lcdsize": 8 if resolution[0] < 1280 else 10.1,
        "lcdres": f"{resolution[0]},{resolution[1]}"
    }
    r = send_data_to_server(payload=payload)
    if r:
        update_config_file(r)


def send_data_to_server(payload):
    try:
        url = f"{BASE_URL}/kiosk/sensor-data/{get_config()['guid']}"
        r = requests.post(url=url, json=payload, timeout=5)
        logger.debug(f"API: Send data({payload}) to {url}: {r.status_code}, {r.content}")
        return r.json()
    except Exception as e:
        logger.error(f"Failed to send data to server - {e}")


def resend_password(phone_number):
    try:
        url = f"{BASE_URL}/resend-password/{get_config()['guid']}/+1{phone_number}"
        r = requests.get(url=url, timeout=3)
        logger.debug(f"API: Send SMS to {phone_number}: {r.status_code}, {r.content}")
        return True
    except Exception as e:
        logger.error(f"Failed to resend sms - {e}")


def ping_server():
    try:
        url = f"{BASE_URL}/kiosk-status/{get_config()['guid']}"
        r = requests.get(url=url, timeout=5)
        logger.debug(f"API: Kiosk PING({url}): {r.status_code}, {r.content}")
        return r.json().get('isActive')
    except Exception as e:
        logger.error(f"Failed to ping server - {e}")


def keep_alive_server():
    s_time = 0
    while True:
        if time.time() - s_time > 3600:     # Every hour
            if ping_server():
                s_time = time.time()
        time.sleep(10)
