#!/usr/bin/env bash
cur_dir="$( cd "$(dirname "$0")" ; pwd -P )"
cd ${cur_dir}/../..
rm -f .git/index.lock
rm .git/index
git add .
git pull
sudo pip3 install -r requirements.txt