import gc
import hashlib
import json
import os
import signal
import subprocess
import sys
import threading
import time

_cur_dir = os.path.dirname(os.path.realpath(__file__))
_par_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.path.pardir)
if _par_dir not in sys.path:
    sys.path.append(_par_dir)


from ui.compile_ui import compile_ui
from settings import CONFIG_FILE, HASH_STRING, HASH_FILE
from utils.logger import logger


try:
    is_rpi = 'arm' in os.uname()[4]
except (AttributeError, IndexError):
    is_rpi = False


def get_serial():
    """
    Get serial number of the device
    :return:
    """
    if is_rpi:
        try:
            cpuserial = "0000000000000000"
            f = open('/proc/cpuinfo', 'r')
            for line in f:
                if line[0:6] == 'Serial':
                    cpuserial = line[10:26].lstrip('0')
            f.close()
            return cpuserial
        except Exception as e:
            print(e)
    return '12345678'


def check_running_proc(proc_name):
    """
    Check if a process is running or not
    :param proc_name:
    :return:
    """
    is_running = False
    cmd = "ps -aef | grep -i '%s' | grep -v 'grep' | awk '{ print $3 }'" % proc_name
    try:
        if len(os.popen(cmd).read().strip().splitlines()) > 0:
            is_running = True
    except Exception as e:
        print(f'Failed to get status of the process({proc_name}) - {e}')
    return is_running


def number_to_ordinal(n):
    """
    Convert number to ordinal number string
    """
    return "%d%s" % (n, "tsnrhtdd"[(n / 10 % 10 != 1) * (n % 10 < 4) * n % 10::4])


def get_free_gpu_size():
    gc.collect()
    if is_rpi:
        try:
            pipe = os.popen('sudo vcdbg reloc stats | grep "free memory"')
            data = pipe.read().strip()
            pipe.close()
            return data
        except OSError:
            logger.error('!!! Failed to get free GPU size! ')
            tot, used, free = map(int, os.popen('free -t -m').readlines()[-1].split()[1:])
            logger.error(f'Total: {tot}, Used: {used}, Free: {free}')
    return 0


def disable_screen_saver():
    if is_rpi:
        os.system('sudo sh -c "TERM=linux setterm -blank 0 >/dev/tty0"')


def kill_process_by_name(proc_name, args="", use_sudo=True, sig=None):
    sig = sig if sig is not None else signal.SIGKILL
    try:
        p = subprocess.Popen(['ps', '-Af'], stdout=subprocess.PIPE)
    except FileNotFoundError:
        return
    out, err = p.communicate()
    for line in out.decode().splitlines():
        if proc_name in line and (not args or args in line):
            pid = int(line.split()[1])
            logger.info(f'Found PID({pid}) of `{proc_name}`, killing with {sig}...')
            try:
                if use_sudo:
                    os.system(f'sudo kill -{sig} {pid}')
                else:
                    os.kill(pid, sig)
            except Exception as e:
                logger.error(f"Failed to kill {proc_name} - {e}")


def rotate_display(angle):
    val = {0: "normal", 90: "left", 180: "inverted", 270: "right"}[angle]
    cmd = f"DISPLAY=:0 xrandr --output HDMI-1 --rotate {val}"
    os.system(cmd)


def update_dict_recursively(dest, updated):
    """
    Update dictionary recursively.
    :param dest: Destination dict.
    :type dest: dict
    :param updated: Updated dict to be applied.
    :type updated: dict
    :return:
    """
    for k, v in updated.items():
        if isinstance(dest, dict):
            if isinstance(v, dict):
                r = update_dict_recursively(dest.get(k, {}), v)
                dest[k] = r
            else:
                dest[k] = updated[k]
        else:
            dest = {k: updated[k]}
    return dest


def get_screen_resolution():
    """
    Get resolution of the screen
    :return:
    """
    if is_rpi:
        pipe = os.popen('fbset -s')
        data = pipe.read().strip()
        pipe.close()
        for line in data.splitlines():
            if line.startswith('mode'):
                w, h = [int(p) for p in line.split('"')[1].split('x')]
                return w, h
    else:
        return 1280, 720


def turn_display_off():
    os.system("xset -display :0 dpms force off")


def turn_display_on():
    os.system("xset -display :0 dpms force on && xrefresh")


def drop_cache():
    if is_rpi:
        os.system("sudo sh -c \"echo 1 > /proc/sys/vm/drop_caches\"")
        os.system("sudo sh -c \"echo 2 > /proc/sys/vm/drop_caches\"")
        os.system("sudo sh -c \"echo 3 > /proc/sys/vm/drop_caches\"")


lock = threading.Lock()


def update_config_file(data):
    old_data = update_dict_recursively(dest=get_config(), updated=data)
    with lock:
        with open(CONFIG_FILE, 'w') as jp:
            json.dump(old_data, jp, indent=2)


def get_config():
    while True:
        with lock:
            try:
                conf = json.loads(open(CONFIG_FILE).read())
                break
            except Exception as e:
                logger.error(f"Failed to read config file ({e})")
        time.sleep(.001)
    return conf


def is_display_connected():
    if is_rpi:
        pipe = os.popen("tvservice -s")
        data = pipe.read().strip()
        pipe.close()
        return "off" not in data
    else:
        return True


def read_version():
    return open(os.path.join(_cur_dir, os.pardir, os.pardir, 'VERSION')).read()


def check_git_commit():
    """
    Compare local/remote commit datetime, and pull if any updates in the remote repo.
    :return:
    """
    p = subprocess.Popen(f'/bin/bash {_cur_dir}/git_update.sh', shell=True,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    p.wait()
    return stdout.decode(), stderr.decode()


def check_remote_repo():
    while True:
        msg, err = check_git_commit()
        if 'Fast-forward' in msg:
            logger.warning(f'===== Remote repository was updated! Pulled - {msg}')
            compile_ui()
            p = subprocess.Popen(f"cd {os.path.join(_par_dir, os.pardir)} && python3 compile.py build_ext --inplace",
                                 shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            p.communicate()
            p.wait()
            logger.info("Rebooting now...")
            os.system('sudo reboot')
        time.sleep(60)


def create_hash():
    hash_str = HASH_STRING.format(sn=get_serial())
    return hashlib.sha256(hash_str.encode()).hexdigest()


def write_hash():
    """
    Generate and save to a file only when the file does not exist.
    :return:
    """
    if not os.path.exists(HASH_FILE):
        with open(HASH_FILE, 'w') as f:
            f.write(create_hash())


def verify_hash():
    if os.path.exists(HASH_FILE):
        return create_hash() == open(HASH_FILE).read()
    return False
