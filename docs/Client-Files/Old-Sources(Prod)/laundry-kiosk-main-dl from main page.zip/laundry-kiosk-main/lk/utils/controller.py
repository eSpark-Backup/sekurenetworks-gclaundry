import glob
import os
import subprocess
import sys
import threading
import time
import serial


_par_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.path.pardir)
if _par_dir not in sys.path:
    sys.path.append(_par_dir)

from utils.logger import logger


class BoardController(threading.Thread):

    def __init__(self, callback=None):
        super().__init__()
        self._b_stop = threading.Event()
        self._lock = threading.Lock()
        self._ser = None
        self.callback = callback

    def run(self) -> None:
        while not self._b_stop.is_set():
            if self._ser is not None or self.connect():
                with self._lock:
                    try:
                        buf = self._ser.readline()
                    except Exception as e:
                        logger.error(f"Failed to read data from the controller - {e}")
                        buf = None
                        self._ser = None
                if buf and callable(self.callback):
                    self.callback(buf)
            time.sleep(.1)

    def connect(self):
        for path in glob.glob('/dev/ttyACM*'):
            try:
                self._ser = serial.Serial(port=path, timeout=.2)
                logger.debug(f"Found a controller board port - {path}")
                return True
            except Exception as e:
                logger.error(f"Failed to connect to serial({path}) - {e}")
                self._ser = None
        return False

    def read_status(self, cmd):
        r = self._send_cmd(cmd=bytes([0x06, cmd]))
        if isinstance(r, bytes) and r[0] == cmd and len(r) > 2:
            return r[1:3]

    def read_tof_sensor(self, index=1):
        data = self.read_status(cmd=0x03 if index == 1 else 0x04)
        if data:
            return data[0] * 256 + data[1]

    def read_temperature(self):
        data = self.read_status(cmd=0x0B)
        if data:
            return data[1]

    def read_motor_current(self, index=1):
        data = self.read_status(0x0C if index == 1 else 0x0D)
        if data:
            return data[0] * 256 + data[1]

    def set_motor_speed(self, mode, speed):
        cmd = bytes([0x07 if mode == 'scented' else 0x08, speed])
        self._send_cmd(cmd)

    def read_firmware_version(self):
        r = self.read_status(cmd=0x09)
        if r:
            return f"{r[1] // 16}.{r[1] % 16}"

    def reboot_device(self):
        self._send_cmd(cmd=bytes([0x0E]))

    def update_firmware(self, path):
        self.read_status(cmd=0x0A)
        time.sleep(.5)
        p = subprocess.Popen(f"dfu-util -a 0 -s 0x08010000 -D {path} -R", shell=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = p.communicate()
        logger.debug(f"Firmware update : {stdout}\n\t{stderr}")

    def _send_cmd(self, cmd):
        if self._ser is not None or self.connect():
            try:
                with self._lock:
                    try:
                        self._ser.write(cmd)
                    except Exception as e:
                        logger.error(f"Failed to send command to the controller - {e}")
                        self._ser = None
                    if cmd[0] == 0x06:      # Controller Status
                        time.sleep(.1)
                        buf = self._ser.readline()
                return buf if cmd[0] == 0x06 else None
            except Exception as e:
                logger.error(f"Failed to send CMD({cmd}) - {e}")
                self._ser = None

    def stop(self):
        self._b_stop.set()
        if self._ser is not None:
            self._ser.close()


if __name__ == '__main__':

    def on_message(msg):
        logger.debug(f"Message received from the CTRL board - {msg}")

    _ctrl = BoardController(callback=on_message)
    _ctrl.start()

    while True:
        try:
            time.sleep(.1)
        except KeyboardInterrupt:
            break
    _ctrl.stop()
