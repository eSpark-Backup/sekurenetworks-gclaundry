import argparse
import os
import random
import sys
from datetime import datetime
from peewee import *

_root_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir, os.pardir)

if _root_dir not in sys.path:
    sys.path.append(_root_dir)

from lk.settings import DB_HOST, DB_PASSWORD, EXIT_QUESTIONS
from lk.utils.logger import logger

db = MySQLDatabase('laundry_kiosk', user='root', password=DB_PASSWORD, host=DB_HOST)


class BaseModel(Model):
    class Meta:
        database = db


class User(BaseModel):

    id = AutoField(primary_key=True)
    name = TextField(default='')
    phone = TextField(default='')
    pin = IntegerField()
    created_at = DateTimeField(default=datetime.now)
    last_login = DateTimeField(default=datetime.now)


class Answer(BaseModel):

    id = AutoField(primary_key=True)
    user = ForeignKeyField(User, backref='answers')
    question_id = IntegerField()
    answer = TextField()
    created_at = DateTimeField(default=datetime.now)


db.connect()
if not User.table_exists():
    db.create_tables([User, Answer])


def create_user(name, phone, pin):
    user = User(name=name, phone=phone, pin=pin)
    user.save()
    return user


def find_user_by_phone(phone):
    try:
        User.get(User.phone == phone)
        return True
    except DoesNotExist:
        pass
    return False


def login_user(phone, pin):
    try:
        user = User.get(User.phone == phone, User.pin == pin)
        user.last_login = datetime.now()
        user.save()
        return user
    except DoesNotExist:
        pass


def find_random_question(user):
    if user is None:
        last_answer = None
    else:
        try:
            obj = Answer.select().join(User).where(User.id == user.id).order_by(Answer.created_at.desc()).get()
            last_answer = obj.question_id
        except Exception as e:
            logger.error(f"Failed to get last answer of {user.name} - {e}")
            last_answer = None
    return random.choice([q for q in EXIT_QUESTIONS if q['id'] != last_answer])


def add_answer(user, question, answer):
    if user is None:
        return
    obj = Answer.create(user=user, question_id=question['id'], answer=answer)
    obj.save()
    return obj


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='User addition script')
    parser.add_argument('-n', '--name', help='Name of the user', required=True)
    parser.add_argument('-p', '--phone', help='Phone number', required=True)
    parser.add_argument('-c', '--pin', help='Pin Code', required=True, type=int)
    args = parser.parse_args()

    new_user = create_user(name=args.name, phone=args.phone, pin=args.pin)
    print(f"Created a new user - {new_user}")
