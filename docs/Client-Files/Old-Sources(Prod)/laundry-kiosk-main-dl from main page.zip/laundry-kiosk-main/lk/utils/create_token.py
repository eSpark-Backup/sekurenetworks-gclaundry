"""
    Execute this python script to generate a token for each device.
"""
import os
import sys

_root_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), os.pardir)

if _root_dir not in sys.path:
    sys.path.append(_root_dir)


from utils.common import write_hash


if __name__ == '__main__':

    write_hash()
