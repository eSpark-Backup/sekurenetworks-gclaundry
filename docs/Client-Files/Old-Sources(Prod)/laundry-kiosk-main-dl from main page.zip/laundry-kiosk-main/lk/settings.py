import json
import os

APP_DIR = os.path.dirname(os.path.realpath(__file__))


ROOT_DIR = os.path.expanduser('~/.lk')
os.makedirs(ROOT_DIR, exist_ok=True)


DEFAULT_CONFIG = {
    "guid": "al-lwdfo"
}

INIT_SCREEN = 'welcome'

CONFIG_FILE = os.path.join(ROOT_DIR, 'config.json')
if not os.path.exists(CONFIG_FILE):
    print("No config found! Creating the default one...")
    with open(CONFIG_FILE, 'w') as jp:
        json.dump(DEFAULT_CONFIG, jp, indent=2)


DISPENSE_COUNT = 10
MOTOR_SPEED = 100

BASE_URL = "https://kiosk-portal-363821.uc.r.appspot.com/webhook"

DB_HOST = 'localhost'
DB_PASSWORD = 'TopSecret123'

HASH_STRING = "LaundryKiosk{sn}"
HASH_FILE = os.path.join(ROOT_DIR, '.lk.hash')

ENV_MESSAGES = [
    "If 62% of students refill sheets then we could avoid 45% of CO2 emissions from laundry detergent.\n"
    "If every industry achieved a 45% CO2 reductions, we could meet the IPCC goals of 1.5 °C",
    "To leave the world better than you found it, sometimes you have to pick up other people’s trash.",
    "An understanding of the natural world and what's in it is a source of not only a great curiosity "
    "but great fulfillment.",
    "\"We still dot not know one thousandth of one percent of what nature has revealed to us.\"\n -Albert Einstein",
    "\"Look at a tree, a flower, a plant. Let your awareness rest upon it. "
    "How still they are, how deeply rooted in Being.  Allow nature to teach you stillness.\" -Eckhart Tolle"
]

EXIT_QUESTIONS = [
    {
        "id": 1,
        "question": "Organic waste sent to landfill (instead of compost), "
                    "will create methane emissions which are 70x worse than carbon emissions?",
        "answers": ["TRUE", "FALSE"],
    }, {
        "id": 2,
        "question": "Meteorology is the study of weather.",
        "answers": ["TRUE", "FALSE"],
    }, {
        "id": 3,
        "question": "Ernst Haeckel coined the word ‘ecology’.",
        "answers": ["TRUE", "FALSE"],
    }, {
        "id": 4,
        "question": "Animals that live in the soil are terricolous animals.",
        "answers": ["TRUE", "FALSE"],
    }, {
        "id": 5,
        "question": "Albert Einstein is known as the father of evolution.",
        "answers": ["TRUE", "FALSE"],
    }, {
        "id": 6,
        "question": "When is your birthday?",
        "answers": ["June 2nd", "October 3rd", "November 17th", "July 18th", "December 1st", "March 3rd"],
    }, {
        "id": 7,
        "question": "What is your favorite color?",
        "answers": ["Red", "Blue", "Yellow", "Green", "Orange", "Brown"],
    }, {
        "id": 8,
        "question": "What is your lucky number?",
        "answers": ["3", "7", "8", "9", "1", "22"],
    }, {
        "id": 9,
        "question": "Name the atmospheric layer closest to the ground.",
        "answers": ["Troposphere", "Mesosphere", "Thermosphere", "Stratosphere", "Exosphere", "Magnetosphere"],
    }, {
        "id": 10,
        "question": "The most abundant gas on the Earth's atmosphere is?",
        "answers": ["Oxygen", "Carbon", "Nitrogen", "Hydrogen", "Hellium", "Ozone"],
    }
]

try:
    from local_settings import *
except ImportError:
    pass
