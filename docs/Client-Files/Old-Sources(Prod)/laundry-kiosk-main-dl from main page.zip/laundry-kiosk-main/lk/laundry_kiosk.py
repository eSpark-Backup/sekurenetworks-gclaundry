import os
import sys
os.environ['QT_API'] = 'pyside2'
os.environ['DISPLAY'] = ':0.0'
os.environ['QT_AUTO_SCREEN_SCALE_FACTOR'] = '1'
os.environ["QT_IM_MODULE"] = "qtvirtualkeyboard"

_cur_dir = os.path.dirname(os.path.realpath(__file__))
sys.path.append(_cur_dir)

import time
import multiprocessing
import threading
import glob
import signal
import sys
import traceback
from PySide2 import QtGui
from PySide2.QtGui import QGuiApplication, QRegion
from PySide2.QtCore import Qt, QTimer, QObject, Signal
from PySide2.QtWidgets import QApplication, QMainWindow
from settings import INIT_SCREEN, MOTOR_SPEED, DISPENSE_COUNT
from utils.common import kill_process_by_name, is_rpi, drop_cache, verify_hash, check_remote_repo
from utils.logger import logger
from utils.controller import BoardController
from screens import screens
from utils.touch_observer import TouchObserver
from ui.ui_lk import Ui_LaundryKiosk
from utils.api import send_data_to_server, keep_alive_server


class LaundryKioskApp(QMainWindow):

    _cur_screen = None
    _cur_screen_name = ''
    _fault_cnt = 0
    _sheet_cnt = 0
    _mode = None
    _state = 'init'
    phone_number = None
    cur_user = None
    sig_dispense_complete = Signal()
    _sensor_data = {}
    _dispense_data = {}
    _last_opt_ts = 0

    def __init__(self):
        super().__init__()
        self.ui = Ui_LaundryKiosk()
        self.ui.setupUi(self)
        if is_rpi:
            self.move(0, 0)
            self.setWindowFlag(Qt.FramelessWindowHint)

        self._inactive_timer = QTimer()
        self._inactive_cnt = 0
        # https://stackoverflow.com/a/64072962/6901561
        setattr(self, "LaundryKioskApp.on_touch_released", self.on_touch_released)
        setattr(self, "LaundryKioskApp._check_inactive", self._check_inactive)
        self._inactive_timer.timeout.connect(self._check_inactive)
        self._inactive_timer.start(1000)
        setattr(self, "LaundryKioskApp._on_dispense_completed", self._on_dispense_completed)
        getattr(self, 'sig_dispense_complete').connect(self._on_dispense_completed)
        self._ctrl = BoardController(callback=self._on_message_from_ctrl)
        self._ctrl.start()
        self.switch_screen(INIT_SCREEN)
        self._last_status_ts = time.time()
        self._lock = threading.Lock()
        threading.Thread(target=self._upload_status).start()

    def switch_screen(self, screen_name, **kwargs):
        if self._cur_screen_name == screen_name:
            return
        if self._cur_screen:
            self._cur_screen.on_leave()
            self.ui.stack.removeWidget(self._cur_screen)
        logging = kwargs.pop('log') if 'log' in kwargs else True
        self._cur_screen = screens[screen_name](app=self, **kwargs)
        self._cur_screen_name = screen_name
        self.ui.stack.addWidget(self._cur_screen)
        self.ui.stack.setCurrentWidget(self._cur_screen)
        if logging:
            logger.debug(f"=== Switched to {screen_name} screen")
        if screen_name == 'dispense':
            logger.info(f">>> Dispensing {self._mode} sheets!")
            self._dispense_data['beforeDispense'] = {
                'ToF1': self._ctrl.read_tof_sensor(index=1),
                'ToF2': self._ctrl.read_tof_sensor(index=2)
            }
            self._sheet_cnt = 0
            self._state = 'init'
            self.set_motor_speed(MOTOR_SPEED)

    def on_touch_released(self):
        self._cur_screen.on_touched()
        self._inactive_cnt = 0

    def _check_inactive(self):
        if self._inactive_cnt > self._cur_screen.timeout and self._cur_screen_name != 'welcome':
            logger.debug(f"Timeout({self._cur_screen.timeout}) from {self._cur_screen_name}...")
            self.switch_screen(self._cur_screen.prev_screen)
            self._inactive_cnt = 0
        else:
            self._inactive_cnt += 1

    def _on_message_from_ctrl(self, msg):
        logger.debug(f"Message received from the CTRL board - {msg}")
        packets = [msg[i:i + 3] for i in range(0, len(msg), 3)]
        packets = [p for p in packets if len(p) == 3]
        for pac in packets:
            if pac[0] == 0x01:              # Limit Sensor / Door Switch
                door_opened = (pac[2] >> 6) & 1 == 1
                if door_opened:
                    logger.warning(">>> Door is opened!!!")
                    threading.Thread(target=send_data_to_server, args=({"doorSw1": "open"}, )).start()
                new_data = {f"limitSw{k}": (pac[2] >> (6 - k)) & 1 for k in range(1, 7)}
                new_data['doorSw1'] = 'open' if door_opened else 'close'
            elif pac[0] == 0x02:            # Optical Sensor
                new_data = {f"irBreak{k}": (pac[2] >> (4 - k)) & 1 for k in range(1, 5)}
                if self._cur_screen_name == 'dispense':
                    offset = 2 if self._mode == 'scented' else 0
                    if self._state == 'init':
                        if (pac[2] >> (offset + 1)) & 1 == 0 or (pac[2] >> offset) & 1 == 0:
                            logger.debug("Top/bottom sensor has been triggered")
                            self._state = 'triggered'
                    elif self._state == 'triggered':
                        if (pac[2] >> (offset + 1)) & 1 == 1 and (pac[2] >> offset) & 1 == 1:
                            self._sheet_cnt += 1
                            logger.debug(f"Both sensors are connected, counting {self._sheet_cnt}")
                            if self._sheet_cnt == DISPENSE_COUNT:
                                self._finish_dispense()
                            else:
                                self._state = 'init'
            elif pac[0] in {0x03, 0x04}:
                new_data = {f"ToF{1 if pac[0] == 0x03 else 2}": pac[1] * 256 + pac[2]}
            elif pac[0] == 0x05:
                new_data = {
                    'motor1': 'stuck' if (pac[2] >> 1) & 1 == 1 else 'clear',
                    'motor2': 'stuck' if (pac[2] >> 5) & 1 == 1 else 'clear',
                }
                threading.Thread(target=send_data_to_server, args=(new_data, )).start()
            elif pac[0] in {0x0C, 0x0D}:
                new_data = {f"Current{1 if pac[0] == 0x03 else 2}": pac[1] * 256 + pac[2]}
            else:
                return
            self._update_sensor_data(new_data)

    def _finish_dispense(self):
        self.set_motor_speed(0)
        getattr(self, 'sig_dispense_complete').emit()
        self._dispense_data['afterDispense'] = {
            'ToF1': self._ctrl.read_tof_sensor(index=1),
            'ToF2': self._ctrl.read_tof_sensor(index=2)
        }
        self._dispense_data.update(**{
            'userId': self.cur_user.id,
            'sheetType': self._mode,
            'sheetsDispensed': self._sheet_cnt
        })
        self._last_status_ts = time.time()
        threading.Thread(target=send_data_to_server, args=(self._dispense_data, )).start()

    def set_motor_speed(self, speed):
        self._ctrl.set_motor_speed(mode=self._mode, speed=speed)

    def _on_dispense_completed(self):
        self.switch_screen('survey')

    def set_fault_cnt(self, val):
        self._fault_cnt = val

    def get_fault_cnt(self):
        return self._fault_cnt

    def get_cur_mode(self):
        return self._mode

    def set_cur_mode(self, mode):
        self._mode = mode

    def _upload_status(self):
        while True:
            if time.time() - self._last_status_ts > 60 * 5 and self._cur_screen_name != 'dispense':
                if 'limitSw1' not in self._sensor_data:
                    state = self._ctrl.read_status(cmd=0x01)
                    if state is not None:
                        self._update_sensor_data({f"limitSw{k}": (state[1] >> (6 - k)) & 1 for k in range(1, 7)})
                if 'irBreak1' not in self._sensor_data:
                    state = self._ctrl.read_status(cmd=0x02)
                    if state is not None:
                        self._update_sensor_data({f"irBreak{k}": (state[1] >> (4 - k)) & 1 for k in range(1, 5)})
                if 'ToF1' not in self._sensor_data:
                    r = self._ctrl.read_tof_sensor(index=1)
                    if r is not None:
                        self._update_sensor_data({'ToF1': r})
                if 'ToF2' not in self._sensor_data:
                    r = self._ctrl.read_tof_sensor(index=2)
                    if r is not None:
                        self._update_sensor_data({'ToF2': r})
                if 'motor1' not in self._sensor_data:
                    state = self._ctrl.read_status(cmd=0x05)
                    if state is not None:
                        self._update_sensor_data({
                            'motor1': 'stuck' if (state[1] >> 1) & 1 == 1 else 'clear',
                            'motor2': 'stuck' if (state[1] >> 5) & 1 == 1 else 'clear',
                        })
                if self._sensor_data:
                    logger.debug(f"Uploading Kiosk status - {self._sensor_data}")
                    if send_data_to_server(self._sensor_data):
                        self._last_status_ts = time.time()
                        with self._lock:
                            self._sensor_data = {}
                else:
                    logger.warning("No sensor data received.. is the controller board connected?")
            time.sleep(10)

    def _update_sensor_data(self, new_data):
        with self._lock:
            self._sensor_data.update(**new_data)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_F:
            logger.debug("F pressed")
        return super().keyPressEvent(event)

    def closeEvent(self, event):
        self._ctrl.stop()
        self._ctrl.join(1)


def handle_visible_changed():
    if not QGuiApplication.inputMethod().isVisible():
        return
    for w in QGuiApplication.allWindows():
        if w.metaObject().className() == "QtVirtualKeyboard::InputView":
            keyboard = w.findChild(QObject, "keyboard")
            if keyboard is not None:
                r = w.geometry()
                r.moveTop(keyboard.property("y"))
                w.setMask(QRegion(r))
                return


def start_kiosk():

    if not verify_hash() and is_rpi:
        logger.error('!!!!!!!!!! Failed to authorize device. Is this correct device?')
        sys.exit(-1)

    # Drop cache to get free memory space
    drop_cache()

    sys._excepthook = sys.excepthook

    def exception_hook(exctype, value, exc_tb):
        logger.error(f'!!!! Crashed! Exctype: {exctype}, Value: {value}, Traceback: {traceback.format_tb(exc_tb)}')
        getattr(sys, "_excepthook")(exctype, value, exc_tb)
        sys.exit(1)

    sys.excepthook = exception_hook

    kill_process_by_name(proc_name='fbi', use_sudo=True, sig=signal.SIGTERM)

    logger.info("========== Starting LaundryKiosk App ==========")

    multiprocessing.Process(target=keep_alive_server).start()
    multiprocessing.Process(target=check_remote_repo).start()

    app = QApplication(sys.argv)

    for font in glob.glob(os.path.join(_cur_dir, 'font', '*.ttf')):
        QtGui.QFontDatabase.addApplicationFont(font)

    # QGuiApplication.inputMethod().visibleChanged.connect(handle_visible_changed)

    lk_app = LaundryKioskApp()
    lk_app.show()
    touch_observer = TouchObserver(lk_app.window().windowHandle())
    touch_observer.released.connect(lambda pos: lk_app.on_touch_released())

    sys.exit(app.exec_())
