# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'lk.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_LaundryKiosk(object):
    def setupUi(self, LaundryKiosk):
        if not LaundryKiosk.objectName():
            LaundryKiosk.setObjectName(u"LaundryKiosk")
        LaundryKiosk.resize(1280, 800)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(LaundryKiosk.sizePolicy().hasHeightForWidth())
        LaundryKiosk.setSizePolicy(sizePolicy)
        LaundryKiosk.setMinimumSize(QSize(1280, 800))
        LaundryKiosk.setMaximumSize(QSize(1280, 800))
        self.centralwidget = QWidget(LaundryKiosk)
        self.centralwidget.setObjectName(u"centralwidget")
        sizePolicy.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy)
        self.centralwidget.setMinimumSize(QSize(1280, 800))
        self.centralwidget.setMaximumSize(QSize(1280, 800))
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget(self.centralwidget)
        self.stack.setObjectName(u"stack")
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.stack.addWidget(self.page)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.stack.addWidget(self.page_2)

        self.verticalLayout.addWidget(self.stack)

        LaundryKiosk.setCentralWidget(self.centralwidget)

        self.retranslateUi(LaundryKiosk)

        QMetaObject.connectSlotsByName(LaundryKiosk)
    # setupUi

    def retranslateUi(self, LaundryKiosk):
        LaundryKiosk.setWindowTitle(QCoreApplication.translate("LaundryKiosk", u"LandryKiosk", None))
    # retranslateUi

