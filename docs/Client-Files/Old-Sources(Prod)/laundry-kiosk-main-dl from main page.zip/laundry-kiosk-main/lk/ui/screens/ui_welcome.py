# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'welcome.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_WelcomeScreen(object):
    def setupUi(self, WelcomeScreen):
        if not WelcomeScreen.objectName():
            WelcomeScreen.setObjectName(u"WelcomeScreen")
        WelcomeScreen.resize(1280, 800)
        self.img = QLabel(WelcomeScreen)
        self.img.setObjectName(u"img")
        self.img.setGeometry(QRect(0, 0, 1280, 800))
        self.img.setPixmap(QPixmap(u":/img/img/background.jpg"))
        self.gif = QLabel(WelcomeScreen)
        self.gif.setObjectName(u"gif")
        self.gif.setGeometry(QRect(0, -1, 1280, 801))
        self.version = QLabel(WelcomeScreen)
        self.version.setObjectName(u"version")
        self.version.setGeometry(QRect(1160, 750, 101, 31))
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(26)
        self.version.setFont(font)
        self.version.setStyleSheet(u"color: #eb2700;")

        self.retranslateUi(WelcomeScreen)

        QMetaObject.connectSlotsByName(WelcomeScreen)
    # setupUi

    def retranslateUi(self, WelcomeScreen):
        WelcomeScreen.setWindowTitle(QCoreApplication.translate("WelcomeScreen", u"Welcome", None))
        self.img.setText("")
        self.gif.setText("")
        self.version.setText(QCoreApplication.translate("WelcomeScreen", u"Ver: V3.1", None))
    # retranslateUi

