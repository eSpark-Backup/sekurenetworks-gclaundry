# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'phone_number.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_PhoneNumberScreen(object):
    def setupUi(self, PhoneNumberScreen):
        if not PhoneNumberScreen.objectName():
            PhoneNumberScreen.setObjectName(u"PhoneNumberScreen")
        PhoneNumberScreen.resize(1280, 800)
        PhoneNumberScreen.setStyleSheet(u"")
        self.lb_background = QLabel(PhoneNumberScreen)
        self.lb_background.setObjectName(u"lb_background")
        self.lb_background.setGeometry(QRect(0, 0, 1280, 800))
        self.lb_background.setPixmap(QPixmap(u":/img/img/background.jpg"))
        self.label = QLabel(PhoneNumberScreen)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(90, 30, 1100, 151))
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(50)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(238, 51, 48);")
        self.label.setAlignment(Qt.AlignCenter)
        self.frame = QFrame(PhoneNumberScreen)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(490, 280, 301, 401))
        self.frame.setFrameShape(QFrame.NoFrame)
        self.frame.setFrameShadow(QFrame.Plain)
        self.frame.setLineWidth(0)
        self.verticalLayout = QVBoxLayout(self.frame)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.btn_1 = QToolButton(self.frame)
        self.btn_1.setObjectName(u"btn_1")
        self.btn_1.setMinimumSize(QSize(70, 70))
        font1 = QFont()
        font1.setFamily(u"Owners XNarrow")
        font1.setPointSize(30)
        self.btn_1.setFont(font1)
        self.btn_1.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout.addWidget(self.btn_1)

        self.btn_2 = QToolButton(self.frame)
        self.btn_2.setObjectName(u"btn_2")
        self.btn_2.setMinimumSize(QSize(70, 70))
        self.btn_2.setFont(font1)
        self.btn_2.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout.addWidget(self.btn_2)

        self.btn_3 = QToolButton(self.frame)
        self.btn_3.setObjectName(u"btn_3")
        self.btn_3.setMinimumSize(QSize(70, 70))
        self.btn_3.setFont(font1)
        self.btn_3.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout.addWidget(self.btn_3)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.btn_4 = QToolButton(self.frame)
        self.btn_4.setObjectName(u"btn_4")
        self.btn_4.setMinimumSize(QSize(70, 70))
        self.btn_4.setFont(font1)
        self.btn_4.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_2.addWidget(self.btn_4)

        self.btn_5 = QToolButton(self.frame)
        self.btn_5.setObjectName(u"btn_5")
        self.btn_5.setMinimumSize(QSize(70, 70))
        self.btn_5.setFont(font1)
        self.btn_5.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_2.addWidget(self.btn_5)

        self.btn_6 = QToolButton(self.frame)
        self.btn_6.setObjectName(u"btn_6")
        self.btn_6.setMinimumSize(QSize(70, 70))
        self.btn_6.setFont(font1)
        self.btn_6.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_2.addWidget(self.btn_6)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.btn_7 = QToolButton(self.frame)
        self.btn_7.setObjectName(u"btn_7")
        self.btn_7.setMinimumSize(QSize(70, 70))
        self.btn_7.setFont(font1)
        self.btn_7.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_3.addWidget(self.btn_7)

        self.btn_8 = QToolButton(self.frame)
        self.btn_8.setObjectName(u"btn_8")
        self.btn_8.setMinimumSize(QSize(70, 70))
        self.btn_8.setFont(font1)
        self.btn_8.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_3.addWidget(self.btn_8)

        self.btn_9 = QToolButton(self.frame)
        self.btn_9.setObjectName(u"btn_9")
        self.btn_9.setMinimumSize(QSize(70, 70))
        self.btn_9.setFont(font1)
        self.btn_9.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_3.addWidget(self.btn_9)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.widget = QWidget(self.frame)
        self.widget.setObjectName(u"widget")
        self.widget.setMaximumSize(QSize(70, 70))

        self.horizontalLayout_4.addWidget(self.widget)

        self.btn_0 = QToolButton(self.frame)
        self.btn_0.setObjectName(u"btn_0")
        self.btn_0.setMinimumSize(QSize(70, 70))
        self.btn_0.setFont(font1)
        self.btn_0.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_4.addWidget(self.btn_0)

        self.btn_b = QToolButton(self.frame)
        self.btn_b.setObjectName(u"btn_b")
        self.btn_b.setMinimumSize(QSize(70, 70))
        self.btn_b.setFont(font1)
        self.btn_b.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_4.addWidget(self.btn_b)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.btn_send = QToolButton(PhoneNumberScreen)
        self.btn_send.setObjectName(u"btn_send")
        self.btn_send.setGeometry(QRect(500, 710, 280, 60))
        font2 = QFont()
        font2.setFamily(u"Owners XNarrow")
        font2.setPointSize(40)
        font2.setBold(True)
        font2.setWeight(75)
        self.btn_send.setFont(font2)
        self.btn_send.setStyleSheet(u"color: rgb(255, 56, 21);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 140px 30px;")
        self.widget_2 = QWidget(PhoneNumberScreen)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setGeometry(QRect(350, 189, 580, 90))
        self.widget_2.setStyleSheet(u"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 290px 45px;")
        self.horizontalLayout_5 = QHBoxLayout(self.widget_2)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(80, 25, 80, 25)
        self.val_0 = QLabel(self.widget_2)
        self.val_0.setObjectName(u"val_0")
        font3 = QFont()
        font3.setFamily(u"Owners XNarrow")
        font3.setPointSize(40)
        font3.setUnderline(False)
        self.val_0.setFont(font3)
        self.val_0.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_0.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_0)

        self.val_1 = QLabel(self.widget_2)
        self.val_1.setObjectName(u"val_1")
        self.val_1.setFont(font3)
        self.val_1.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_1.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_1)

        self.val_2 = QLabel(self.widget_2)
        self.val_2.setObjectName(u"val_2")
        self.val_2.setFont(font3)
        self.val_2.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_2)

        self.val_3 = QLabel(self.widget_2)
        self.val_3.setObjectName(u"val_3")
        self.val_3.setFont(font3)
        self.val_3.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_3.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_3)

        self.val_4 = QLabel(self.widget_2)
        self.val_4.setObjectName(u"val_4")
        self.val_4.setFont(font3)
        self.val_4.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_4.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_4)

        self.val_5 = QLabel(self.widget_2)
        self.val_5.setObjectName(u"val_5")
        self.val_5.setFont(font3)
        self.val_5.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_5.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_5)

        self.val_6 = QLabel(self.widget_2)
        self.val_6.setObjectName(u"val_6")
        self.val_6.setFont(font3)
        self.val_6.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_6.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_6)

        self.val_7 = QLabel(self.widget_2)
        self.val_7.setObjectName(u"val_7")
        self.val_7.setFont(font3)
        self.val_7.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_7.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_7)

        self.val_8 = QLabel(self.widget_2)
        self.val_8.setObjectName(u"val_8")
        self.val_8.setFont(font3)
        self.val_8.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_8.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_8)

        self.val_9 = QLabel(self.widget_2)
        self.val_9.setObjectName(u"val_9")
        self.val_9.setFont(font3)
        self.val_9.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_9.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_9)


        self.retranslateUi(PhoneNumberScreen)

        QMetaObject.connectSlotsByName(PhoneNumberScreen)
    # setupUi

    def retranslateUi(self, PhoneNumberScreen):
        PhoneNumberScreen.setWindowTitle(QCoreApplication.translate("PhoneNumberScreen", u"Phone Number", None))
        self.lb_background.setText("")
        self.label.setText(QCoreApplication.translate("PhoneNumberScreen", u"ENTER YOUR PHONE NUMBER TO RECEIVE\n"
"DISPENSING CODE", None))
        self.btn_1.setText(QCoreApplication.translate("PhoneNumberScreen", u"1", None))
        self.btn_2.setText(QCoreApplication.translate("PhoneNumberScreen", u"2", None))
        self.btn_3.setText(QCoreApplication.translate("PhoneNumberScreen", u"3", None))
        self.btn_4.setText(QCoreApplication.translate("PhoneNumberScreen", u"4", None))
        self.btn_5.setText(QCoreApplication.translate("PhoneNumberScreen", u"5", None))
        self.btn_6.setText(QCoreApplication.translate("PhoneNumberScreen", u"6", None))
        self.btn_7.setText(QCoreApplication.translate("PhoneNumberScreen", u"7", None))
        self.btn_8.setText(QCoreApplication.translate("PhoneNumberScreen", u"8", None))
        self.btn_9.setText(QCoreApplication.translate("PhoneNumberScreen", u"9", None))
        self.btn_0.setText(QCoreApplication.translate("PhoneNumberScreen", u"0", None))
        self.btn_b.setText(QCoreApplication.translate("PhoneNumberScreen", u"<", None))
        self.btn_send.setText(QCoreApplication.translate("PhoneNumberScreen", u"SEND", None))
        self.val_0.setText("")
        self.val_1.setText("")
        self.val_2.setText("")
        self.val_3.setText("")
        self.val_4.setText("")
        self.val_5.setText("")
        self.val_6.setText("")
        self.val_7.setText("")
        self.val_8.setText("")
        self.val_9.setText("")
    # retranslateUi

