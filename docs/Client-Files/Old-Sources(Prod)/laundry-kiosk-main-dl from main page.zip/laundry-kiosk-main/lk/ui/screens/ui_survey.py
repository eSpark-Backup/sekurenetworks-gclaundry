# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'survey.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_SurveyScreen(object):
    def setupUi(self, SurveyScreen):
        if not SurveyScreen.objectName():
            SurveyScreen.setObjectName(u"SurveyScreen")
        SurveyScreen.resize(1280, 800)
        self.img = QLabel(SurveyScreen)
        self.img.setObjectName(u"img")
        self.img.setGeometry(QRect(0, 0, 1280, 800))
        self.img.setPixmap(QPixmap(u":/img/img/background.jpg"))
        self.layoutWidget = QWidget(SurveyScreen)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(59, 30, 1161, 751))
        self.verticalLayout = QVBoxLayout(self.layoutWidget)
        self.verticalLayout.setSpacing(20)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(20, 20, 20, 20)
        self.question = QLabel(self.layoutWidget)
        self.question.setObjectName(u"question")
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(50)
        font.setBold(True)
        font.setWeight(75)
        self.question.setFont(font)
        self.question.setStyleSheet(u"color: rgb(238, 51, 48);")
        self.question.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)
        self.question.setWordWrap(True)

        self.verticalLayout.addWidget(self.question)

        self.stack = QStackedWidget(self.layoutWidget)
        self.stack.setObjectName(u"stack")
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.stack.sizePolicy().hasHeightForWidth())
        self.stack.setSizePolicy(sizePolicy)
        self.page_yes_no = QWidget()
        self.page_yes_no.setObjectName(u"page_yes_no")
        self.btn_true = QToolButton(self.page_yes_no)
        self.btn_true.setObjectName(u"btn_true")
        self.btn_true.setGeometry(QRect(70, 240, 420, 100))
        self.btn_true.setFont(font)
        self.btn_true.setStyleSheet(u"QToolButton {\n"
"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 210px 50px;\n"
"}\n"
"QToolButton::pressed {\n"
"  color: rgb(255, 56, 21);\n"
"  background-color: rgb(255, 255, 255);\n"
"  border-width: 1px; \n"
"  border-style: solid; \n"
"  border-color: red;\n"
"  border-radius: 210px 50px;\n"
"}\n"
"QToolButton::released {\n"
"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 210px 50px;\n"
"}\n"
"")
        self.btn_false = QToolButton(self.page_yes_no)
        self.btn_false.setObjectName(u"btn_false")
        self.btn_false.setGeometry(QRect(630, 240, 420, 100))
        self.btn_false.setFont(font)
        self.btn_false.setStyleSheet(u"QToolButton {\n"
"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 210px 50px;\n"
"}\n"
"QToolButton::pressed {\n"
"  color: rgb(255, 56, 21);\n"
"  background-color: rgb(255, 255, 255);\n"
"  border-width: 1px; \n"
"  border-style: solid; \n"
"  border-color: red;\n"
"  border-radius: 210px 50px;\n"
"}\n"
"QToolButton::released {\n"
"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 210px 50px;\n"
"}\n"
"")
        self.stack.addWidget(self.page_yes_no)
        self.page_multiple = QWidget()
        self.page_multiple.setObjectName(u"page_multiple")
        self.btn_submit = QToolButton(self.page_multiple)
        self.btn_submit.setObjectName(u"btn_submit")
        self.btn_submit.setGeometry(QRect(410, 520, 300, 60))
        font1 = QFont()
        font1.setFamily(u"Owners XNarrow")
        font1.setPointSize(30)
        font1.setBold(True)
        font1.setWeight(75)
        self.btn_submit.setFont(font1)
        self.btn_submit.setStyleSheet(u"QToolButton {\n"
"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 150px 30px;\n"
"}\n"
"QToolButton::pressed {\n"
"  color: rgb(255, 56, 21);\n"
"  background-color: rgb(255, 255, 255);\n"
"  border-width: 1px; \n"
"  border-style: solid; \n"
"  border-color: red;\n"
"  border-radius: 150px 30px;\n"
"}\n"
"")
        self.frame = QFrame(self.page_multiple)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 1111, 501))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.btn_0 = QPushButton(self.frame)
        self.btn_0.setObjectName(u"btn_0")
        font2 = QFont()
        font2.setFamily(u"Owners XNarrow")
        font2.setPointSize(30)
        self.btn_0.setFont(font2)
        self.btn_0.setStyleSheet(u"text-align:left;\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(238, 51, 48);\n"
"border-radius: 10px;\n"
"padding-left: 20px;\n"
"")

        self.verticalLayout_2.addWidget(self.btn_0)

        self.btn_1 = QPushButton(self.frame)
        self.btn_1.setObjectName(u"btn_1")
        self.btn_1.setFont(font2)
        self.btn_1.setStyleSheet(u"text-align:left;\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(238, 51, 48);\n"
"border-radius: 10px;\n"
"padding-left: 20px;\n"
"")

        self.verticalLayout_2.addWidget(self.btn_1)

        self.btn_2 = QPushButton(self.frame)
        self.btn_2.setObjectName(u"btn_2")
        self.btn_2.setFont(font2)
        self.btn_2.setStyleSheet(u"text-align:left;\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(238, 51, 48);\n"
"border-radius: 10px;\n"
"padding-left: 20px;\n"
"")

        self.verticalLayout_2.addWidget(self.btn_2)

        self.btn_3 = QPushButton(self.frame)
        self.btn_3.setObjectName(u"btn_3")
        self.btn_3.setFont(font2)
        self.btn_3.setStyleSheet(u"text-align:left;\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(238, 51, 48);\n"
"border-radius: 10px;\n"
"padding-left: 20px;\n"
"")

        self.verticalLayout_2.addWidget(self.btn_3)

        self.btn_4 = QPushButton(self.frame)
        self.btn_4.setObjectName(u"btn_4")
        self.btn_4.setFont(font2)
        self.btn_4.setStyleSheet(u"text-align:left;\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(238, 51, 48);\n"
"border-radius: 10px;\n"
"padding-left: 20px;\n"
"")

        self.verticalLayout_2.addWidget(self.btn_4)

        self.btn_5 = QPushButton(self.frame)
        self.btn_5.setObjectName(u"btn_5")
        self.btn_5.setFont(font2)
        self.btn_5.setStyleSheet(u"text-align:left;\n"
"background-color: rgb(255, 255, 255);\n"
"color: rgb(238, 51, 48);\n"
"border-radius: 10px;\n"
"padding-left: 20px;\n"
"")

        self.verticalLayout_2.addWidget(self.btn_5)

        self.stack.addWidget(self.page_multiple)

        self.verticalLayout.addWidget(self.stack)


        self.retranslateUi(SurveyScreen)

        self.stack.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(SurveyScreen)
    # setupUi

    def retranslateUi(self, SurveyScreen):
        SurveyScreen.setWindowTitle(QCoreApplication.translate("SurveyScreen", u"Survey", None))
        self.img.setText("")
        self.question.setText(QCoreApplication.translate("SurveyScreen", u"When is your birthday?", None))
        self.btn_true.setText(QCoreApplication.translate("SurveyScreen", u"TRUE", None))
        self.btn_false.setText(QCoreApplication.translate("SurveyScreen", u"FALSE", None))
        self.btn_submit.setText(QCoreApplication.translate("SurveyScreen", u"SUBMIT", None))
        self.btn_0.setText(QCoreApplication.translate("SurveyScreen", u"A) June 2nd", None))
        self.btn_1.setText(QCoreApplication.translate("SurveyScreen", u"B) October 3rd", None))
        self.btn_2.setText(QCoreApplication.translate("SurveyScreen", u"C) November 17th", None))
        self.btn_3.setText(QCoreApplication.translate("SurveyScreen", u"D) July 18th", None))
        self.btn_4.setText(QCoreApplication.translate("SurveyScreen", u"E) December 1st", None))
        self.btn_5.setText(QCoreApplication.translate("SurveyScreen", u"F) March 3rd", None))
    # retranslateUi

