# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'dispense.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_DispenseScreen(object):
    def setupUi(self, DispenseScreen):
        if not DispenseScreen.objectName():
            DispenseScreen.setObjectName(u"DispenseScreen")
        DispenseScreen.resize(1280, 800)
        self.img = QLabel(DispenseScreen)
        self.img.setObjectName(u"img")
        self.img.setGeometry(QRect(0, 0, 1280, 800))
        self.img.setPixmap(QPixmap(u":/img/img/background.jpg"))
        self.label = QLabel(DispenseScreen)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 50, 1280, 700))
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(50)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(238, 51, 48);")
        self.label.setAlignment(Qt.AlignCenter)
        self.label.setWordWrap(True)

        self.retranslateUi(DispenseScreen)

        QMetaObject.connectSlotsByName(DispenseScreen)
    # setupUi

    def retranslateUi(self, DispenseScreen):
        DispenseScreen.setWindowTitle(QCoreApplication.translate("DispenseScreen", u"Dispense", None))
        self.img.setText("")
        self.label.setText(QCoreApplication.translate("DispenseScreen", u"If 62% of students refill sheets\n"
"then we could avoid 45% of CO2\n"
"emissions from landry detergent.\n"
"\n"
"If every industry achieved a 45% of CO2 reduction,\n"
"we could meet the IPCC goals of 1.5\u00b0C", None))
    # retranslateUi

