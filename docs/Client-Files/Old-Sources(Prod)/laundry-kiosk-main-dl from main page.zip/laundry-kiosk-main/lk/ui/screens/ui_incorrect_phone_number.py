# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'incorrect_phone_number.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_IncorrectPhoneNumberScreen(object):
    def setupUi(self, IncorrectPhoneNumberScreen):
        if not IncorrectPhoneNumberScreen.objectName():
            IncorrectPhoneNumberScreen.setObjectName(u"IncorrectPhoneNumberScreen")
        IncorrectPhoneNumberScreen.resize(1280, 800)
        IncorrectPhoneNumberScreen.setStyleSheet(u"")
        self.lb_background = QLabel(IncorrectPhoneNumberScreen)
        self.lb_background.setObjectName(u"lb_background")
        self.lb_background.setGeometry(QRect(0, 0, 1280, 800))
        self.lb_background.setPixmap(QPixmap(u":/img/img/background.jpg"))
        self.label = QLabel(IncorrectPhoneNumberScreen)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(140, 70, 1000, 141))
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(50)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(238, 51, 48);")
        self.label.setAlignment(Qt.AlignCenter)
        self.label_2 = QLabel(IncorrectPhoneNumberScreen)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(0, 520, 1280, 231))
        font1 = QFont()
        font1.setFamily(u"Owners XNarrow")
        font1.setPointSize(45)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_2.setFont(font1)
        self.label_2.setStyleSheet(u"color: rgb(238, 51, 48);")
        self.label_2.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(IncorrectPhoneNumberScreen)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(240, 280, 800, 215))
        self.label_3.setPixmap(QPixmap(u":/img/img/spill_logo.png"))

        self.retranslateUi(IncorrectPhoneNumberScreen)

        QMetaObject.connectSlotsByName(IncorrectPhoneNumberScreen)
    # setupUi

    def retranslateUi(self, IncorrectPhoneNumberScreen):
        IncorrectPhoneNumberScreen.setWindowTitle(QCoreApplication.translate("IncorrectPhoneNumberScreen", u"Incorrect Phone Number", None))
        self.lb_background.setText("")
        self.label.setText(QCoreApplication.translate("IncorrectPhoneNumberScreen", u"INCORRECT INPUT OR NUMBER\n"
"PLEASE TRY AGAIN", None))
        self.label_2.setText(QCoreApplication.translate("IncorrectPhoneNumberScreen", u"IF YOU HAVEN'T SIGNED UP YET, PLEASE SCAN THE QR CODE\n"
"ON THE MACHINE TO OPTAIN YOUR SUBSCRIPTION", None))
        self.label_3.setText("")
    # retranslateUi

