# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'out_of_order.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_OutOfOrderScreen(object):
    def setupUi(self, OutOfOrderScreen):
        if not OutOfOrderScreen.objectName():
            OutOfOrderScreen.setObjectName(u"OutOfOrderScreen")
        OutOfOrderScreen.resize(1280, 800)
        OutOfOrderScreen.setStyleSheet(u"background-color: rgb(238, 51, 48);")
        self.label = QLabel(OutOfOrderScreen)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(39, 50, 1211, 261))
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(55)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(255, 255, 255);")
        self.label.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(OutOfOrderScreen)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(240, 410, 800, 215))
        self.label_3.setPixmap(QPixmap(u":/img/img/spill_logo_alt.png"))

        self.retranslateUi(OutOfOrderScreen)

        QMetaObject.connectSlotsByName(OutOfOrderScreen)
    # setupUi

    def retranslateUi(self, OutOfOrderScreen):
        OutOfOrderScreen.setWindowTitle(QCoreApplication.translate("OutOfOrderScreen", u"Out of Order", None))
        self.label.setText(QCoreApplication.translate("OutOfOrderScreen", u"TEMPORARILY OUT OF ORDER\n"
"PLEASE TRY AGAIN SOON", None))
        self.label_3.setText("")
    # retranslateUi

