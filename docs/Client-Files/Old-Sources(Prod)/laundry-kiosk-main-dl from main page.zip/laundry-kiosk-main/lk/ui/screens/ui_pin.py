# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'pin.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_PinScreen(object):
    def setupUi(self, PinScreen):
        if not PinScreen.objectName():
            PinScreen.setObjectName(u"PinScreen")
        PinScreen.resize(1280, 800)
        PinScreen.setStyleSheet(u"")
        self.lb_background = QLabel(PinScreen)
        self.lb_background.setObjectName(u"lb_background")
        self.lb_background.setGeometry(QRect(0, 0, 1280, 800))
        self.lb_background.setPixmap(QPixmap(u":/img/img/background.jpg"))
        self.title = QLabel(PinScreen)
        self.title.setObjectName(u"title")
        self.title.setGeometry(QRect(140, 50, 1000, 111))
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(70)
        font.setBold(True)
        font.setWeight(75)
        self.title.setFont(font)
        self.title.setStyleSheet(u"color: rgb(238, 51, 48);")
        self.title.setAlignment(Qt.AlignCenter)
        self.btn_dispense = QToolButton(PinScreen)
        self.btn_dispense.setObjectName(u"btn_dispense")
        self.btn_dispense.setGeometry(QRect(430, 650, 420, 100))
        font1 = QFont()
        font1.setFamily(u"Owners XNarrow")
        font1.setPointSize(45)
        font1.setBold(True)
        font1.setWeight(75)
        self.btn_dispense.setFont(font1)
        self.btn_dispense.setStyleSheet(u"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 210px 50px;")
        self.btn_scented = QToolButton(PinScreen)
        self.btn_scented.setObjectName(u"btn_scented")
        self.btn_scented.setGeometry(QRect(130, 390, 360, 80))
        font2 = QFont()
        font2.setFamily(u"Owners XNarrow")
        font2.setPointSize(40)
        font2.setBold(True)
        font2.setWeight(75)
        self.btn_scented.setFont(font2)
        self.btn_scented.setStyleSheet(u"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 180px 40px;")
        self.btn_unscented = QToolButton(PinScreen)
        self.btn_unscented.setObjectName(u"btn_unscented")
        self.btn_unscented.setGeometry(QRect(790, 390, 360, 80))
        self.btn_unscented.setFont(font2)
        self.btn_unscented.setStyleSheet(u"background-color: rgb(255, 56, 21);\n"
"color: rgb(255, 255, 255);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 180px 40px;")
        self.frame_input = QFrame(PinScreen)
        self.frame_input.setObjectName(u"frame_input")
        self.frame_input.setGeometry(QRect(390, 150, 500, 531))
        self.frame_input.setFrameShape(QFrame.StyledPanel)
        self.frame_input.setFrameShadow(QFrame.Raised)
        self.widget_2 = QWidget(self.frame_input)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setGeometry(QRect(50, 20, 400, 90))
        self.widget_2.setStyleSheet(u"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-radius: 200px 45px;")
        self.horizontalLayout_5 = QHBoxLayout(self.widget_2)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(100, 25, 100, 25)
        self.val_0 = QLabel(self.widget_2)
        self.val_0.setObjectName(u"val_0")
        font3 = QFont()
        font3.setFamily(u"Owners XNarrow")
        font3.setPointSize(30)
        font3.setUnderline(False)
        self.val_0.setFont(font3)
        self.val_0.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_0.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_0)

        self.val_1 = QLabel(self.widget_2)
        self.val_1.setObjectName(u"val_1")
        self.val_1.setFont(font3)
        self.val_1.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_1.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_1)

        self.val_2 = QLabel(self.widget_2)
        self.val_2.setObjectName(u"val_2")
        self.val_2.setFont(font3)
        self.val_2.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_2.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_2)

        self.val_3 = QLabel(self.widget_2)
        self.val_3.setObjectName(u"val_3")
        self.val_3.setFont(font3)
        self.val_3.setStyleSheet(u"color: rgb(255, 0, 0);\n"
"border-width: 1px; \n"
"border-style: solid; \n"
"border-color: red;\n"
"border-top-style:none;\n"
"border-left-style:none;\n"
"border-right-style:none;")
        self.val_3.setAlignment(Qt.AlignCenter)

        self.horizontalLayout_5.addWidget(self.val_3)

        self.frame_keyboard = QFrame(self.frame_input)
        self.frame_keyboard.setObjectName(u"frame_keyboard")
        self.frame_keyboard.setGeometry(QRect(100, 120, 300, 401))
        self.frame_keyboard.setFrameShape(QFrame.NoFrame)
        self.frame_keyboard.setFrameShadow(QFrame.Plain)
        self.frame_keyboard.setLineWidth(0)
        self.verticalLayout = QVBoxLayout(self.frame_keyboard)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.btn_1 = QToolButton(self.frame_keyboard)
        self.btn_1.setObjectName(u"btn_1")
        self.btn_1.setMinimumSize(QSize(70, 70))
        font4 = QFont()
        font4.setFamily(u"Owners XNarrow")
        font4.setPointSize(30)
        self.btn_1.setFont(font4)
        self.btn_1.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout.addWidget(self.btn_1)

        self.btn_2 = QToolButton(self.frame_keyboard)
        self.btn_2.setObjectName(u"btn_2")
        self.btn_2.setMinimumSize(QSize(70, 70))
        self.btn_2.setFont(font4)
        self.btn_2.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout.addWidget(self.btn_2)

        self.btn_3 = QToolButton(self.frame_keyboard)
        self.btn_3.setObjectName(u"btn_3")
        self.btn_3.setMinimumSize(QSize(70, 70))
        self.btn_3.setFont(font4)
        self.btn_3.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout.addWidget(self.btn_3)


        self.verticalLayout.addLayout(self.horizontalLayout)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.btn_4 = QToolButton(self.frame_keyboard)
        self.btn_4.setObjectName(u"btn_4")
        self.btn_4.setMinimumSize(QSize(70, 70))
        self.btn_4.setFont(font4)
        self.btn_4.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_2.addWidget(self.btn_4)

        self.btn_5 = QToolButton(self.frame_keyboard)
        self.btn_5.setObjectName(u"btn_5")
        self.btn_5.setMinimumSize(QSize(70, 70))
        self.btn_5.setFont(font4)
        self.btn_5.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_2.addWidget(self.btn_5)

        self.btn_6 = QToolButton(self.frame_keyboard)
        self.btn_6.setObjectName(u"btn_6")
        self.btn_6.setMinimumSize(QSize(70, 70))
        self.btn_6.setFont(font4)
        self.btn_6.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_2.addWidget(self.btn_6)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.btn_7 = QToolButton(self.frame_keyboard)
        self.btn_7.setObjectName(u"btn_7")
        self.btn_7.setMinimumSize(QSize(70, 70))
        self.btn_7.setFont(font4)
        self.btn_7.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_3.addWidget(self.btn_7)

        self.btn_8 = QToolButton(self.frame_keyboard)
        self.btn_8.setObjectName(u"btn_8")
        self.btn_8.setMinimumSize(QSize(70, 70))
        self.btn_8.setFont(font4)
        self.btn_8.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_3.addWidget(self.btn_8)

        self.btn_9 = QToolButton(self.frame_keyboard)
        self.btn_9.setObjectName(u"btn_9")
        self.btn_9.setMinimumSize(QSize(70, 70))
        self.btn_9.setFont(font4)
        self.btn_9.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_3.addWidget(self.btn_9)


        self.verticalLayout.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.widget = QWidget(self.frame_keyboard)
        self.widget.setObjectName(u"widget")
        self.widget.setMaximumSize(QSize(70, 70))

        self.horizontalLayout_4.addWidget(self.widget)

        self.btn_0 = QToolButton(self.frame_keyboard)
        self.btn_0.setObjectName(u"btn_0")
        self.btn_0.setMinimumSize(QSize(70, 70))
        self.btn_0.setFont(font4)
        self.btn_0.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_4.addWidget(self.btn_0)

        self.btn_b = QToolButton(self.frame_keyboard)
        self.btn_b.setObjectName(u"btn_b")
        self.btn_b.setMinimumSize(QSize(70, 70))
        self.btn_b.setFont(font4)
        self.btn_b.setStyleSheet(u"color: rgb(255, 255, 255);\n"
"border: none;\n"
"border-radius: 35px;\n"
"background-color: rgb(255, 0, 0);")

        self.horizontalLayout_4.addWidget(self.btn_b)


        self.verticalLayout.addLayout(self.horizontalLayout_4)

        self.lb_background.raise_()
        self.title.raise_()
        self.btn_dispense.raise_()
        self.btn_scented.raise_()
        self.frame_input.raise_()
        self.btn_unscented.raise_()

        self.retranslateUi(PinScreen)

        QMetaObject.connectSlotsByName(PinScreen)
    # setupUi

    def retranslateUi(self, PinScreen):
        PinScreen.setWindowTitle(QCoreApplication.translate("PinScreen", u"Pin", None))
        self.lb_background.setText("")
        self.title.setText(QCoreApplication.translate("PinScreen", u"ENTER 4 DIGIT CODE", None))
        self.btn_dispense.setText(QCoreApplication.translate("PinScreen", u"DISPENSE", None))
        self.btn_scented.setText(QCoreApplication.translate("PinScreen", u"SCENTED", None))
        self.btn_unscented.setText(QCoreApplication.translate("PinScreen", u"UNSCENTED", None))
        self.val_0.setText("")
        self.val_1.setText("")
        self.val_2.setText("")
        self.val_3.setText("")
        self.btn_1.setText(QCoreApplication.translate("PinScreen", u"1", None))
        self.btn_2.setText(QCoreApplication.translate("PinScreen", u"2", None))
        self.btn_3.setText(QCoreApplication.translate("PinScreen", u"3", None))
        self.btn_4.setText(QCoreApplication.translate("PinScreen", u"4", None))
        self.btn_5.setText(QCoreApplication.translate("PinScreen", u"5", None))
        self.btn_6.setText(QCoreApplication.translate("PinScreen", u"6", None))
        self.btn_7.setText(QCoreApplication.translate("PinScreen", u"7", None))
        self.btn_8.setText(QCoreApplication.translate("PinScreen", u"8", None))
        self.btn_9.setText(QCoreApplication.translate("PinScreen", u"9", None))
        self.btn_0.setText(QCoreApplication.translate("PinScreen", u"0", None))
        self.btn_b.setText(QCoreApplication.translate("PinScreen", u"<", None))
    # retranslateUi

