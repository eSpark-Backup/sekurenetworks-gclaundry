# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'invalid_pin.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import ui.lk_rc

class Ui_InvalidPinScreen(object):
    def setupUi(self, InvalidPinScreen):
        if not InvalidPinScreen.objectName():
            InvalidPinScreen.setObjectName(u"InvalidPinScreen")
        InvalidPinScreen.resize(1280, 800)
        InvalidPinScreen.setStyleSheet(u"")
        self.lb_background = QLabel(InvalidPinScreen)
        self.lb_background.setObjectName(u"lb_background")
        self.lb_background.setGeometry(QRect(0, 0, 1280, 800))
        self.lb_background.setPixmap(QPixmap(u":/img/img/background.jpg"))
        self.label = QLabel(InvalidPinScreen)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(9, 20, 1261, 371))
        font = QFont()
        font.setFamily(u"Owners XNarrow")
        font.setPointSize(60)
        font.setBold(True)
        font.setWeight(75)
        self.label.setFont(font)
        self.label.setStyleSheet(u"color: rgb(238, 51, 48);")
        self.label.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(InvalidPinScreen)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(240, 410, 800, 215))
        self.label_3.setPixmap(QPixmap(u":/img/img/spill_logo.png"))

        self.retranslateUi(InvalidPinScreen)

        QMetaObject.connectSlotsByName(InvalidPinScreen)
    # setupUi

    def retranslateUi(self, InvalidPinScreen):
        InvalidPinScreen.setWindowTitle(QCoreApplication.translate("InvalidPinScreen", u"Invalid PIN", None))
        self.lb_background.setText("")
        self.label.setText(QCoreApplication.translate("InvalidPinScreen", u"INVALID PIN\n"
"PLEASE TRY AGAIN", None))
        self.label_3.setText("")
    # retranslateUi

