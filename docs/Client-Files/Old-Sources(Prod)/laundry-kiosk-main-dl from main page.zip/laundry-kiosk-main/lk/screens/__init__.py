from screens.dispense import DispenseScreen
from screens.incorrect_phone_number import IncorrectPhoneNumberScreen
from screens.invalid_pin import InvalidPinScreen
from screens.out_of_order import OutOfOrderScreen
from screens.phone_number import PhoneNumberScreen
from screens.pin import PinScreen
from screens.survey import SurveyScreen
from screens.welcome import WelcomeScreen

screens = {
    'welcome': WelcomeScreen,
    'phone_number': PhoneNumberScreen,
    'incorrect_phone_number': IncorrectPhoneNumberScreen,
    'pin': PinScreen,
    'invalid_pin': InvalidPinScreen,
    'dispense': DispenseScreen,
    'survey': SurveyScreen,
    'out_of_order': OutOfOrderScreen,
}
