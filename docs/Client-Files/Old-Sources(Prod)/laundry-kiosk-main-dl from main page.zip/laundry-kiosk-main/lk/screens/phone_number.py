from functools import partial

from PySide2.QtCore import QTimer

from screens.base import BaseScreen
from ui.screens.ui_phone_number import Ui_PhoneNumberScreen
from utils.db import find_user_by_phone
from utils.logger import logger


class PhoneNumberScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app)
        self.ui = Ui_PhoneNumberScreen()
        self.ui.setupUi(self)
        self._index = 0
        self._value = ''
        self.ui.btn_send.setVisible(False)
        setattr(self, "PhoneNumberScreen._mask_value", self._mask_value)
        setattr(self, "PhoneNumberScreen._on_btn", self._on_btn)
        for v in list(range(10)) + ['b']:
            getattr(self.ui, f"btn_{v}").released.connect(partial(self._on_btn, v))
        setattr(self, "PhoneNumberScreen._on_btn_send", self._on_btn_send)
        self.ui.btn_send.released.connect(self._on_btn_send)

    def _on_btn(self, v):
        if v == 'b':
            if self._index > 0:
                self._value = self._value[:-1]
                getattr(self.ui, f"val_{self._index - 1}").setText('')
                self._index -= 1
                self.ui.btn_send.setVisible(False)
        else:
            if self._index < 10:
                wid_val = getattr(self.ui, f"val_{self._index}")
                wid_val.setText(str(v))
                self._value += str(v)
                QTimer.singleShot(500, partial(self._mask_value, wid_val, self._index))
                self._index += 1
                self.ui.btn_send.setVisible(self._index == 10)
                self.timeout = 30 if self._index == 10 else 20

    def _mask_value(self, widget, index):
        if self._index >= index + 1:
            widget.setText('*')
        else:
            widget.setText('')

    def _on_btn_send(self):
        logger.debug(f"Entered phone number - {self._value}")
        if find_user_by_phone(self._value):
            self.app.phone_number = self._value
            self.switch_screen('pin')
        else:
            self.switch_screen('incorrect_phone_number')
