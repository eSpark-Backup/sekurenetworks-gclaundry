import threading

from PySide2.QtCore import QByteArray
from PySide2.QtGui import QMovie

from screens.base import BaseScreen
from ui.screens.ui_welcome import Ui_WelcomeScreen
from utils.api import send_data_to_server
from utils.common import read_version


class WelcomeScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app)
        self.ui = Ui_WelcomeScreen()
        self.ui.setupUi(self)
        self.movie = QMovie("lk/ui/img/touch_me.gif", QByteArray(), self)
        self.movie.setCacheMode(QMovie.CacheAll)
        self.movie.setSpeed(100)
        self.ui.gif.setMovie(self.movie)
        self.movie.start()
        self.ui.version.setText(f"Ver: {read_version()}")
        self.app.set_fault_cnt(0)

    def on_enter(self):
        self.app.cur_user = None

    def on_touched(self):
        threading.Thread(target=send_data_to_server, args=({'screenact1': True}, )).start()
        self.switch_screen('phone_number')
