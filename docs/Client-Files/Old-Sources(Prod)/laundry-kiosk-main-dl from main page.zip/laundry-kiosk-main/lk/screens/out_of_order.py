from screens.base import BaseScreen
from ui.screens.ui_out_of_order import Ui_OutOfOrderScreen


class OutOfOrderScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app, timeout=60)
        self.ui = Ui_OutOfOrderScreen()
        self.ui.setupUi(self)
