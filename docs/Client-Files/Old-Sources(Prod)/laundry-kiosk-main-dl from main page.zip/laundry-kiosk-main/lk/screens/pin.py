from functools import partial

from PySide2.QtCore import QTimer

from screens.base import BaseScreen
from ui.screens.ui_pin import Ui_PinScreen
from utils.db import login_user
from utils.logger import logger


class PinScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app, timeout=60)
        self.ui = Ui_PinScreen()
        self.ui.setupUi(self)
        self._index = 0
        self._value = ''
        self._cur_mode = None
        setattr(self, "PinScreen._mask_value", self._mask_value)
        setattr(self, "PinScreen._on_btn", self._on_btn)
        for v in list(range(10)) + ['b']:
            getattr(self.ui, f"btn_{v}").released.connect(partial(self._on_btn, v))
        self.ui.btn_dispense.setVisible(False)
        setattr(self, "PinScreen._on_btn_dispense", self._on_btn_dispense)
        self.ui.btn_dispense.released.connect(self._on_btn_dispense)
        setattr(self, "PinScreen._on_btn_type", self._on_btn_type)
        self.ui.btn_scented.setVisible(False)
        self.ui.btn_scented.released.connect(partial(self._on_btn_type, 'scented'))
        self.ui.btn_unscented.setVisible(False)
        self.ui.btn_unscented.released.connect(partial(self._on_btn_type, 'unscented'))

    def _on_btn(self, v):
        cnt = self.app.get_fault_cnt()
        if v == 'b':
            if self._index > 0 and cnt < 3:
                self._value = self._value[:-1]
                getattr(self.ui, f"val_{self._index - 1}").setText('')
                self._index -= 1
        else:
            self.timeout = 20
            if self._index < 4:
                widget = getattr(self.ui, f"val_{self._index}")
                widget.setText(str(v))
                self._value += str(v)
                QTimer.singleShot(500, partial(self._mask_value, widget, self._index))
                self._index += 1
            if self._index == 4:
                self._parse_code()

    def _mask_value(self, widget, index):
        if self._index >= index + 1:
            widget.setText('*')
        else:
            widget.setText('')

    def _parse_code(self):
        cnt = self.app.get_fault_cnt()
        logger.debug(f"Entered code - {self._value}")
        user = login_user(phone=self.app.phone_number, pin=self._value)
        if user is None:
            self.app.set_fault_cnt(min(cnt + 1, 3))
            self.switch_screen('invalid_pin')
        else:
            self.app.cur_user = user
            self.ui.title.setText('SHEET TYPE')
            self.ui.frame_input.setVisible(False)
            self.ui.btn_dispense.setVisible(True)
            self.ui.btn_scented.setVisible(True)
            self.ui.btn_unscented.setVisible(True)

    def _on_btn_type(self, s_type):
        self._cur_mode = s_type
        getattr(self.ui, f"btn_{s_type}").setStyleSheet(
            "color:rgb(255,56,21);border-width:1px;border-style:solid;border-color:red;border-radius:180px 40px;"
            "background-color:rgb(255,255,255);")
        other_key = 'unscented' if s_type == 'scented' else 'scented'
        getattr(self.ui, f"btn_{other_key}").setStyleSheet(
            "background-color:rgb(255,56,21);border-width:1px;border-style:solid;border-color:red;"
            "border-radius:180px 40px;color: #ffffff")

    def _on_btn_dispense(self):
        if self._cur_mode is not None:
            logger.debug(f"Dispensing {self._cur_mode}")
            self.app.set_cur_mode(self._cur_mode)
            self.switch_screen('dispense')
