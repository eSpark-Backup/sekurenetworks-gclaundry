from functools import partial
from screens.base import BaseScreen
from ui.screens.ui_survey import Ui_SurveyScreen
from utils.db import find_random_question, add_answer
from utils.logger import logger


class SurveyScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app, timeout=90)
        self.ui = Ui_SurveyScreen()
        self.ui.setupUi(self)
        setattr(self, "SurveyScreen._on_answer", self._on_answer)
        for k in {'true', 'false', 0, 1, 2, 3, 4, 5}:
            getattr(self.ui, f"btn_{k}").released.connect(partial(self._on_answer, k))
        setattr(self, "SurveyScreen._on_btn_submit", self._on_btn_submit)
        self.ui.btn_submit.released.connect(self._on_btn_submit)
        self._question = find_random_question(self.app.cur_user)
        if 'TRUE' in self._question['answers']:
            self.ui.stack.setCurrentWidget(self.ui.page_yes_no)
        self.ui.question.setText(self._question['question'])
        self._cur_answer = None

    def _on_answer(self, val):
        logger.debug(f"Answered - {val}")
        if val in {'true', 'false'}:
            self.submit_answer(val)
        else:
            self._cur_answer = self._question['answers'][int(val)]
            for k in range(6):
                sh = f"text-align:left;background-color:#{'FFFFFF' if k != int(val) else 'EE3330'};" \
                     f"color:#{'FFFFFF' if k == int(val) else 'EE3330'};border-radius:10px;padding-left:20px;"
                getattr(self.ui, f"btn_{k}").setStyleSheet(sh)

    def _on_btn_submit(self):
        if self._cur_answer is None:
            return
        self.submit_answer(self._cur_answer)

    def submit_answer(self, answer):
        logger.debug(f"Question: {self._question['question']}, answer: {answer}")
        add_answer(self.app.cur_user, self._question, answer)
        self.switch_screen('welcome')
