import threading

from ui.screens.ui_invalid_pin import Ui_InvalidPinScreen

from screens.base import BaseScreen
from utils.api import resend_password


class InvalidPinScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app, timeout=15)
        self.ui = Ui_InvalidPinScreen()
        self.ui.setupUi(self)
        if self.app.get_fault_cnt() == 3:
            self.ui.label.setText("YOU HAVE ENTERED AN INVALID PIN\nWE HAVE SENT YOU A NEW TEMPORARY\n"
                                  "PIN VIA SMS TO THE PHONE NUMBER ON ACCOUNT")
            threading.Thread(target=resend_password, args=(self.app.phone_number, )).start()

    def on_touched(self):
        self.switch_screen('pin' if self.app.get_fault_cnt() < 3 else 'phone_number')
