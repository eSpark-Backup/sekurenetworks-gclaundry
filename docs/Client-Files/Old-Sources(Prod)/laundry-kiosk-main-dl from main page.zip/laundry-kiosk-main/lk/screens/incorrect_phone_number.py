from screens.base import BaseScreen
from ui.screens.ui_incorrect_phone_number import Ui_IncorrectPhoneNumberScreen


class IncorrectPhoneNumberScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app, prev_screen='phone_number', timeout=10)
        self.ui = Ui_IncorrectPhoneNumberScreen()
        self.ui.setupUi(self)

    def on_touched(self):
        self.switch_screen('phone_number')
