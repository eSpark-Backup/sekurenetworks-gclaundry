import random

from screens.base import BaseScreen
from settings import ENV_MESSAGES
from ui.screens.ui_dispense import Ui_DispenseScreen
from utils.common import is_rpi


class DispenseScreen(BaseScreen):

    def __init__(self, app):
        super().__init__(app, timeout=10)
        self.ui = Ui_DispenseScreen()
        self.ui.setupUi(self)
        self.ui.label.setText(random.choice(ENV_MESSAGES))

    def on_touched(self):
        if not is_rpi:
            self.switch_screen('survey')

    def on_leave(self):
        self.app.set_motor_speed(0)
