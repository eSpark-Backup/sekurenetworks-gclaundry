from PySide2.QtCore import QTimer
from PySide2.QtWidgets import QWidget


class BaseScreen(QWidget):

    def __init__(self, app, timeout=20, prev_screen="welcome"):
        super().__init__()
        self.app = app
        self.ui = None
        self.timeout = timeout
        self.prev_screen = prev_screen
        setattr(self, f"{self.__class__.__name__}.on_enter", self.on_enter)
        QTimer.singleShot(50, self.on_enter)

    def switch_screen(self, screen_name, **kwargs):
        self.app.switch_screen(screen_name, **kwargs)

    def on_enter(self):
        pass

    def on_touched(self):
        pass

    def on_leave(self):
        pass
