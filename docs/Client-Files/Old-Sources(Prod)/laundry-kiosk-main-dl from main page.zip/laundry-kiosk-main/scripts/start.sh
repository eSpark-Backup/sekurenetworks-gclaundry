screen -mS lk -d
screen -S lk -X stuff "cd DIR\\r"
screen -S lk -X stuff "python3 main.py\\r"
