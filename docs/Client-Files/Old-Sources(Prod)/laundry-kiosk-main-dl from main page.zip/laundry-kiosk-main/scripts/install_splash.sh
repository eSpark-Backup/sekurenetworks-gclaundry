cur_dir="$( cd "$(dirname "$0")" ; pwd -P )"
user="$(id -u -n)"

sudo apt install -y fbi

sudo cp ${cur_dir}/../lk/ui/img/splash.jpg /opt/splash.jpg
sudo cp ${cur_dir}/splashscreen.service /etc/systemd/system/splashscreen.service

sudo systemctl enable splashscreen
