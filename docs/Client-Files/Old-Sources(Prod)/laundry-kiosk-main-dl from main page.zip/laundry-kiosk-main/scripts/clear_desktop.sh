cur_dir="$( cd "$(dirname "$0")" ; pwd -P )"

sudo apt install -y unclutter
echo "@unclutter -idle 0" | tee -a ~/.config/lxsession/LXDE-pi/autostart

# Remove SSH warning
sudo apt purge -y libpam-chksshpwd

# Remove login prompt
sudo systemctl disable getty@tty1

# Disable booting logo and messages
echo "disable_splash=1" | sudo tee -a /boot/config.txt
sudo systemctl mask plymouth-start.service
sudo sed -i -- "s/$/ logo.nologo quiet loglevel=3 vt.global_cursor_default=0 systemd.show_status=0 plymouth.ignore-serial-consoles plymouth.enable=0 consoleblank=0/" /boot/cmdline.txt
sudo sed -i -- "s/console=tty1/console=tty3/g" /boot/cmdline.txt

# Disable some services to reduce booting time
sudo systemctl disable hciuart
echo "boot_delay=0" | sudo tee -a /boot/config.txt
echo "hdmi_force_hotplug=1" | sudo tee -a /boot/config.txt

# Hide mouse cursor
sudo sed -i -- "s/#xserver-command=X/xserver-command=X -nocursor/" /etc/lightdm/lightdm.conf

# Disable screen saver
echo "xset s off" | sudo tee -a /etc/xdg/lxsession/LXDE-pi/autostart
echo "@xset s noblank" | sudo tee -a /etc/xdg/lxsession/LXDE-pi/autostart
echo "xset -dpms" | sudo tee -a /etc/xdg/lxsession/LXDE-pi/autostart

# Set wallpaper
sudo cp ${cur_dir}/../ui/img/splash.jpg /usr/share/rpd-wallpaper/temple.jpg

# Hide menu bar
sudo sed -i -- "s/@lxpanel --profile LXDE-pi/#@lxpanel --profile LXDE-pi/" /etc/xdg/lxsession/LXDE-pi/autostart

# Clear desktop
sudo sed -i -- "s/show_trash=1/show_trash=0/" /etc/xdg/pcmanfm/LXDE-pi/desktop-items-0.conf
sudo sed -i -- "s/show_mounts=1/show_mounts=0/" /etc/xdg/pcmanfm/LXDE-pi/desktop-items-0.conf
if test -f ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf; then
  sed -i -- "s/show_trash=1/show_trash=0/" ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
  sed -i -- "s/show_mounts=1/show_mounts=0/" ~/.config/pcmanfm/LXDE-pi/desktop-items-0.conf
fi

# Disable welcome wizard
sudo rm /etc/xdg/autostart/piwiz.desktop
