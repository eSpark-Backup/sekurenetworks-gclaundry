from lk.laundry_kiosk import start_kiosk


if __name__ == '__main__':

    start_kiosk()
