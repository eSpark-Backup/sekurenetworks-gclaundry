echo "Setting up LaundryKiosk..."
sudo apt update

cur_dir="$( cd "$(dirname "$0")" ; pwd -P )"

sed -i -- "s/https:\/\/gitlab.com/https:\/\/gitlab+deploy-token-1609844:YsbLCieFPfuyc1zkxnyK@gitlab.com/g" .git/config

# Install PySide2 and some dependencies
sudo apt install -y python3-pyside2* qml-module-qtquick-virtualkeyboard matchbox-keyboard python3-pyside2uic pyside2-tools dfu-util
sudo sed -i -- "s/#! \/usr\/bin\/python2/#! \/usr\/bin\/python3/g" /usr/bin/pyside2-uic

sudo pip3 install -U pip setuptools wheel
sudo pip3 install -r ${cur_dir}/requirements.txt

# Install MySQL db
sudo apt install -y mariadb-server
sudo mysql -e "CREATE DATABASE laundry_kiosk; GRANT ALL PRIVILEGES ON *.* TO root@localhost WITH GRANT OPTION;FLUSH PRIVILEGES;"
sudo mysql -e "SET PASSWORD FOR root@localhost = PASSWORD('TopSecret123');FLUSH PRIVILEGES;"
printf "TopSecret123\n n\n n\n n\n y\n y\n y\n" | sudo mysql_secure_installation

# Install watchdog
echo "dtparam=watchdog=on" | sudo tee -a /boot/config.txt
sudo apt-get install -y watchdog
echo "watchdog-device = /dev/watchdog" | sudo tee -a /etc/watchdog.conf
echo "watchdog-timeout = 15" | sudo tee -a /etc/watchdog.conf
echo "max-load-1 = 400" | sudo tee -a /etc/watchdog.conf
echo "max-load-5 = 300" | sudo tee -a /etc/watchdog.conf
echo "max-load-15 = 200" | sudo tee -a /etc/watchdog.conf
echo "min-memory = 1" | sudo tee -a /etc/watchdog.conf
echo "allocatable-memory = 1" | sudo tee -a /etc/watchdog.conf
sudo systemctl enable watchdog
sudo systemctl start watchdog

# Increase GPU memory size
sudo echo "gpu_mem=256" | sudo tee -a /boot/config.txt

# Configure UDEV rule for the controller board.
sudo usermod -a -G dialout $USER
sudo usermod -a -G plugdev $USER
sudo bash -c 'cat > /etc/udev/rules.d/99-usb-serial-udev.rules' << EOF
ATTRS{idVendor}=="0483", ATTRS{idProduct}=="5740", MODE:="0666", ENV{ID_MM_DEVICE_IGNORE}="1", ENV{ID_MM_PORT_IGNORE}="1"
EOF
sudo bash -c 'cat > /etc/udev/rules.d/77-mm-usb-device-blacklist.rules' << EOF
ATTRS{idProduct}=="d058", ATTRS{idVendor}=="2b04", MODE="0666", GROUP="plugdev"
EOF
sudo service udev restart

# Clear desktop and install splash service
bash ${cur_dir}/scripts/clear_desktop.sh
bash ${cur_dir}/scripts/install_splash.sh

# Allow port 80 to pi
sudo touch /etc/sysctl.d/50-unprivileged-ports.conf
echo "net.ipv4.ip_unprivileged_port_start=0" | sudo tee -a /etc/sysctl.d/50-unprivileged-ports.conf
sudo sysctl --system

# Enable Auto Start
sudo apt install -y screen
sudo cp ${cur_dir}/scripts/start.sh /opt/
sudo sed -i -- "s/DIR/${cur_dir////\\/}/g" /opt/start.sh
echo "bash /opt/start.sh" | sudo tee -a /etc/xdg/lxsession/LXDE-pi/autostart

# Create token to prevent copycat
python3 ${cur_dir}/lk/utils/create_token.py

# Create a sample user
python3 ${cur_dir}/lk/utils/db.py -n "John Doe" -p 9053315695 -c 8181

# Compile UI files
python3 ${cur_dir}/lk/ui/compile_ui.py

# Cythonize to protect python files
cd ${cur_dir}
python3 compile.py build_ext --inplace && rm -r build

rm setup.sh README.md compile.py scripts/* doc/*
echo "Finished Installation. Please reboot now."