# rpi-CM4-kiosk
Raspberry PI CM4 Software for Customer Interface LCD Panel / Touchscreen

## Components

- Raspberry Pi Compute Model 4

- Touchscreen

## Installation

- Download the **Raspbian Buster Desktop** image from [here](http://downloads.raspberrypi.org/raspios_oldstable_armhf/images/raspios_oldstable_armhf-2022-09-26/2022-09-22-raspios-buster-armhf.img.xz) and flash your RPi.

- Clone this repository

    ```shell script
    cd /home/pi
    sudo apt update
    sudo apt install -y git
    git clone https://gitlab.com/shineon93/laundry-kiosk
    ```

- Install everything on RPi

    ```shell script
    cd /home/pi/laundry-kiosk
    bash setup.sh
    ```
- And reboot! :)
