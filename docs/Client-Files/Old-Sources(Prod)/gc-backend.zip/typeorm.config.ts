import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { TypeOrmModuleOptions, TypeOrmOptionsFactory } from '@nestjs/typeorm';

type DB_TYPES = 'mysql' | 'postgres';

@Injectable()
export class TypeOrmConfigService implements TypeOrmOptionsFactory {
  constructor(private configService: ConfigService) {}
  createTypeOrmOptions(): TypeOrmModuleOptions {
    return {
      host: this.configService.get<string>('DB_HOST', 'localhost'),
      type: this.configService.get<DB_TYPES>('DB_TYPE', 'postgres'),
      port: this.configService.get<number>('DB_PORT', 5432),
      username: this.configService.get<string>('DB_USERNAME', 'db_user'),
      password: this.configService.get<string>('DB_PASSWORD', 'db_password'),
      database: this.configService.get<string>('DB_NAME', 'db_name'),
      entities: [__dirname + '/../*/.entity.{js,ts}'],
      retryAttempts: 3,
      extra: {
        connectionLimit: 5,
      },
    };
  }
}
