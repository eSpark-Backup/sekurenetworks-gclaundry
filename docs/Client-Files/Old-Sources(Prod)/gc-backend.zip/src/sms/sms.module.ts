import { Module } from '@nestjs/common';
import { SmsService } from './sms.service';
import { SmsController } from './sms.controller';
import { EmailModule } from '../common/email/email.module';
import { MongooseModule } from '@nestjs/mongoose';
import { SmsTransaction, SmsTransactionSchema } from './entities/sms.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: SmsTransaction.name, schema: SmsTransactionSchema },
    ]),
    EmailModule,
  ],
  providers: [SmsService],
  controllers: [SmsController],
  exports: [SmsService],
})
export class SmsModule {}
