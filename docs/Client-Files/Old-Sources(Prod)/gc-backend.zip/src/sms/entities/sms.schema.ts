import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { now, Document } from 'mongoose';
import { ObjectId } from 'mongodb';

export type SmsTransactionDocument = SmsTransaction & Document;
@Schema()
export class SmsTransaction {
  @Prop({ type: ObjectId })
  _id: ObjectId;

  @Prop()
  kioskId: string;

  @Prop()
  phone: string;

  @Prop()
  otp: string;

  @Prop({ default: now() })
  created_at: Date;

  @Prop({ default: now() })
  updated_at: Date;
}
export const SmsTransactionSchema =
  SchemaFactory.createForClass(SmsTransaction);
