import { Module } from '@nestjs/common';
import { Email } from './email.service';

@Module({
  providers: [Email],
  exports: [Email],
})
export class EmailModule {}
