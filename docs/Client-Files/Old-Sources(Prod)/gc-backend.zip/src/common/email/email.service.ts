import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as sendgrid from '@sendgrid/mail';

@Injectable()
export class Email {
  constructor(private readonly configService: ConfigService) {
    sendgrid.setApiKey(this.configService.get('email.sendgrid_api_key'));
  }

  async sendEmail(options) {
    try {
      const msg = {
        to: options.to,
        from: options.from,
        templateId: options.template_id,
        dynamicTemplateData: {
          ...options,
        },
      };
      return await sendgrid.send(msg);
    } catch (e) {
      console.log('++++ e +++', e);
    }
  }
}
