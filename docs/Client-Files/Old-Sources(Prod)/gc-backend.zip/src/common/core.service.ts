import {
  InternalServerErrorException,
  NotFoundException,
} from '@nestjs/common';
import { APP_ENV } from '../config/configuration';

export class CoreService {
  private readonly CURRENT_ENV;

  constructor(protected readonly configService, private readonly repository) {
    this.CURRENT_ENV = this.configService.get('app.env');
  }

  async coreCreate(body) {
    try {
      const create = this.repository.create(body);
      return await this.repository.save(create);
    } catch (e) {
      this.throwError(e);
    }
  }

  async coreFindOne(id, notFound = true) {
    const record = await this.repository.findOne(id);
    if (!record && notFound) {
      throw new NotFoundException(
        `Sorry, Record with #${id} not found. Please check your request again`,
      );
    }
    return record;
  }

  async coreFindAll(findOptions = {}) {
    try {
      findOptions =
        Object.keys(findOptions).length === 0
          ? {
              order: {
                id: 'ASC',
              },
            }
          : findOptions;
      return await this.repository.find({
        ...findOptions,
      });
    } catch (e) {
      this.throwError(e);
    }
  }

  async coreUpdate(id, body) {
    try {
      const resourcePermission = await this.repository.preload({
        id: +id,
        ...body,
      });
      if (!resourcePermission) {
        this.throwError(
          `Sorry, Record with #${id} not found. Please check your request again`,
        );
      }
      return this.repository.save(resourcePermission);
    } catch (e) {
      this.throwError(e);
    }
  }

  async coreRemove(id) {
    try {
      const resourcePermission = await this.coreFindOne(id);
      return this.repository.remove(resourcePermission);
    } catch (e) {
      this.throwError(e);
    }
  }

  async coreReorder(body: []) {
    try {
      return await Promise.all(
        body.map(async (id, index) => {
          return await this.coreUpdate(id, { sequence: index + 1 });
        }),
      );
    } catch (e) {
      throw new InternalServerErrorException(e);
    }
  }

  protected getOrgId(current_org_id?: number, type = 'MANAGE') {
    const SUPERUSER = this.configService.get('auth.SUPERUSER');
    return 0;
  }

  private throwError(e) {
    const error = this.CURRENT_ENV === APP_ENV.DEV ? e : null;
    if (e instanceof NotFoundException) {
      throw e;
    } else {
      throw new InternalServerErrorException(error);
    }
  }
}
