import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
} from '@nestjs/common';
import { KioskService } from './kiosk.service';
import { CreateKioskDto, KioskStatus } from './dto/create-kiosk.dto';
import { UpdateKioskDto } from './dto/update-kiosk.dto';

@Controller()
export class KioskController {
  constructor(private readonly kioskService: KioskService) {}

  @Post()
  create(@Body() createCityDto: CreateKioskDto) {
    return this.kioskService.create(createCityDto);
  }

  @Get()
  findAll() {
    return this.kioskService.findAll();
  }

  @Get('/byKioskIds')
  findByKioskIds(@Query() { kioskIds }) {
    return this.kioskService.findByKioskIds(kioskIds.split(','));
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.kioskService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateKioskDto: UpdateKioskDto) {
    return this.kioskService.update(id, updateKioskDto);
  }

  @Patch(':id/activate')
  activateKiosk(@Param('id') id: string, @Body() { isActive }: KioskStatus) {
    return this.kioskService.activateKiosk(id, isActive);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.kioskService.remove(id);
  }
}
