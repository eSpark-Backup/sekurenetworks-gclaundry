import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { now, Document } from 'mongoose';
import { ObjectId } from 'mongodb';

export type KioskDocument = Kiosk & Document;

@Schema({ _id: false })
class OnSiteContact {
  @Prop()
  firstName: string;

  @Prop()
  lastName: string;

  @Prop()
  phone: string;

  @Prop()
  email: string;
}

@Schema({ _id: false })
class Address {
  @Prop()
  address: string;

  @Prop()
  city: string;

  @Prop()
  state: string;

  @Prop()
  country: string;

  @Prop()
  zip: string;
}

@Schema({ _id: false })
class Status {
  @Prop()
  limitSw1: number;

  @Prop()
  limitSw2: number;

  @Prop()
  limitSw3: number;

  @Prop()
  limitSw4: number;

  @Prop()
  limitSw5: number;

  @Prop()
  limitSw6: number;

  @Prop()
  irBreak1: number;

  @Prop()
  irBreak2: number;

  @Prop()
  irBreak3: number;

  @Prop()
  irBreak4: number;

  @Prop()
  ToF1: number;

  @Prop()
  ToF2: number;

  @Prop()
  motor1: string;

  @Prop()
  motor2: string;
}

@Schema()
export class Kiosk {
  @Prop({ type: ObjectId })
  _id: ObjectId;

  @Prop()
  kioskName: string;

  @Prop({ unique: true })
  kioskId: string;

  @Prop()
  email: string;

  @Prop({})
  macId: string;

  @Prop({ type: ObjectId, ref: 'Customer' })
  customerId: ObjectId;

  @Prop()
  communicationStatus: boolean;

  @Prop()
  errorStatus: boolean;

  @Prop()
  deployedLocation: string;

  @Prop({ type: Address })
  address: Address;

  @Prop({ type: Status })
  status: Status;

  @Prop()
  locationTag: string;

  @Prop()
  inventoryScented: string;

  @Prop()
  inventoryUnscented: string;

  @Prop()
  screen: string;

  @Prop()
  resolution: string;

  @Prop()
  mcbHWVersion: string;

  @Prop()
  mcbSWVersion: string;

  @Prop()
  sbcHWVersion: string;

  @Prop()
  sbcSWVersion: string;

  @Prop()
  motorHWVersion: string;

  @Prop()
  motorSWVersion: string;

  @Prop()
  checkInTime: string;

  @Prop([String])
  time: string[];

  @Prop({ type: OnSiteContact })
  onSiteContact: OnSiteContact;

  @Prop({ type: OnSiteContact })
  onSiteContactSecondary: OnSiteContact;

  @Prop({ default: true })
  isActive: boolean;

  @Prop()
  isNotified: boolean;

  @Prop({ default: now() })
  created_at: Date;

  @Prop({ default: now() })
  updated_at: Date;
}
export const KioskSchema = SchemaFactory.createForClass(Kiosk);
