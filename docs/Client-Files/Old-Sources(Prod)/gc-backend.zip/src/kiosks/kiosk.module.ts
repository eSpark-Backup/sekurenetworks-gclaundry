import { Module } from '@nestjs/common';
import { KioskController } from './kiosk.controller';
import { KioskService } from './kiosk.service';
import { MongooseModule } from '@nestjs/mongoose';
import { Kiosk, KioskSchema } from './entities/kiosk.schema';
import {
  Customer,
  CustomerSchema,
} from '../customers/entities/customers.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Kiosk.name, schema: KioskSchema },
      { name: Customer.name, schema: CustomerSchema },
    ]),
  ],
  controllers: [KioskController],
  providers: [KioskService],
  exports: [KioskService],
})
export class KioskModule {}
