import { Model } from 'mongoose';
import { BadRequestException, Injectable, Scope } from '@nestjs/common';
import { Kiosk, KioskDocument } from './entities/kiosk.schema';
import { CreateKioskDto, KioskSensorDto } from './dto/create-kiosk.dto';
import { UpdateKioskDto } from './dto/update-kiosk.dto';
import { InjectModel } from '@nestjs/mongoose';
import { ObjectId } from 'mongodb';
import {
  Customer,
  CustomerDocument,
} from '../customers/entities/customers.schema';
import { randomUUID } from 'crypto';
import { differenceInMinutes } from 'date-fns';

@Injectable({ scope: Scope.REQUEST })
export class KioskService {
  constructor(
    @InjectModel(Kiosk.name) private readonly kioskModel: Model<KioskDocument>,
    @InjectModel(Customer.name)
    private readonly customerModel: Model<CustomerDocument>, // private readonly customerService: CustomersService,
  ) {}

  async create(body: CreateKioskDto) {
    try {
      body._id = body._id ?? new ObjectId();
      const { customerId } = body;
      body.customerId = this.toObjectId(customerId);
      if (!body.kioskId) {
        body.kioskId = randomUUID();
      }
      const createdKiosk = new this.kioskModel(body);
      const response = await createdKiosk.save();
      if (response) {
        await this.assignCustomer(customerId, response._id);
      }
      return response;
    } catch (e) {
      console.log('++++ e ++++', e);
    }
  }

  async findAll() {
    const kiosks = await this.kioskModel.find().populate({
      path: 'customerId',
      select: '_id customerFirstName customerLastName schoolName',
    });
    const data = JSON.parse(JSON.stringify(kiosks));
    return data.map((kiosk) => {
      kiosk = JSON.parse(JSON.stringify(kiosk));
      const mins = differenceInMinutes(
        new Date(),
        new Date(kiosk['checkInTime']),
      );
      delete kiosk.communicationStatus;
      return {
        ...kiosk,
        communicationStatus: kiosk['checkInTime']
          ? mins <= 15 && mins >= 0
          : false,
      };
    });
  }

  async findOne(id) {
    return (
      this.kioskModel
        .findOne({ _id: this.toObjectId(id) })
        //.populate('customer', ['_id', 'customerFirstName'])
        .exec()
    );
  }

  async findOneByCondition(condition) {
    return this.kioskModel.findOne(condition).exec();
  }

  async findByKioskIds(kioskIds) {
    kioskIds = kioskIds.map((kioskId) => new ObjectId(kioskId));
    return this.kioskModel.find({ _id: { $in: kioskIds } }).exec();
  }

  async update(_id, updateKioskDto: UpdateKioskDto) {
    delete updateKioskDto._id;
    _id = this.toObjectId(_id);
    if (updateKioskDto.customerId) {
      updateKioskDto.customerId = new ObjectId(updateKioskDto.customerId);
    }
    const kiosk: Kiosk = await this.findOne(_id.toString());
    if (kiosk.isActive === false) {
      throw new BadRequestException(
        'Sorry but you cannot modify the information of de-activated kiosk',
      );
    }
    if (kiosk?.customerId && updateKioskDto.customerId === null) {
      await this.unAssignCustomer(kiosk.customerId, kiosk._id);
    } else if (
      kiosk?.customerId &&
      kiosk.customerId !== updateKioskDto.customerId
    ) {
      await this.reAssignCustomer(
        kiosk.customerId,
        updateKioskDto.customerId,
        kiosk._id,
      );
    } else if (!kiosk?.customerId && updateKioskDto.customerId) {
      await this.assignCustomer(updateKioskDto.customerId, kiosk._id);
    }

    return this.kioskModel.findOneAndUpdate({ _id }, updateKioskDto, {
      new: true,
    });
  }

  async assignCustomer(customerId, kioskId) {
    customerId = this.toObjectId(customerId);
    kioskId = this.toObjectId(kioskId);

    return this.customerModel.findOneAndUpdate(
      { _id: customerId },
      { $push: { kioskIds: kioskId } },
    );
  }

  async unAssignCustomer(oldCustomerId, kioskId) {
    oldCustomerId = this.toObjectId(oldCustomerId);
    kioskId = this.toObjectId(kioskId);
    return this.customerModel.findOneAndUpdate(
      { _id: oldCustomerId },
      { $pull: { kioskIds: kioskId } },
    );
  }

  async reAssignCustomer(oldCustomerId, newCustomerId, kioskId) {
    await this.unAssignCustomer(oldCustomerId, kioskId);
    await this.assignCustomer(newCustomerId, kioskId);
  }

  toObjectId(_id) {
    return typeof _id === 'string' ? new ObjectId(_id) : _id;
  }

  async updateKioskStatus(condition) {
    return this.kioskModel.findOneAndUpdate(condition, {
      updated_at: new Date().toISOString(),
    });
  }

  async remove(id) {
    const _id = this.toObjectId(id);
    const response = await this.kioskModel.findOneAndRemove({ _id });
    if (response) {
      await this.unAssignCustomer(response.customerId, _id);
    }
    return response;
  }

  async getTotalKiosk() {
    return this.kioskModel.count();
  }

  async updateKioskSensorDataByMacId(macId, updateKioskDto: KioskSensorDto) {
    return this.kioskModel.findOneAndUpdate({ macId }, updateKioskDto, {
      new: true,
    });
  }

  async activateKiosk(_id, isActive = false) {
    _id = this.toObjectId(_id);
    return this.kioskModel.findOneAndUpdate({ _id }, { isActive });
  }

  async fetchAllKiosksWithLowInventory(minPercentage = 31) {
    return this.kioskModel.find({
      $or: [
        {
          $expr: {
            $lt: [
              {
                $cond: {
                  if: {
                    $regexMatch: {
                      input: '$inventoryScented',
                      regex: /^[0-9]+%$/,
                    },
                  },
                  then: {
                    $convert: {
                      input: {
                        $trim: { input: '$inventoryScented', chars: '%' },
                      },
                      to: 'double',
                    },
                  },
                  else: false,
                },
              },
              minPercentage,
            ],
          },
        },
        {
          $expr: {
            $lt: [
              {
                $cond: {
                  if: {
                    $regexMatch: {
                      input: '$inventoryUnscented',
                      regex: /^[0-9]+%$/,
                    },
                  },
                  then: {
                    $convert: {
                      input: {
                        $trim: { input: '$inventoryUnscented', chars: '%' },
                      },
                      to: 'double',
                    },
                  },
                  else: false,
                },
              },
              minPercentage,
            ],
          },
        },
      ],
    });
  }
}
