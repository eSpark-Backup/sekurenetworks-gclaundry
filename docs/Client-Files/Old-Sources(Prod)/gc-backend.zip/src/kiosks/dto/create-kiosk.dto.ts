import {
  IsArray,
  IsBoolean,
  IsObject,
  IsOptional,
  IsString,
} from 'class-validator';
import type { ObjectId } from 'mongodb';

class OnSiteContract {
  @IsString()
  firstName: string;

  @IsString()
  @IsOptional()
  lastName: string;

  @IsString()
  @IsOptional()
  phone: string;

  @IsString()
  @IsOptional()
  email: string;
}

export class KioskSensorDto {
  @IsString()
  @IsOptional()
  inventoryScented: string;

  @IsString()
  @IsOptional()
  inventoryUnscented: string;

  @IsString()
  @IsOptional()
  screen: string;

  @IsString()
  @IsOptional()
  resolution: string;

  @IsString()
  @IsOptional()
  mcbHWVersion: string;

  @IsString()
  @IsOptional()
  mcbSWVersion: string;

  @IsString()
  @IsOptional()
  sbcHWVersion: string;

  @IsString()
  @IsOptional()
  sbcSWVersion: string;

  @IsString()
  @IsOptional()
  motorHWVersion: string;

  @IsString()
  @IsOptional()
  motorSWVersion: string;
}

class Address {
  @IsString()
  @IsOptional()
  address: string;

  @IsString()
  @IsOptional()
  city: string;

  @IsString()
  @IsOptional()
  state: string;

  @IsString()
  @IsOptional()
  country: string;

  @IsString()
  @IsOptional()
  zip: string;
}

export class CreateKioskDto extends KioskSensorDto {
  @IsOptional()
  _id?: ObjectId;

  @IsString()
  customerId: ObjectId;

  @IsString()
  @IsOptional()
  kioskName: string;

  @IsString()
  @IsOptional()
  kioskId: string;

  @IsString()
  @IsOptional()
  email: string;

  @IsString()
  @IsOptional()
  macId: string;

  @IsBoolean()
  @IsOptional()
  communicationStatus: boolean;

  @IsBoolean()
  @IsOptional()
  errorStatus: boolean;

  @IsString()
  @IsOptional()
  owner: string;

  @IsObject()
  @IsOptional()
  address: Address;

  @IsString()
  @IsOptional()
  locationTag: string;

  @IsString()
  @IsOptional()
  deployedLocation: string;

  @IsString()
  @IsOptional()
  checkInTime: string;

  @IsArray()
  @IsOptional()
  time: string[];

  @IsObject()
  @IsOptional()
  onSiteContact: OnSiteContract;

  @IsObject()
  @IsOptional()
  onSiteContactSecondary: OnSiteContract;

  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}

export class KioskStatus {
  @IsBoolean()
  isActive?: boolean;
}
