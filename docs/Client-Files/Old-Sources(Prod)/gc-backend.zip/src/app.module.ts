import {
  MiddlewareConsumer,
  Module,
  NestModule,
  RequestMethod,
} from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule } from '@nestjs/config';
import configuration from './config/configuration';
import { PreAuthMiddleware } from './middlewares/pre-auth-middleware.service';
import { CustomersModule } from './customers/customers.module';
import { RouterModule } from '@nestjs/core';
import { KioskModule } from './kiosks/kiosk.module';
import { ClientsModule } from './clients/clients.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { SeedsModule } from '../seeds/seeds.module';
import { CommandModule } from 'nestjs-command';
import { SmsModule } from './sms/sms.module';
import { FirebaseAdmin } from './common/firebase-admin/firebase-admin.service';
import { WebhookModule } from './webhooks/webhook.module';

const config = configuration();

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      load: [configuration],
    }),
    MongooseModule.forRoot(config.database.url),
    CustomersModule,
    CommandModule,
    KioskModule,
    ClientsModule,
    SeedsModule,
    DashboardModule,
    SmsModule,
    WebhookModule,
    RouterModule.register([
      {
        path: 'customers',
        module: CustomersModule,
      },
      {
        path: 'kiosk',
        module: KioskModule,
      },
      {
        path: 'clients',
        module: ClientsModule,
      },
      {
        path: 'dashboard',
        module: DashboardModule,
      },
      {
        path: 'sms',
        module: SmsModule,
      },
      {
        path: 'webhook',
        module: WebhookModule,
      },
    ]),
  ],
  controllers: [AppController],
  providers: [AppService, FirebaseAdmin],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(PreAuthMiddleware)
      .exclude(
        { path: 'webhook/client', method: RequestMethod.POST },
        { path: 'webhook/kioskStatus/:id', method: RequestMethod.GET },
        'webhook/(.*)',
      )
      .forRoutes({
        path: '*',
        method: RequestMethod.ALL,
      });
  }
}
