import { InjectModel } from '@nestjs/mongoose';
import { Kiosk, KioskDocument } from '../kiosks/entities/kiosk.schema';
import { Model } from 'mongoose';
import {
  Customer,
  CustomerDocument,
} from '../customers/entities/customers.schema';
import { Client, ClientDocument } from '../clients/entities/clients.schema';
import { differenceInMinutes } from 'date-fns';
export class DashboardService {
  constructor(
    @InjectModel(Kiosk.name)
    private readonly kioskModel: Model<KioskDocument>,
    @InjectModel(Customer.name)
    private readonly customerModel: Model<CustomerDocument>,
    @InjectModel(Client.name)
    private readonly clientModel: Model<ClientDocument>,
  ) {}

  extractInventoryPercentage(inventory, totalLowInventoryKiosk) {
    const inventoryPercentage = parseFloat(inventory.replace('%', ''));
    if (inventoryPercentage <= 15) {
      totalLowInventoryKiosk++;
    }
    return totalLowInventoryKiosk;
  }

  async findAll() {
    const totalKiosk = await this.kioskModel.count();
    const allKiosk = await this.kioskModel.find();
    const totalClients = await this.clientModel.count();
    let totalOnlineKiosk = 0,
      totalOfflineKiosk = 0,
      totalLowInventoryKiosk = 0;
    allKiosk.map((kiosk) => {
      const checkInTime = kiosk.checkInTime;
      if (parseFloat(kiosk.inventoryScented.replace('%', '')) <= 15) {
        totalLowInventoryKiosk++;
      } else if (parseFloat(kiosk.inventoryUnscented.replace('%', '')) <= 15) {
        totalLowInventoryKiosk++;
      }
      const mins = differenceInMinutes(new Date(), new Date(checkInTime));
      if (mins <= 15 && mins >= 0) {
        totalOnlineKiosk++;
      } else {
        totalOfflineKiosk++;
      }
    });

    const totalCustomers = await this.customerModel.count();
    return {
      kiosk: {
        total: totalKiosk,
        online: totalOnlineKiosk,
        offline: totalOfflineKiosk,
      },
      totalClients,
      totalCustomers,
      totalLowInventoryKiosk: totalLowInventoryKiosk,
    };
  }
}
