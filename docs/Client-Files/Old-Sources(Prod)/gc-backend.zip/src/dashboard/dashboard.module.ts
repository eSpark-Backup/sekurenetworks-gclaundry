import { Module } from '@nestjs/common';
import { DashboardController } from './dashboard.controller';
import { DashboardService } from './dashboard.service';
import { KioskModule } from '../kiosks/kiosk.module';
import { CustomersModule } from '../customers/customers.module';
import { MongooseModule } from '@nestjs/mongoose';
import { Kiosk, KioskSchema } from '../kiosks/entities/kiosk.schema';
import {
  Customer,
  CustomerSchema,
} from '../customers/entities/customers.schema';
import { Client, ClientsSchema } from '../clients/entities/clients.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Kiosk.name, schema: KioskSchema },
      { name: Customer.name, schema: CustomerSchema },
      { name: Client.name, schema: ClientsSchema },
    ]),
    KioskModule,
    CustomersModule,
  ],
  controllers: [DashboardController],
  providers: [DashboardService],
  exports: [DashboardService],
})
export class DashboardModule {}
