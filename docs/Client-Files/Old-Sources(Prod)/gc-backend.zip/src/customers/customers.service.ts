import { Model } from 'mongoose';
import { Injectable, Scope } from '@nestjs/common';
import { Customer, CustomerDocument } from './entities/customers.schema';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { InjectModel } from '@nestjs/mongoose';
import { ObjectId } from 'mongodb';
import { KioskService } from '../kiosks/kiosk.service';

@Injectable({ scope: Scope.REQUEST })
export class CustomersService {
  constructor(
    @InjectModel(Customer.name)
    private readonly customerModel: Model<CustomerDocument>,
    private readonly kioskService: KioskService,
  ) {}

  create(body: CreateCustomerDto) {
    try {
      body._id = new ObjectId();
      if (body?.kioskIds && body.kioskIds.length > 0) {
        body.kioskIds = body.kioskIds.map((kioskId) => new ObjectId(kioskId));
      }
      const createdCustomer = new this.customerModel(body);
      return createdCustomer.save();
    } catch (e) {
      console.log('++++ e ++++', e);
    }
  }

  findAll() {
    return this.customerModel.find().exec();
  }

  async findOne(_id) {
    _id = new ObjectId(_id);
    return this.customerModel.findOne({ _id }).exec();
  }

  async update(_id, updateCustomerDto: UpdateCustomerDto) {
    _id = new ObjectId(_id);
    delete updateCustomerDto._id;
    if (updateCustomerDto?.kioskIds && updateCustomerDto.kioskIds.length > 0) {
      updateCustomerDto.kioskIds = updateCustomerDto.kioskIds.map(
        (kioskId) => new ObjectId(kioskId),
      );
    }
    return this.customerModel.findOneAndUpdate({ _id }, updateCustomerDto, {
      new: false,
    });
  }

  async addNewKiosk(_id, kioskId) {
    _id = new ObjectId(_id);
    return this.customerModel.findOneAndUpdate(
      { _id },
      { $push: { kioskIds: kioskId } },
      {
        new: true,
      },
    );
  }

  async findOneAndUpdate(_id, kioskId) {
    _id = new ObjectId(_id);
    return this.customerModel.findOneAndUpdate(
      { _id },
      { $push: { kioskIds: kioskId } },
      {
        new: true,
      },
    );
  }

  async remove(id) {
    const _id = new ObjectId(id);
    const response = await this.customerModel.findOneAndRemove({ _id });
    if (response.kioskIds) {
      response.kioskIds.map(async (kioskId) => {
        await this.kioskService.update(kioskId, { customerId: null });
      });
    }
    return response;
  }
}
