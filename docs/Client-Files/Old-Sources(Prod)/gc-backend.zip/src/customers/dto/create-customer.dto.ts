import { IsArray, IsOptional, IsString } from 'class-validator';
import type { ObjectId } from 'mongodb';

export class CreateCustomerDto {
  @IsString()
  @IsOptional()
  _id?: ObjectId;

  @IsString()
  @IsOptional()
  readonly schoolName?: string;

  @IsString()
  @IsOptional()
  readonly customerFirstName?: string;

  @IsString()
  @IsOptional()
  readonly customerLastName?: string;

  @IsString()
  @IsOptional()
  readonly customerCity?: string;

  @IsString()
  @IsOptional()
  readonly customerState?: string;

  @IsString()
  @IsOptional()
  readonly customerCountry?: string;

  @IsString()
  @IsOptional()
  readonly customerZip?: string;

  @IsString()
  @IsOptional()
  readonly customerEmail?: string;

  @IsString()
  @IsOptional()
  readonly customerPhone?: string;

  @IsString()
  @IsOptional()
  readonly customerAddress?: string;

  @IsArray()
  @IsOptional()
  kioskIds?: ObjectId[];
}
