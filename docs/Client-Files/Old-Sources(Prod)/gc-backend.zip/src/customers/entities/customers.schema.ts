import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, now } from 'mongoose';
import { ObjectId } from 'mongodb';

export type CustomerDocument = HydratedDocument<Customer>;

@Schema()
export class Customer {
  @Prop()
  _id: ObjectId;

  @Prop()
  schoolName: string;

  @Prop()
  customerFirstName: string;

  @Prop()
  customerLastName: string;

  @Prop()
  customerCity: string;

  @Prop()
  customerState: string;

  @Prop()
  customerCountry: string;

  @Prop()
  customerZip: string;

  @Prop()
  //TODO: Apply unique constraint
  customerEmail: string;

  @Prop()
  customerPhone: string;

  @Prop()
  customerAddress: string;

  @Prop([ObjectId])
  kioskIds: ObjectId[];

  @Prop({ default: now() })
  created_at: Date;

  @Prop({ default: now() })
  updated_at: Date;
}

export const CustomerSchema = SchemaFactory.createForClass(Customer);
