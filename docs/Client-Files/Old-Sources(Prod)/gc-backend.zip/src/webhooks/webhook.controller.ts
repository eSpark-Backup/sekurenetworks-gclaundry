import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { WebhookService } from './webhook.service';
import { CreateClientsDto } from '../clients/dto/create-clients.dto';

@Controller()
export class WebhookController {
  constructor(private readonly webhookService: WebhookService) {}

  @Post('/client')
  create(@Body() createCityDto: CreateClientsDto) {
    return this.webhookService.createClient(createCityDto);
  }

  @Get('/kiosk-status/:kioskId')
  modifyKioskUpdatedAt(@Param() { kioskId }: { kioskId: string }) {
    return this.webhookService.getKioskStatus({ kioskId });
  }

  @Post('/kiosk/sensor-data/:kioskId')
  updateKioskSensorData(
    @Param() { kioskId }: { kioskId: string },
    @Body() updateKioskDto,
  ) {
    console.log('+++++ updateKioskDto +++', updateKioskDto);
    return this.webhookService.updateKioskSensor(kioskId, updateKioskDto);
  }

  @Get('/resend-password/:kioskId/:phone')
  resetPassword(
    @Param() { kioskId, phone }: { kioskId: string; phone: string },
  ) {
    return this.webhookService.resendPasswordToken(kioskId, phone);
  }
}
