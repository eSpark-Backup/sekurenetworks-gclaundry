import { IsEnum, IsNumber, IsOptional, IsString } from 'class-validator';
import type { ObjectId } from 'mongodb';

export enum SubscriptionTypes {
  PAID = 'Paid',
  SUBSIDIZED = 'Subsidized',
}

export class CreateClientsDto {
  @IsString()
  @IsOptional()
  _id?: ObjectId;

  @IsNumber()
  @IsOptional()
  class_year: number;

  @IsString()
  @IsOptional()
  email: string;

  @IsString()
  @IsOptional()
  first_name: string;

  @IsEnum(SubscriptionTypes)
  @IsOptional()
  subscription: SubscriptionTypes;

  @IsString()
  @IsOptional()
  gender: string;

  @IsString()
  @IsOptional()
  last_name: string;

  @IsString()
  @IsOptional()
  order_date: string;

  @IsNumber()
  @IsOptional()
  order_number: number;

  @IsString()
  @IsOptional()
  frequency: string;

  @IsString()
  @IsOptional()
  product: string;

  @IsNumber()
  @IsOptional()
  quantity: number;

  @IsString()
  @IsOptional()
  scenti: string;

  @IsString()
  @IsOptional()
  school: string;

  @IsNumber()
  @IsOptional()
  masterPin?: number;

  @IsNumber()
  @IsOptional()
  tel: string;

  @IsString()
  @IsOptional()
  scent: string;

  @IsString()
  @IsOptional()
  ethnicity: string;

  @IsString()
  @IsOptional()
  building: string;

  @IsString()
  @IsOptional()
  floor: string;

  @IsString()
  @IsOptional()
  recommend_friend: string;

  @IsNumber()
  @IsOptional()
  pin: number;

  @IsString()
  @IsOptional()
  financial_aid: string;

  @IsString()
  @IsOptional()
  low_income: string;
}
