import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { SchemaTypes, HydratedDocument, now } from 'mongoose';
import type { ObjectId } from 'mongodb';
import { SubscriptionTypes } from '../dto/create-clients.dto';

export type ClientDocument = HydratedDocument<Client>;

@Schema()
export class Client {
  @Prop({ type: SchemaTypes.ObjectId })
  _id: ObjectId;

  @Prop()
  class_year: number;

  @Prop()
  email: string;

  @Prop()
  first_name: string;

  @Prop({ default: SubscriptionTypes.PAID })
  subscription: string;

  @Prop()
  gender: string;

  @Prop()
  last_name: string;

  @Prop()
  order_date: string;

  @Prop()
  order_number: number;

  @Prop()
  frequency: string;

  @Prop()
  product: string;

  @Prop()
  masterPin: number;

  @Prop({ default: 0 })
  quantity: number;

  @Prop()
  scenti: string;

  @Prop()
  school: string;

  @Prop()
  tel: string;

  @Prop()
  scent: string;
  @Prop()
  ethnicity: string;
  @Prop()
  building: string;
  @Prop()
  floor: string;
  @Prop()
  recommend_friend: string;
  @Prop()
  pin: number;

  @Prop()
  resetPasswordToken: string;

  @Prop()
  financial_aid: string;

  @Prop()
  low_income: string;

  @Prop({ default: now() })
  created_at: Date;

  @Prop({ default: now() })
  updated_at: Date;
}
export const ClientsSchema = SchemaFactory.createForClass(Client);
