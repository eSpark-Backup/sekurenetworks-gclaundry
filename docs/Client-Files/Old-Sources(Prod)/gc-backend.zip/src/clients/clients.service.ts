import { Model } from 'mongoose';
import { Injectable, Scope } from '@nestjs/common';
import { Client, ClientDocument } from './entities/clients.schema';
import { CreateClientsDto } from './dto/create-clients.dto';
import { UpdateClientsDto } from './dto/update-clients.dto';
import { InjectModel } from '@nestjs/mongoose';
import { ObjectId } from 'mongodb';
import { SmsService } from '../sms/sms.service';
@Injectable({ scope: Scope.REQUEST })
export class ClientsService {
  constructor(
    @InjectModel(Client.name)
    private readonly clientModel: Model<ClientDocument>,
    private readonly smsService: SmsService,
  ) {}

  create(body: CreateClientsDto) {
    try {
      body._id = new ObjectId();
      if (body.tel) {
        body.tel = this.formatPhoneNumber(body.tel);
      }
      body.quantity = body.quantity ?? 50;
      const createdClient = new this.clientModel(body);
      return createdClient.save();
    } catch (e) {
      console.log('++++ e ++++', e);
    }
  }

  findAll() {
    return this.clientModel.find().sort({ created_at: 'desc' }).exec();
  }

  async findOne(id) {
    return this.clientModel.findOne({ _id: id }).exec();
  }

  formatPhoneNumber(phoneNumberString) {
    const cleaned = ('' + phoneNumberString).replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return '(' + match[1] + ') ' + match[2] + '-' + match[3];
    }
    return null;
  }
  async findByTel(tel) {
    tel = tel.toString();
    tel = tel.replace('+1', '');
    console.log('+++ tel +++', { tel: this.formatPhoneNumber(tel) });
    return this.clientModel.find({ tel: this.formatPhoneNumber(tel) });
  }

  async findByKioskIds(kioskIds) {
    kioskIds = kioskIds.map((kioskId) => new ObjectId(kioskId));
    return this.clientModel.find({ _id: { $in: kioskIds } }).exec();
  }

  async update(_id, updateClientDto: UpdateClientsDto) {
    delete updateClientDto._id;
    _id = new ObjectId(_id);
    return this.clientModel.findOneAndUpdate({ _id }, updateClientDto, {
      new: false,
    });
  }

  async remove(id) {
    const _id = new ObjectId(id);
    return this.clientModel.findOneAndRemove({ _id });
  }
}
