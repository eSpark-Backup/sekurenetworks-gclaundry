import { Module } from '@nestjs/common';
import configuration from '../src/config/configuration';
const config = configuration();
import * as mongoose from 'mongoose';

export const databaseProviders = [
  {
    provide: 'DATABASE_CONNECTION',
    useFactory: (): Promise<typeof mongoose> =>
      mongoose.connect(config.database.url),
  },
];
@Module({
  providers: [...databaseProviders],
  exports: [...databaseProviders],
})
export class ProviderModule {}
