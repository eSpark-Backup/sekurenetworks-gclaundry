import { Module } from '@nestjs/common';
import { CommandModule } from 'nestjs-command';
import { CustomerSeed } from './customer.seed';
import { CustomersModule } from '../src/customers/customers.module';
import { KioskModule } from '../src/kiosks/kiosk.module';
import { MongooseModule } from '@nestjs/mongoose';
import { Kiosk, KioskSchema } from '../src/kiosks/entities/kiosk.schema';
import {
  Customer,
  CustomerSchema,
} from '../src/customers/entities/customers.schema';

import configuration from '../src/config/configuration';
import { ProviderModule } from './provider.module';
import { Client, ClientsSchema } from '../src/clients/entities/clients.schema';
import { ClientsModule } from '../src/clients/clients.module';
const config = configuration();

@Module({
  imports: [
    MongooseModule.forRoot(config.database.url),
    MongooseModule.forFeature([
      { name: Kiosk.name, schema: KioskSchema },
      { name: Customer.name, schema: CustomerSchema },
      { name: Client.name, schema: ClientsSchema },
    ]),
    KioskModule,
    CustomersModule,
    CommandModule,
    ProviderModule,
    ClientsModule,
  ],
  providers: [CustomerSeed],
  exports: [CustomerSeed],
})
export class SeedsModule {}
