import { Command } from 'nestjs-command';
import { Injectable } from '@nestjs/common';
import { CustomersService } from '../src/customers/customers.service';
import { InjectModel } from '@nestjs/mongoose';
import { ObjectId } from 'mongodb';
import { Customer } from '../src/customers/entities/customers.schema';
import { Chance } from 'chance';
import { KioskService } from '../src/kiosks/kiosk.service';
import { sub } from 'date-fns';
import { Kiosk } from '../src/kiosks/entities/kiosk.schema';
import * as lodash from 'lodash';
import { ClientsService } from '../src/clients/clients.service';
import { Client } from '../src/clients/entities/clients.schema';

const chance = new Chance();
const colleges = [
  'Adelphi University',
  'American University - International Accelerator',
  'Auburn University',
  'Felician University',
  'University of Dayton',
  'Florida State College at Jacksonville English Language Institute',
  'Heartland Community College',
  'McNeese State University',
  'Northwest Missouri State University',
  'Rockland Community College',
  'South Dakota School of Mines and Technology',
  'Maryville College',
  'American University of Antigua College of Medicine (AUA)',
  'Central Connecticut State University Intensive Language Program',
  'Florida International University Global First Year',
  'George Mason University',
  'Johns Hopkins Whiting School of Engineering',
  'Lingoda',
  'Madison College',
  'Santa Fe College',
  'Study Florida',
  'Study Illinois',
  'Study South Carolina',
  'Study Tennessee',
  'Study Wisconsin',
  'The University of North Florida Coggin College of Business',
  'University of Kansas',
  'University of Minnesota-Twin Cities',
  'Broward College',
  'California State University, Monterey Bay',
  'California State University-Dominguez Hills',
  'Cleveland State Global',
  'College of Central Florida',
  'Full Sail University',
  'Gonzaga University',
  'Louisiana State University - Global Pathway',
  'Middle Tennessee State University',
  'Nicholls State University',
  'Northeastern Junior College',
  'UMass Boston',
  'University of Arkansas',
  'University of Illinois at Chicago Global',
  'University of Illinois at Springfield',
  'University of Mount Union',
  'University of South Carolina',
  'University of Utah',
  'University of West Georgia',
  'UOP International',
  'Valencia College',
];

const resolution = ['1280 x 800'];

const time = [
  'just now',
  '1 day ago',
  '2 min ago',
  '2 days ago',
  '1 week ago',
  '1 year ago',
  '5 months ago',
  '3 hours ago',
  '1 hour ago',
];

export const range = (len) => {
  const arr = [];
  for (let i = 0; i < len; i += 1) {
    arr.push(i);
  }
  return arr;
};
const totalCustoms = 2;
const totalKiosks = 5;
const totalClients = 5;
const customerIds = range(totalCustoms).map(() => new ObjectId());
const kioskIds = range(totalKiosks).map(() => new ObjectId());
const clientIds = range(totalClients).map(() => new ObjectId());

const customers = customerIds.map(() => ({
  customerFirstName: chance.first(),
  customerLastName: chance.last(),
  customerEmail: chance.email({ domain: 'gmail.com' }),
  customerPhone: chance.phone(),
  customerAddress: chance.address(),
  customerCity: chance.city(),
  customerState: chance.state(),
  customerCountry: chance.country(),
  customerZip: chance.zip(),
  kioskIds: [],
}));

@Injectable()
export class CustomerSeed {
  constructor(
    @InjectModel(Customer.name)
    private readonly customerService: CustomersService,
    @InjectModel(Kiosk.name)
    private readonly kioskService: KioskService,
    @InjectModel(Client.name)
    private readonly clientService: ClientsService,
  ) {}

  @Command({
    command: 'seed:customers',
    describe: 'create random customers',
  })
  create() {
    try {
      // const clientPromise = clientIds.map(async (clientId) =>
      //   this.clientService.create({
      //     _id: clientId,
      //     masterPin: chance.integer({ min: 1000, max: 9999 }),
      //     class_year: chance.integer({ min: 1985, max: 2010 }),
      //     email: chance.email({ domain: 'gmail.com' }),
      //     first_name: chance.first(),
      //     subscription: chance.pickone(['Paid', 'Subsidized']),
      //     gender: chance.pickone(['Male', 'Female']),
      //     last_name: chance.last(),
      //     order_date: sub(new Date(), {
      //       days: chance.integer({ min: 0, max: 100 }),
      //     }).toString(),
      //     frequency: chance.integer({ min: 0, max: 100 }),
      //     order_number: chance.integer({ min: 100000, max: 900000 }),
      //     product: chance.pickone([
      //       'Product 1',
      //       'Product 2',
      //       'Product 3',
      //       'Product 4',
      //       'Product 5',
      //     ]),
      //     quantity:
      //       chance.integer({ min: 0, max: 50 }) +
      //       '/' +
      //       chance.pickone(['50', '100', '150']),
      //     scenti: chance.pickone(['Scented', 'Unscented']),
      //     school: chance.pickone(colleges),
      //     tel: chance.phone(),
      //   }),
      // );
      // Promise.all([...clientPromise]).then(() => console.log('+++ done +++'));
      const customerPromise = customerIds.map(async (customerId) =>
        this.customerService.create({
          _id: customerId,
          schoolName: chance.pickone(colleges),
          customerFirstName: chance.first(),
          customerLastName: chance.last(),
          customerEmail: chance.email({ domain: 'gmail.com' }),
          customerPhone: chance.phone(),
          customerAddress: chance.address(),
          customerCity: chance.city(),
          customerState: chance.state(),
          customerCountry: chance.country(),
          customerZip: chance.zip(),
          kioskIds: [],
        }),
      );
      Promise.all(customerPromise).then((customers) => {
        const kioskPromise = kioskIds.map(async (kioskId) => {
          const { _id: customerId, schoolName } = chance.pickone(customers);
          const state = chance.state();
          await this.kioskService.create({
            _id: kioskId,
            kioskId:
              state.toLowerCase().substring(0, 2) +
              '-' +
              (Math.random() + 1).toString(36).substring(7),
            kioskName: chance.hash({ length: 8 }),
            email: chance.email({ domain: 'gmail.com' }),
            macId: chance.hash({ length: 15 }),
            communicationStatus: chance.bool(),
            errorStatus: chance.bool(),
            owner: chance.pickone(customerIds),
            deployedLocation: schoolName,
            customerId,
            onSiteContact: {
              firstName: chance.first(),
              lastName: chance.last(),
              phone: chance.phone(),
              email: chance.email({ domain: 'gmail.com' }),
            },
            onSiteContactSecondary: {
              firstName: chance.first(),
              lastName: chance.last(),
              phone: chance.phone(),
              email: chance.email({ domain: 'gmail.com' }),
            },
            address: {
              address: chance.address(),
              city: chance.city(),
              state: state,
              country: chance.country(),
              zip: chance.zip(),
            },
            locationTag: chance.hash({ length: 6 }),
            inventoryScented: chance.integer({ min: 0, max: 100 }),
            inventoryUnscented: chance.integer({ min: 0, max: 100 }),
            screen: chance.pick([10.1, 8.0]),
            resolution: chance.pickone(resolution),
            sbcHWVersion: chance.floating({ min: 0, max: 4, fixed: 2 }),
            sbcSWVersion: chance.floating({ min: 0, max: 4, fixed: 2 }),
            mcbHWVersion: chance.floating({ min: 0, max: 4, fixed: 2 }),
            mcbSWVersion: chance.floating({ min: 0, max: 4, fixed: 2 }),
            motorHWVersion: chance.floating({ min: 0, max: 4, fixed: 2 }),
            motorSWVersion: chance.floating({ min: 0, max: 4, fixed: 2 }),
            checkInTime: sub(new Date(), {
              days: chance.integer({ min: 0, max: 100 }),
            }).toString(),
            time: lodash.sampleSize(time),
          });
          return this.customerService.findOneAndUpdate(
            { _id: customerId },
            { $push: { kioskIds: kioskId } },
          );
        });
        // const clientPromise = clientIds.map(async (clientId) =>
        // this.clientService.create({
        //   _id: clientId,
        //   class_year: chance.integer({ min: 1985, max: 2010 }),
        //   email: chance.email({ domain: 'gmail.com' }),
        //   first_name: chance.first(),
        //   subscription: chance.pickone(['Paid', 'Subsidized']),
        //   gender: chance.pickone(['Male', 'Female']),
        //   last_name: chance.last(),
        //   order_date: sub(new Date(), {
        //     days: chance.integer({ min: 0, max: 100 }),
        //   }).toString(),
        //   frequency: chance.integer({ min: 0, max: 100 }),
        //   order_number: chance.integer({ min: 100000, max: 900000 }),
        //   product: chance.pickone([
        //     'Product 1',
        //     'Product 2',
        //     'Product 3',
        //     'Product 4',
        //     'Product 5',
        //   ]),
        //   quantity:
        //     chance.integer({ min: 0, max: 50 }) +
        //     '/' +
        //     chance.pickone(['50', '100', '150']),
        //   scenti: chance.pickone(['Scented', 'Unscented']),
        //   school: chance.pickone(colleges),
        //   tel: chance.phone(),
        // }),
        // );
        Promise.all([
          ...customerPromise,
          ...kioskPromise,
          // ...clientPromise,
        ]).then(() => console.log('+++ done +++'));
      });
      return true;
    } catch (e) {
      console.log('+++++ e++++', e);
      return true;
    }
  }
}
